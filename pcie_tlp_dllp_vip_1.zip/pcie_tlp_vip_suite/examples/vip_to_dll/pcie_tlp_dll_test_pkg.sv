`ifndef PCIE_TLP_DLL_TEST_PKG_SV
`define PCIE_TLP_DLL_TEST_PKG_SV

package pcie_tlp_dll_test_pkg;
  import uvm_pkg::*;
  import pcie_tlp_globals_pkg::*;
  import pcie_tlp_rc_pkg::*;
  import pcie_tlp_ep_pkg::*;
  import pcie_dll_globals_pkg::*;
  import pcie_dll_pkg::*;
  import pcie_tlp_env_pkg::*; // reused for pcie_tlp_scoreboard + subscriber shims
`include "uvm_macros.svh"

`include "pcie_tlp_dll_env.sv"
`include "pcie_tlp_dll_smoke_test.sv"

endpackage : pcie_tlp_dll_test_pkg

`endif
