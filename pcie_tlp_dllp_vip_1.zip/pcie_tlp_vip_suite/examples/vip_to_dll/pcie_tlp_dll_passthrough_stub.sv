//-----------------------------------------------------------------------------
// pcie_tlp_dll_passthrough_stub.sv
// Minimal example "DLL VIP" placeholder that terminates one pcie_tlp_if
// (facing the TLP VIP) and re-drives a second pcie_tlp_if (facing the
// PHY / another link partner), inserting only DLL-owned concerns
// (illustrated here as comments -- a real DLL VIP fills these in):
//   - Sequence number assignment / stripping
//   - ACK/NAK generation and replay buffer management
//   - Flow control credit accounting
// The TLP VIP itself never needs to change to plug into this boundary;
// it only ever speaks tlp_if's tx_*/rx_* signals.
//-----------------------------------------------------------------------------
module pcie_tlp_dll_passthrough_stub (
  pcie_tlp_if.DUT tlp_side, // faces the TLP VIP (RC or EP)
  pcie_tlp_if.DUT phy_side  // faces the PHY / remote link partner
);

  // Pure combinational pass-through for the example: a real DLL would
  // buffer here for replay, insert/validate sequence numbers, and only
  // present rx_ready backpressure once flow-control credits allow it.
  always_comb begin
    phy_side.tx_data  = tlp_side.tx_data;
    phy_side.tx_keep  = tlp_side.tx_keep;
    phy_side.tx_valid = tlp_side.tx_valid;
    phy_side.tx_sop   = tlp_side.tx_sop;
    phy_side.tx_eop   = tlp_side.tx_eop;
    phy_side.tx_err   = tlp_side.tx_err;
    tlp_side.tx_ready = phy_side.tx_ready;

    tlp_side.rx_data  = phy_side.rx_data;
    tlp_side.rx_keep  = phy_side.rx_keep;
    tlp_side.rx_valid = phy_side.rx_valid;
    tlp_side.rx_sop   = phy_side.rx_sop;
    tlp_side.rx_eop   = phy_side.rx_eop;
    tlp_side.rx_err   = phy_side.rx_err;
    phy_side.rx_ready = tlp_side.rx_ready;
  end

endmodule : pcie_tlp_dll_passthrough_stub
