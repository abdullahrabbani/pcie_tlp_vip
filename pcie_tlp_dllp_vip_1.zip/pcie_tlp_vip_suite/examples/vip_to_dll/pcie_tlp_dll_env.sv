`ifndef PCIE_TLP_DLL_ENV_SV
`define PCIE_TLP_DLL_ENV_SV

// Small env for this example only: RC agent + EP agent (as in env/) plus
// a pcie_dll_agent sitting logically between them (physically it's the
// hdl_top wiring that puts it in the signal path -- this env just needs
// handles to start sequences and to hook the DLL's events + the
// existing pcie_tlp_scoreboard together).
class pcie_tlp_dll_env extends uvm_env;
  `uvm_component_utils(pcie_tlp_dll_env)

  pcie_tlp_rc_agent_config rc_cfg;
  pcie_tlp_ep_agent_config ep_cfg;
  pcie_dll_agent_config     dll_cfg;

  pcie_tlp_rc_agent  rc_agent_h;
  pcie_tlp_ep_agent  ep_agent_h;
  pcie_dll_agent      dll_agent_h;

  pcie_tlp_scoreboard scoreboard_h;
  pcie_tlp_sb_request_subscriber    sb_req_sub_h;
  pcie_tlp_sb_completion_subscriber sb_cpl_sub_h;

  function new(string name = "pcie_tlp_dll_env", uvm_component parent = null);
    super.new(name, parent);
  endfunction

  function void build_phase(uvm_phase phase);
    super.build_phase(phase);

    rc_cfg = pcie_tlp_rc_agent_config::type_id::create("rc_cfg");
    rc_cfg.is_active = UVM_ACTIVE;
    rc_cfg.completion_timeout_ns = 20000; // roomier than Mode 1 default: DLL adds latency
    uvm_config_db#(pcie_tlp_rc_agent_config)::set(this, "rc_agent_h", "cfg", rc_cfg);
    rc_agent_h = pcie_tlp_rc_agent::type_id::create("rc_agent_h", this);

    ep_cfg = pcie_tlp_ep_agent_config::type_id::create("ep_cfg");
    ep_cfg.is_active = UVM_ACTIVE;
    uvm_config_db#(pcie_tlp_ep_agent_config)::set(this, "ep_agent_h", "cfg", ep_cfg);
    ep_agent_h = pcie_tlp_ep_agent::type_id::create("ep_agent_h", this);

    dll_cfg = pcie_dll_agent_config::type_id::create("dll_cfg");
    dll_cfg.is_active = UVM_ACTIVE;
    uvm_config_db#(pcie_dll_agent_config)::set(this, "dll_agent_h", "cfg", dll_cfg);
    dll_agent_h = pcie_dll_agent::type_id::create("dll_agent_h", this);

    scoreboard_h = pcie_tlp_scoreboard::type_id::create("scoreboard_h", this);
    sb_req_sub_h = pcie_tlp_sb_request_subscriber::type_id::create("sb_req_sub_h", this);
    sb_cpl_sub_h = pcie_tlp_sb_completion_subscriber::type_id::create("sb_cpl_sub_h", this);
  endfunction

  function void connect_phase(uvm_phase phase);
    super.connect_phase(phase);
    sb_req_sub_h.sb = scoreboard_h;
    sb_cpl_sub_h.sb = scoreboard_h;
    rc_agent_h.request_ap.connect(sb_req_sub_h.analysis_export);
    rc_agent_h.completion_ap.connect(sb_cpl_sub_h.analysis_export);
  endfunction
endclass : pcie_tlp_dll_env

`endif
