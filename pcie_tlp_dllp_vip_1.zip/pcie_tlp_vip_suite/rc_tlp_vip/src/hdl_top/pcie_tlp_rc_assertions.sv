`ifndef PCIE_TLP_RC_ASSERTIONS_SV
`define PCIE_TLP_RC_ASSERTIONS_SV

module pcie_tlp_rc_assertions (pcie_tlp_if vif);

  import uvm_pkg::*;
`include "uvm_macros.svh"

  // A1: sop always coincides with valid.
  property p_sop_with_valid;
    @(posedge vif.clk) disable iff (!vif.rst_n)
    vif.tx_sop |-> vif.tx_valid;
  endproperty
  a_sop_with_valid: assert property (p_sop_with_valid)
    else `uvm_error("PCIE_TLP_RC_ASSERT", "tx_sop asserted without tx_valid")

  // A2: data/valid must remain stable while stalled (valid high, ready low).
  property p_stable_under_backpressure;
    @(posedge vif.clk) disable iff (!vif.rst_n)
    (vif.tx_valid && !vif.tx_ready) |=> $stable(vif.tx_data) && vif.tx_valid;
  endproperty
  a_stable_under_backpressure: assert property (p_stable_under_backpressure)
    else `uvm_error("PCIE_TLP_RC_ASSERT", "tx_data/tx_valid changed while stalled")

  // A3: every sop is followed by an eop within a bounded window (no
  // dangling/truncated TLP on the RC transmit side).
  property p_sop_implies_eop;
    @(posedge vif.clk) disable iff (!vif.rst_n)
    (vif.tx_valid && vif.tx_sop) |-> ##[1:64] (vif.tx_valid && vif.tx_eop);
  endproperty
  a_sop_implies_eop: assert property (p_sop_implies_eop)
    else `uvm_error("PCIE_TLP_RC_ASSERT", "tx_sop not followed by tx_eop within 64 cycles")

endmodule : pcie_tlp_rc_assertions

`endif
