`ifndef PCIE_TLP_RC_AGENT_BFM_SV
`define PCIE_TLP_RC_AGENT_BFM_SV

module pcie_tlp_rc_agent_bfm (pcie_tlp_if.DUT vif);

  pcie_tlp_rc_driver_bfm  rc_driver_bfm_h  (vif);
  pcie_tlp_rc_monitor_bfm rc_monitor_bfm_h (vif);

  // Handles are registered into the uvm_config_db by pcie_tlp_hdl_top so
  // that the hvl_top driver_proxy/monitor_proxy can pick them up by name.

endmodule : pcie_tlp_rc_agent_bfm

`endif
