//-----------------------------------------------------------------------------
// pcie_tlp_rc_driver_bfm.sv
// RC-side driver BFM: serializes pcie_tlp_seq_item requests onto tx_*, and
// samples completions arriving on rx_* on behalf of the driver_proxy.
//-----------------------------------------------------------------------------
`ifndef PCIE_TLP_RC_DRIVER_BFM_SV
`define PCIE_TLP_RC_DRIVER_BFM_SV

interface pcie_tlp_rc_driver_bfm (pcie_tlp_if.DUT vif);

  import uvm_pkg::*;
  import pcie_tlp_globals_pkg::*;
`include "uvm_macros.svh"

  string name = "PCIE_TLP_RC_DRIVER_BFM";

  task wait_for_reset();
    @(negedge vif.rst_n);
    default_values();
    @(posedge vif.rst_n);
  endtask

  task default_values();
    vif.tx_data  <= '0;
    vif.tx_keep  <= '0;
    vif.tx_valid <= 1'b0;
    vif.tx_sop   <= 1'b0;
    vif.tx_eop   <= 1'b0;
    vif.tx_err   <= 1'b0;
    vif.rx_ready <= 1'b1;
  endtask

  // Drive one request TLP (mem/io/cfg read or write) out tx_*.
  task automatic drive_request(input pcie_tlp_seq_item item);
    bit [31:0] hdr[4];
    int        hdr_dws;
    hdr_dws = item.pack_header(hdr);

    repeat (item.delay_cycles) @(posedge vif.clk);

    @(posedge vif.clk);
    vif.tx_data  <= {hdr[1], hdr[0]};
    vif.tx_keep  <= '1;
    vif.tx_valid <= 1'b1;
    vif.tx_sop   <= 1'b1;
    vif.tx_eop   <= (hdr_dws == 3 && item.length_dw == 0) ? 1'b0 : 1'b0;
    vif.tx_err   <= item.inject_error;
    do @(posedge vif.clk); while (vif.tx_ready !== 1'b1);

    if (hdr_dws == 4) begin
      vif.tx_data <= {hdr[3], hdr[2]};
      vif.tx_eop  <= (item.length_dw == 0);
      do @(posedge vif.clk); while (vif.tx_ready !== 1'b1);
    end
    else begin
      // 3DW header: DW2 is the low half of this beat, high half unused
      vif.tx_data <= {32'h0, hdr[2]};
      vif.tx_eop  <= (item.length_dw == 0);
      do @(posedge vif.clk); while (vif.tx_ready !== 1'b1);
    end

    // payload beats (writes only)
    for (int i = 0; i < item.length_dw; i += 2) begin
      bit [63:0] beat;
      beat = item.payload[i];
      if (i+1 < item.length_dw) beat |= {item.payload[i+1], 32'h0};
      @(posedge vif.clk);
      vif.tx_data <= beat;
      vif.tx_eop  <= (i+2 >= item.length_dw);
      do @(posedge vif.clk); while (vif.tx_ready !== 1'b1);
    end

    @(posedge vif.clk);
    default_values();
    `uvm_info(name, $sformatf("Drove request: %s", item.convert2string()), UVM_HIGH)
  endtask

  // Sample one completion TLP arriving on rx_*.
  task automatic sample_completion(output pcie_tlp_seq_item item, input pcie_tlp_seq_item factory_item);
    bit [31:0] hdr[4];
    int        hdr_dws;

    item = factory_item;
    vif.rx_ready <= 1'b1;
    do @(posedge vif.clk); while (!(vif.rx_valid && vif.rx_sop));

    hdr[0] = vif.rx_data[31:0];
    hdr[1] = vif.rx_data[63:32];
    @(posedge vif.clk);
    hdr[2] = vif.rx_data[31:0];
    hdr[3] = vif.rx_data[63:32];

    item.unpack_header(hdr, 3);
    hdr_dws = 3;

    for (int i = 0; i < item.length_dw; i++) begin
      if (i % 2 == 0) @(posedge vif.clk);
      item.payload = new[item.length_dw](item.payload);
      item.payload[i] = (i % 2 == 0) ? vif.rx_data[31:0] : vif.rx_data[63:32];
    end

    if (!vif.rx_eop) @(posedge vif.clk); // flush to eop if extra beat pending
    item.complete_time = $time;
    `uvm_info(name, $sformatf("Sampled completion: %s", item.convert2string()), UVM_HIGH)
  endtask

endinterface : pcie_tlp_rc_driver_bfm

`endif
