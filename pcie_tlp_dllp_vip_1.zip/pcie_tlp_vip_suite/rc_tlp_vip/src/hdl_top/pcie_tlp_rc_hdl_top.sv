`ifndef PCIE_TLP_RC_HDL_TOP_SV
`define PCIE_TLP_RC_HDL_TOP_SV

// Standalone RC HDL top: clock/reset generation + interface + RC agent
// BFM + assertions. In VIP-to-VIP or VIP-to-DUT integration this module
// is instantiated by the top-level env testbench instead (see
// examples/vip_to_vip and examples/vip_to_dut) which wires vif to either
// an EP VIP's interface directly, or to DUT pins / a DLL VIP.
module pcie_tlp_rc_hdl_top;
  import uvm_pkg::*;
`include "uvm_macros.svh"

  bit clk;
  bit rst_n;

  initial clk = 0;
  always #5 clk = ~clk;

  initial begin
    rst_n = 0;
    #20 rst_n = 1;
  end

  pcie_tlp_if rc_if (.clk(clk), .rst_n(rst_n));
  pcie_tlp_rc_agent_bfm rc_agent_bfm_h (.vif(rc_if));

  initial begin
    uvm_config_db#(virtual pcie_tlp_rc_driver_bfm)::set(null, "*", "bfm", rc_agent_bfm_h.rc_driver_bfm_h);
    uvm_config_db#(virtual pcie_tlp_rc_monitor_bfm)::set(null, "*", "bfm", rc_agent_bfm_h.rc_monitor_bfm_h);
    uvm_config_db#(virtual pcie_tlp_if)::set(null, "*", "vif", rc_if);
  end

  pcie_tlp_rc_assertions rc_assertions_h (.vif(rc_if));

endmodule : pcie_tlp_rc_hdl_top

`endif
