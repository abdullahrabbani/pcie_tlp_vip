`ifndef PCIE_TLP_RC_COVERAGE_SV
`define PCIE_TLP_RC_COVERAGE_SV

class pcie_tlp_rc_coverage extends uvm_subscriber #(pcie_tlp_seq_item);
  `uvm_component_utils(pcie_tlp_rc_coverage)

  pcie_tlp_rc_agent_config cfg;
  pcie_tlp_seq_item        item;

  covergroup rc_tlp_cg;
    option.per_instance = 1;
    cp_opcode: coverpoint item.opcode;
    cp_tc:     coverpoint item.tc;
    cp_attr:   coverpoint item.attr;
    cp_hdr:    coverpoint item.is_4dw_hdr { bins dw3 = {0}; bins dw4 = {1}; }
    cp_len:    coverpoint item.length_dw {
      bins zero    = {0};
      bins small   = {[1:16]};
      bins medium  = {[17:64]};
      bins large   = {[65:$]};
    }
    cp_err:    coverpoint item.inject_error;
    cross_opcode_len: cross cp_opcode, cp_len;
  endgroup

  function new(string name = "pcie_tlp_rc_coverage", uvm_component parent = null);
    super.new(name, parent);
    rc_tlp_cg = new();
  endfunction

  function void write(pcie_tlp_seq_item t);
    item = t;
    rc_tlp_cg.sample();
  endfunction
endclass : pcie_tlp_rc_coverage

`endif
