`ifndef PCIE_TLP_RC_DRIVER_PROXY_SV
`define PCIE_TLP_RC_DRIVER_PROXY_SV

class pcie_tlp_rc_driver_proxy extends uvm_driver #(pcie_tlp_seq_item);
  `uvm_component_utils(pcie_tlp_rc_driver_proxy)

  virtual pcie_tlp_rc_driver_bfm bfm;
  pcie_tlp_rc_agent_config       cfg;

  // Completion analysis port: every completion collected while waiting
  // for a non-posted request also gets published here so a scoreboard
  // or the RC monitor's own subscribers can see it independent of the
  // sequence that issued the request.
  uvm_analysis_port #(pcie_tlp_seq_item) completion_ap;

  `uvm_declare_p_sequencer(pcie_tlp_rc_sequencer)

  function new(string name = "pcie_tlp_rc_driver_proxy", uvm_component parent = null);
    super.new(name, parent);
    completion_ap = new("completion_ap", this);
  endfunction

  function void build_phase(uvm_phase phase);
    super.build_phase(phase);
    if (!uvm_config_db#(virtual pcie_tlp_rc_driver_bfm)::get(this, "", "bfm", bfm))
      `uvm_fatal("NOVIF", "virtual pcie_tlp_rc_driver_bfm not found in config_db")
  endfunction

  task run_phase(uvm_phase phase);
    bfm.wait_for_reset();
    forever begin
      pcie_tlp_seq_item req;
      seq_item_port.get_next_item(req);

      `uvm_do_callbacks(pcie_tlp_rc_driver_proxy, pcie_tlp_callbacks, pre_send(req))

      bfm.drive_request(req);

      if (!req.is_posted) begin
        pcie_tlp_seq_item cpl;
        fork
          begin
            bfm.sample_completion(cpl, pcie_tlp_seq_item::type_id::create("cpl"));
            cpl.transaction_id = req.tag;
            completion_ap.write(cpl);
            req.cpl_status = cpl.cpl_status;
          end
          begin
            #(cfg.completion_timeout_ns * 1ns);
            `uvm_error("PCIE_TLP_RC_TIMEOUT",
              $sformatf("Completion timeout for tag %0d, addr 0x%0h", req.tag, req.address))
          end
        join_any
        disable fork;
      end

      `uvm_do_callbacks(pcie_tlp_rc_driver_proxy, pcie_tlp_callbacks, post_send(req))
      seq_item_port.item_done();
    end
  endtask
endclass : pcie_tlp_rc_driver_proxy

`endif
