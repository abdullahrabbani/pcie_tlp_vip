`ifndef PCIE_TLP_RC_PKG_SV
`define PCIE_TLP_RC_PKG_SV

package pcie_tlp_rc_pkg;
  import uvm_pkg::*;
  import pcie_tlp_globals_pkg::*;
`include "uvm_macros.svh"

`include "pcie_tlp_rc_agent_config.sv"
`include "pcie_tlp_rc_sequencer.sv"
`include "pcie_tlp_rc_driver_proxy.sv"
`include "pcie_tlp_rc_monitor_proxy.sv"
`include "pcie_tlp_rc_coverage.sv"
`include "pcie_tlp_rc_agent.sv"
`include "sequences/pcie_tlp_rc_base_seq.sv"

endpackage : pcie_tlp_rc_pkg

`endif
