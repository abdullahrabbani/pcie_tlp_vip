`ifndef PCIE_TLP_RC_AGENT_CONFIG_SV
`define PCIE_TLP_RC_AGENT_CONFIG_SV

class pcie_tlp_rc_agent_config extends uvm_object;
  `uvm_object_utils(pcie_tlp_rc_agent_config)

  uvm_active_passive_enum is_active = UVM_ACTIVE;
  pcie_tlp_addr_width_e   addr_width = ADDR_64BIT;

  bit  [15:0] requester_id            = 16'h0100;
  int         max_payload_size_bytes  = PCIE_TLP_MAX_PAYLOAD_BYTES_DEFAULT;
  int         max_read_req_size_bytes = PCIE_TLP_MAX_READ_REQ_BYTES_DEFAULT;
  int         completion_timeout_ns   = PCIE_TLP_DEFAULT_TIMEOUT_NS;
  bit         error_injection_enable  = 0;

  virtual pcie_tlp_if vif;

  function new(string name = "pcie_tlp_rc_agent_config");
    super.new(name);
  endfunction

  function void do_print(uvm_printer printer);
    printer.print_field("is_active", is_active, 1);
    printer.print_field("requester_id", requester_id, 16, UVM_HEX);
    printer.print_field("max_payload_size_bytes", max_payload_size_bytes, 32);
    printer.print_field("max_read_req_size_bytes", max_read_req_size_bytes, 32);
    printer.print_field("completion_timeout_ns", completion_timeout_ns, 32);
    printer.print_field("error_injection_enable", error_injection_enable, 1);
  endfunction
endclass : pcie_tlp_rc_agent_config

`endif
