`ifndef PCIE_TLP_RC_BASE_SEQ_SV
`define PCIE_TLP_RC_BASE_SEQ_SV

class pcie_tlp_rc_base_seq extends uvm_sequence #(pcie_tlp_seq_item);
  `uvm_object_utils(pcie_tlp_rc_base_seq)
  `uvm_declare_p_sequencer(pcie_tlp_rc_sequencer)

  function new(string name = "pcie_tlp_rc_base_seq");
    super.new(name);
  endfunction

  //-------------------------------------------------------------
  // Reusable request builders. Each returns the completed item
  // after driver_proxy has captured the completion (for non-posted
  // requests) so callers can inspect req.cpl_status directly.
  //-------------------------------------------------------------
  task automatic do_mem_write(bit [63:0] addr, bit [31:0] data[], bit [15:0] req_id,
                               bit [7:0] tag = 8'h0, bit [2:0] tc = 3'h0);
    pcie_tlp_seq_item item;
    item = pcie_tlp_seq_item::type_id::create("mem_wr");
    start_item(item);
    if (!item.randomize() with {
      opcode == TLP_MEM_WRITE;
      fmt == (addr[63:32] != 0) ? FMT_4DW_DATA : FMT_3DW_DATA;
      is_4dw_hdr == (addr[63:32] != 0);
      address == addr;
      requester_id == req_id;
      tag == local::tag;
      tc == local::tc;
      length_dw == data.size();
      last_be == 4'hF; first_be == 4'hF;
      inject_error == 0;
      delay_cycles inside {[0:2]};
    }) `uvm_error(get_name(), "Randomization failed for mem_write")
    item.payload = data;
    finish_item(item);
  endtask

  task automatic do_mem_read(bit [63:0] addr, int unsigned len_dw, bit [15:0] req_id,
                              output pcie_tlp_seq_item cpl, bit [7:0] tag = 8'h0);
    pcie_tlp_seq_item item;
    item = pcie_tlp_seq_item::type_id::create("mem_rd");
    start_item(item);
    if (!item.randomize() with {
      opcode == TLP_MEM_READ;
      fmt == (addr[63:32] != 0) ? FMT_4DW_NO_DATA : FMT_3DW_NO_DATA;
      is_4dw_hdr == (addr[63:32] != 0);
      address == addr;
      requester_id == req_id;
      tag == local::tag;
      length_dw == local::len_dw;
      last_be == 4'hF; first_be == 4'hF;
      inject_error == 0;
    }) `uvm_error(get_name(), "Randomization failed for mem_read")
    finish_item(item);
    cpl = item;
  endtask

  task automatic do_cfg_write(bit [7:0] bus, bit [4:0] dev, bit [2:0] func,
                               bit [9:0] reg_num, bit [31:0] data, bit [15:0] req_id);
    pcie_tlp_seq_item item;
    item = pcie_tlp_seq_item::type_id::create("cfg_wr");
    start_item(item);
    if (!item.randomize() with {
      opcode == TLP_CFG_WRITE;
      fmt == FMT_3DW_DATA;
      is_4dw_hdr == 0;
      cfg_bus == bus; cfg_device == dev; cfg_function == func; cfg_register == reg_num;
      requester_id == req_id;
      length_dw == 1;
      last_be == 4'hF; first_be == 4'hF;
    }) `uvm_error(get_name(), "Randomization failed for cfg_write")
    item.payload = new[1];
    item.payload[0] = data;
    finish_item(item);
  endtask

  task automatic do_cfg_read(bit [7:0] bus, bit [4:0] dev, bit [2:0] func,
                              bit [9:0] reg_num, bit [15:0] req_id, output pcie_tlp_seq_item cpl);
    pcie_tlp_seq_item item;
    item = pcie_tlp_seq_item::type_id::create("cfg_rd");
    start_item(item);
    if (!item.randomize() with {
      opcode == TLP_CFG_READ;
      fmt == FMT_3DW_NO_DATA;
      is_4dw_hdr == 0;
      cfg_bus == bus; cfg_device == dev; cfg_function == func; cfg_register == reg_num;
      requester_id == req_id;
      length_dw == 1;
    }) `uvm_error(get_name(), "Randomization failed for cfg_read")
    finish_item(item);
    cpl = item;
  endtask

  virtual task body();
    // Base sequence is intentionally empty; extend and call the
    // do_mem_*/do_cfg_* helper tasks above from derived test sequences.
  endtask
endclass : pcie_tlp_rc_base_seq

`endif
