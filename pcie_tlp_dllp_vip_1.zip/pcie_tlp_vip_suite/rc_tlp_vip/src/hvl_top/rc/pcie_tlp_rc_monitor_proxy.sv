`ifndef PCIE_TLP_RC_MONITOR_PROXY_SV
`define PCIE_TLP_RC_MONITOR_PROXY_SV

class pcie_tlp_rc_monitor_proxy extends uvm_monitor;
  `uvm_component_utils(pcie_tlp_rc_monitor_proxy)

  virtual pcie_tlp_rc_monitor_bfm bfm;
  pcie_tlp_rc_agent_config        cfg;

  uvm_analysis_port #(pcie_tlp_seq_item) request_ap;
  uvm_analysis_port #(pcie_tlp_seq_item) completion_ap;

  function new(string name = "pcie_tlp_rc_monitor_proxy", uvm_component parent = null);
    super.new(name, parent);
    request_ap    = new("request_ap", this);
    completion_ap = new("completion_ap", this);
  endfunction

  function void build_phase(uvm_phase phase);
    super.build_phase(phase);
    if (!uvm_config_db#(virtual pcie_tlp_rc_monitor_bfm)::get(this, "", "bfm", bfm))
      `uvm_fatal("NOVIF", "virtual pcie_tlp_rc_monitor_bfm not found in config_db")
  endfunction

  task run_phase(uvm_phase phase);
    fork
      collect_requests();
      collect_completions();
    join
  endtask

  task automatic collect_requests();
    forever begin
      pcie_tlp_seq_item item;
      bfm.sample_request(item, pcie_tlp_seq_item::type_id::create("mon_req"));
      request_ap.write(item);
    end
  endtask

  task automatic collect_completions();
    forever begin
      pcie_tlp_seq_item item;
      bfm.sample_completion(item, pcie_tlp_seq_item::type_id::create("mon_cpl"));
      completion_ap.write(item);
    end
  endtask
endclass : pcie_tlp_rc_monitor_proxy

`endif
