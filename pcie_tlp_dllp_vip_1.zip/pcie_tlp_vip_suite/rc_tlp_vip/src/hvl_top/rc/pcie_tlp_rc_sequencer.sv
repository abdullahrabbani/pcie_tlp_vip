`ifndef PCIE_TLP_RC_SEQUENCER_SV
`define PCIE_TLP_RC_SEQUENCER_SV

class pcie_tlp_rc_sequencer extends uvm_sequencer #(pcie_tlp_seq_item);
  `uvm_component_utils(pcie_tlp_rc_sequencer)

  pcie_tlp_rc_agent_config cfg;

  function new(string name = "pcie_tlp_rc_sequencer", uvm_component parent = null);
    super.new(name, parent);
  endfunction
endclass : pcie_tlp_rc_sequencer

`endif
