`ifndef PCIE_TLP_RC_HVL_TOP_SV
`define PCIE_TLP_RC_HVL_TOP_SV

module pcie_tlp_rc_hvl_top;
  import uvm_pkg::*;
  import pcie_tlp_globals_pkg::*;
  import pcie_tlp_rc_pkg::*;
  import pcie_tlp_rc_test_pkg::*;
`include "uvm_macros.svh"

  initial run_test();

endmodule : pcie_tlp_rc_hvl_top

`endif
