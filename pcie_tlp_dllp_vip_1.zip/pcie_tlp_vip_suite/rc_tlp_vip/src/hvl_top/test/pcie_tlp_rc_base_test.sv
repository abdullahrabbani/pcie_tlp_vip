`ifndef PCIE_TLP_RC_BASE_TEST_SV
`define PCIE_TLP_RC_BASE_TEST_SV

class pcie_tlp_rc_base_test extends uvm_test;
  `uvm_component_utils(pcie_tlp_rc_base_test)

  pcie_tlp_rc_agent        rc_agent_h;
  pcie_tlp_rc_agent_config rc_cfg;

  function new(string name = "pcie_tlp_rc_base_test", uvm_component parent = null);
    super.new(name, parent);
  endfunction

  function void build_phase(uvm_phase phase);
    super.build_phase(phase);
    rc_cfg = pcie_tlp_rc_agent_config::type_id::create("rc_cfg");
    rc_cfg.is_active = UVM_ACTIVE;
    uvm_config_db#(pcie_tlp_rc_agent_config)::set(this, "rc_agent_h", "cfg", rc_cfg);
    rc_agent_h = pcie_tlp_rc_agent::type_id::create("rc_agent_h", this);
  endfunction

  function void end_of_elaboration_phase(uvm_phase phase);
    super.end_of_elaboration_phase(phase);
    uvm_top.print_topology();
  endfunction
endclass : pcie_tlp_rc_base_test

`endif
