`ifndef PCIE_TLP_RC_TEST_PKG_SV
`define PCIE_TLP_RC_TEST_PKG_SV

package pcie_tlp_rc_test_pkg;
  import uvm_pkg::*;
  import pcie_tlp_globals_pkg::*;
  import pcie_tlp_rc_pkg::*;
`include "uvm_macros.svh"

`include "pcie_tlp_rc_base_test.sv"
`include "pcie_tlp_rc_smoke_test.sv"

endpackage : pcie_tlp_rc_test_pkg

`endif
