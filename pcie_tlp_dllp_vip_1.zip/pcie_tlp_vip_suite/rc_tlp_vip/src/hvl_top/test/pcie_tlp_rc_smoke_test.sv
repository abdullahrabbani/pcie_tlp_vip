`ifndef PCIE_TLP_RC_SMOKE_TEST_SV
`define PCIE_TLP_RC_SMOKE_TEST_SV

// Standalone smoke sequence: drives a memory write followed by a memory
// read on the RC agent alone. Useful for compile/elab sanity of the RC
// VIP in isolation (loops back only if something is connected to rx_*).
class pcie_tlp_rc_smoke_seq extends pcie_tlp_rc_base_seq;
  `uvm_object_utils(pcie_tlp_rc_smoke_seq)
  function new(string name = "pcie_tlp_rc_smoke_seq"); super.new(name); endfunction

  virtual task body();
    bit [31:0] wdata[] = '{32'hDEAD_BEEF, 32'hCAFE_F00D};
    pcie_tlp_seq_item cpl;
    do_mem_write(64'h1000_0000, wdata, 16'h0100, 8'h01);
    do_mem_read(64'h1000_0000, 2, 16'h0100, cpl, 8'h02);
  endtask
endclass : pcie_tlp_rc_smoke_seq

class pcie_tlp_rc_smoke_test extends pcie_tlp_rc_base_test;
  `uvm_component_utils(pcie_tlp_rc_smoke_test)
  function new(string name = "pcie_tlp_rc_smoke_test", uvm_component parent = null);
    super.new(name, parent);
  endfunction

  task run_phase(uvm_phase phase);
    pcie_tlp_rc_smoke_seq seq;
    phase.raise_objection(this);
    seq = pcie_tlp_rc_smoke_seq::type_id::create("seq");
    seq.start(rc_agent_h.sequencer_h);
    #100ns;
    phase.drop_objection(this);
  endtask
endclass : pcie_tlp_rc_smoke_test

`endif
