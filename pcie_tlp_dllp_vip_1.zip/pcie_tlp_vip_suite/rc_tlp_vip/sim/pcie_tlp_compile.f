// RC TLP VIP compile file order matters: globals -> interface -> BFMs ->
// assertions -> hdl_top -> hvl packages -> hvl_top.
-timescale 1ns/1ps
+incdir+../src/globals
+incdir+../src/hdl_top/pcie_tlp_interface
+incdir+../src/hdl_top/rc_agent_bfm
+incdir+../src/hvl_top/rc
+incdir+../src/hvl_top/rc/sequences
+incdir+../src/hvl_top/test

../src/globals/pcie_tlp_globals_pkg.sv

../src/hdl_top/pcie_tlp_interface/pcie_tlp_if.sv
../src/hdl_top/rc_agent_bfm/pcie_tlp_rc_driver_bfm.sv
../src/hdl_top/rc_agent_bfm/pcie_tlp_rc_monitor_bfm.sv
../src/hdl_top/rc_agent_bfm/pcie_tlp_rc_agent_bfm.sv
../src/hdl_top/pcie_tlp_rc_assertions.sv
../src/hdl_top/pcie_tlp_rc_hdl_top.sv

../src/hvl_top/rc/pcie_tlp_rc_pkg.sv
../src/hvl_top/test/pcie_tlp_rc_test_pkg.sv
../src/hvl_top/pcie_tlp_rc_hvl_top.sv
