# RC TLP VIP

Standalone Root Complex PCIe Transaction-Layer-Packet VIP. Generates
Memory/Config Read/Write requests (posted and non-posted), receives and
checks Completions, and exposes a generic `pcie_tlp_if` boundary that can
connect to a peer EP VIP, an Endpoint DUT, or a DLL VIP.

## Compile order

See `sim/pcie_tlp_compile.f`. Summary: globals pkg -> `pcie_tlp_if` -> RC
BFMs -> RC assertions -> `pcie_tlp_rc_hdl_top` -> RC pkg -> RC test pkg ->
`pcie_tlp_rc_hvl_top`.

## Run (standalone smoke test)

```bash
cd sim
make SIM=questa TEST=pcie_tlp_rc_smoke_test
```

Standalone runs only drive `tx_*`; without something connected to
`rx_*`, non-posted requests will hit the completion timeout in
`pcie_tlp_rc_driver_proxy` -- that is expected when running the RC VIP in
isolation. Connect it to the EP VIP (`env/`) or a DUT for full request/
completion checking.

## Key files

| File | Purpose |
|---|---|
| `src/globals/pcie_tlp_globals_pkg.sv` | `pcie_tlp_seq_item`, enums, callbacks base |
| `src/hdl_top/pcie_tlp_interface/pcie_tlp_if.sv` | generic TX/RX streaming boundary |
| `src/hdl_top/rc_agent_bfm/` | driver/monitor BFMs, agent BFM wrapper |
| `src/hvl_top/rc/` | agent, agent_config, sequencer, driver_proxy, monitor_proxy, coverage |
| `src/hvl_top/rc/sequences/pcie_tlp_rc_base_seq.sv` | `do_mem_write/read`, `do_cfg_write/read` task library |
| `src/hvl_top/test/` | standalone base/smoke tests |

## Configuration knobs (`pcie_tlp_rc_agent_config`)

`is_active`, `addr_width` (32/64-bit), `requester_id`,
`max_payload_size_bytes`, `max_read_req_size_bytes`,
`completion_timeout_ns`, `error_injection_enable`.

## Extending

Add new opcodes in `pcie_tlp_globals_pkg::pcie_tlp_opcode_e` and update
`pack_header`/`unpack_header` together; add a builder task to
`pcie_tlp_rc_base_seq`; add a coverpoint in `pcie_tlp_rc_coverage`.
