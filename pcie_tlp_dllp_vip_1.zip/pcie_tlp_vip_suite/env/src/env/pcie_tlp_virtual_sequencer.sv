`ifndef PCIE_TLP_VIRTUAL_SEQUENCER_SV
`define PCIE_TLP_VIRTUAL_SEQUENCER_SV

class pcie_tlp_virtual_sequencer extends uvm_sequencer;
  `uvm_component_utils(pcie_tlp_virtual_sequencer)

  pcie_tlp_rc_sequencer rc_sequencer_h;
  pcie_tlp_ep_sequencer ep_sequencer_h;

  function new(string name = "pcie_tlp_virtual_sequencer", uvm_component parent = null);
    super.new(name, parent);
  endfunction
endclass : pcie_tlp_virtual_sequencer

`endif
