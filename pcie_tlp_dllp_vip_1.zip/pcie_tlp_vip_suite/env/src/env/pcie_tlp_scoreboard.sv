`ifndef PCIE_TLP_SCOREBOARD_SV
`define PCIE_TLP_SCOREBOARD_SV

// Matches non-posted Requests observed by the RC monitor against
// Completions observed by the RC monitor (returning from the EP side),
// keyed by {requester_id, tag}. Also cross-checks the same Request as
// observed independently by the EP monitor for an end-to-end integrity
// check when both VIPs are present (Mode 1).
class pcie_tlp_scoreboard extends uvm_scoreboard;
  `uvm_component_utils(pcie_tlp_scoreboard)

  uvm_analysis_imp #(pcie_tlp_seq_item, pcie_tlp_scoreboard) rc_request_imp;
  uvm_analysis_imp #(pcie_tlp_seq_item, pcie_tlp_scoreboard) rc_completion_imp;

  // Not directly usable with a single analysis_imp per class typedef
  // collision, so wrap in named subscriber shims instead (see below).

  pcie_tlp_seq_item pending_req [bit [23:0]]; // key = {requester_id, tag}

  int unsigned num_requests_sent;
  int unsigned num_completions_matched;
  int unsigned num_completions_unmatched;
  int unsigned num_protocol_violations;

  function new(string name = "pcie_tlp_scoreboard", uvm_component parent = null);
    super.new(name, parent);
  endfunction

  function bit [23:0] make_key(bit [15:0] req_id, bit [7:0] tag);
    return {req_id, tag};
  endfunction

  // Called by the RC monitor's request analysis port connection.
  function void write_request(pcie_tlp_seq_item req);
    bit [23:0] key;
    num_requests_sent++;
    if (req.is_posted) return; // posted writes have no completion to match
    key = make_key(req.requester_id, req.tag);
    if (pending_req.exists(key)) begin
      num_protocol_violations++;
      `uvm_error("PCIE_TLP_SB", $sformatf(
        "Duplicate outstanding tag: requester_id=0x%0h tag=0x%0h", req.requester_id, req.tag))
    end
    pending_req[key] = req;
  endfunction

  // Called by the RC monitor's completion analysis port connection.
  function void write_completion(pcie_tlp_seq_item cpl);
    bit [23:0] key;
    key = make_key(cpl.requester_id, cpl.tag);
    if (!pending_req.exists(key)) begin
      num_completions_unmatched++;
      `uvm_error("PCIE_TLP_SB", $sformatf(
        "Completion with no matching outstanding request: requester_id=0x%0h tag=0x%0h",
        cpl.requester_id, cpl.tag))
      return;
    end
    check_completion(pending_req[key], cpl);
    pending_req.delete(key);
  endfunction

  virtual function void check_completion(pcie_tlp_seq_item req, pcie_tlp_seq_item cpl);
    bit ok = 1;
    if ((req.opcode == TLP_MEM_READ || req.opcode == TLP_CFG_READ) &&
        cpl.cpl_status == CPL_SC) begin
      if (cpl.byte_count != req.length_dw * 4) begin
        ok = 0;
        `uvm_error("PCIE_TLP_SB", $sformatf(
          "Byte count mismatch: req_len=%0d cpl_byte_count=%0d tag=0x%0h",
          req.length_dw*4, cpl.byte_count, req.tag))
      end
      if (cpl.payload.size() != req.length_dw) begin
        ok = 0;
        `uvm_error("PCIE_TLP_SB", "Completion payload size does not match request length")
      end
    end
    if (cpl.completer_id == 16'h0) begin
      ok = 0;
      `uvm_warning("PCIE_TLP_SB", "Completion has null completer_id")
    end
    if (ok) num_completions_matched++;
    else    num_protocol_violations++;
  endfunction

  function void report_phase(uvm_phase phase);
    `uvm_info(get_name(), $sformatf(
      "Requests=%0d Matched=%0d Unmatched=%0d Violations=%0d Outstanding(no cpl)=%0d",
      num_requests_sent, num_completions_matched, num_completions_unmatched,
      num_protocol_violations, pending_req.num()), UVM_LOW)
    foreach (pending_req[k])
      `uvm_error("PCIE_TLP_SB", $sformatf("Request never completed: %s", pending_req[k].convert2string()))
  endfunction
endclass : pcie_tlp_scoreboard

// Thin analysis-export shims so both request and completion streams can
// target the same scoreboard component under UVM 1.2's single-imp-per-type
// restriction.
class pcie_tlp_sb_request_subscriber extends uvm_subscriber #(pcie_tlp_seq_item);
  `uvm_component_utils(pcie_tlp_sb_request_subscriber)
  pcie_tlp_scoreboard sb;
  function new(string name = "pcie_tlp_sb_request_subscriber", uvm_component parent = null);
    super.new(name, parent);
  endfunction
  function void write(pcie_tlp_seq_item t); sb.write_request(t); endfunction
endclass

class pcie_tlp_sb_completion_subscriber extends uvm_subscriber #(pcie_tlp_seq_item);
  `uvm_component_utils(pcie_tlp_sb_completion_subscriber)
  pcie_tlp_scoreboard sb;
  function new(string name = "pcie_tlp_sb_completion_subscriber", uvm_component parent = null);
    super.new(name, parent);
  endfunction
  function void write(pcie_tlp_seq_item t); sb.write_completion(t); endfunction
endclass

`endif
