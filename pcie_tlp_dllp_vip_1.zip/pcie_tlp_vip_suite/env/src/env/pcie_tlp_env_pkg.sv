`ifndef PCIE_TLP_ENV_PKG_SV
`define PCIE_TLP_ENV_PKG_SV

package pcie_tlp_env_pkg;
  import uvm_pkg::*;
  import pcie_tlp_globals_pkg::*;
  import pcie_tlp_rc_pkg::*;
  import pcie_tlp_ep_pkg::*;
`include "uvm_macros.svh"

`include "pcie_tlp_env_config.sv"
`include "pcie_tlp_virtual_sequencer.sv"
`include "pcie_tlp_scoreboard.sv"
`include "pcie_tlp_env.sv"

endpackage : pcie_tlp_env_pkg

`endif
