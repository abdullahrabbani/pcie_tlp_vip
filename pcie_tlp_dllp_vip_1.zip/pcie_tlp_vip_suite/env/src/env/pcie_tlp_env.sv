`ifndef PCIE_TLP_ENV_SV
`define PCIE_TLP_ENV_SV

// Top-level integration environment. Instantiates whichever agents the
// configured mode requires:
//   MODE_VIP_TO_VIP    : RC agent (active) + EP agent (active)
//   MODE_VIP_TO_EP_DUT : RC agent (active) only, DUT is the EP
//   MODE_RC_DUT_TO_VIP : EP agent (active) only, DUT is the RC
//   MODE_WITH_DLL      : either/both agents, DLL VIP connects below vif
// Scoreboard is only meaningful when the RC agent is present (it observes
// the RC side of the link, matching requests-to-completions).
class pcie_tlp_env extends uvm_env;
  `uvm_component_utils(pcie_tlp_env)

  pcie_tlp_env_config       cfg;
  pcie_tlp_rc_agent         rc_agent_h;
  pcie_tlp_ep_agent         ep_agent_h;
  pcie_tlp_virtual_sequencer virtual_sequencer_h;
  pcie_tlp_scoreboard        scoreboard_h;
  pcie_tlp_sb_request_subscriber    sb_req_sub_h;
  pcie_tlp_sb_completion_subscriber sb_cpl_sub_h;

  function new(string name = "pcie_tlp_env", uvm_component parent = null);
    super.new(name, parent);
  endfunction

  function void build_phase(uvm_phase phase);
    super.build_phase(phase);
    if (!uvm_config_db#(pcie_tlp_env_config)::get(this, "", "cfg", cfg))
      `uvm_fatal("NOCFG", "pcie_tlp_env_config not found in config_db")

    if (cfg.has_rc_agent) begin
      uvm_config_db#(pcie_tlp_rc_agent_config)::set(this, "rc_agent_h", "cfg", cfg.rc_cfg);
      rc_agent_h = pcie_tlp_rc_agent::type_id::create("rc_agent_h", this);
    end
    if (cfg.has_ep_agent) begin
      uvm_config_db#(pcie_tlp_ep_agent_config)::set(this, "ep_agent_h", "cfg", cfg.ep_cfg);
      ep_agent_h = pcie_tlp_ep_agent::type_id::create("ep_agent_h", this);
    end

    virtual_sequencer_h = pcie_tlp_virtual_sequencer::type_id::create("virtual_sequencer_h", this);

    if (cfg.scoreboard_enable && cfg.has_rc_agent) begin
      scoreboard_h  = pcie_tlp_scoreboard::type_id::create("scoreboard_h", this);
      sb_req_sub_h  = pcie_tlp_sb_request_subscriber::type_id::create("sb_req_sub_h", this);
      sb_cpl_sub_h  = pcie_tlp_sb_completion_subscriber::type_id::create("sb_cpl_sub_h", this);
    end
  endfunction

  function void connect_phase(uvm_phase phase);
    super.connect_phase(phase);
    if (cfg.has_rc_agent && rc_agent_h.is_active == UVM_ACTIVE)
      virtual_sequencer_h.rc_sequencer_h = rc_agent_h.sequencer_h;
    if (cfg.has_ep_agent && ep_agent_h.is_active == UVM_ACTIVE)
      virtual_sequencer_h.ep_sequencer_h = ep_agent_h.sequencer_h;

    if (scoreboard_h != null) begin
      sb_req_sub_h.sb = scoreboard_h;
      sb_cpl_sub_h.sb = scoreboard_h;
      rc_agent_h.request_ap.connect(sb_req_sub_h.analysis_export);
      rc_agent_h.completion_ap.connect(sb_cpl_sub_h.analysis_export);
    end
  endfunction
endclass : pcie_tlp_env

`endif
