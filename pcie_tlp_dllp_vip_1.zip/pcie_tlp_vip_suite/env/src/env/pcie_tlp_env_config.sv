`ifndef PCIE_TLP_ENV_CONFIG_SV
`define PCIE_TLP_ENV_CONFIG_SV

// Selects which side(s) of the link are driven by VIP vs. left to a DUT,
// and whether a DLL layer sits between the TLP VIP(s) and the link.
typedef enum {
  MODE_VIP_TO_VIP,   // RC VIP <-> EP VIP directly
  MODE_VIP_TO_EP_DUT, // RC VIP <-> Endpoint DUT
  MODE_RC_DUT_TO_VIP, // RC DUT <-> EP VIP
  MODE_WITH_DLL       // RC/EP VIP <-> DLL VIP <-> PHY(future)
} pcie_tlp_env_mode_e;

class pcie_tlp_env_config extends uvm_object;
  `uvm_object_utils(pcie_tlp_env_config)

  pcie_tlp_env_mode_e      mode = MODE_VIP_TO_VIP;
  bit                      has_rc_agent = 1;
  bit                      has_ep_agent = 1;
  pcie_tlp_rc_agent_config rc_cfg;
  pcie_tlp_ep_agent_config ep_cfg;
  bit                      scoreboard_enable = 1;

  function new(string name = "pcie_tlp_env_config");
    super.new(name);
  endfunction
endclass : pcie_tlp_env_config

`endif
