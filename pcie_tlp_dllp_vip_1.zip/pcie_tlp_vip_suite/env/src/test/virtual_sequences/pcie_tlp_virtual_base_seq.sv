`ifndef PCIE_TLP_VIRTUAL_BASE_SEQ_SV
`define PCIE_TLP_VIRTUAL_BASE_SEQ_SV

class pcie_tlp_virtual_base_seq extends uvm_sequence;
  `uvm_object_utils(pcie_tlp_virtual_base_seq)
  `uvm_declare_p_sequencer(pcie_tlp_virtual_sequencer)

  function new(string name = "pcie_tlp_virtual_base_seq");
    super.new(name);
  endfunction

  virtual task body();
    // Extend to orchestrate RC + EP sequencers together, e.g. seed the
    // EP memory model via a directed EP sequence before issuing RC reads.
  endtask
endclass : pcie_tlp_virtual_base_seq

`endif
