`ifndef PCIE_TLP_MEM_READ_TEST_SV
`define PCIE_TLP_MEM_READ_TEST_SV

class pcie_tlp_mem_read_seq extends pcie_tlp_rc_base_seq;
  `uvm_object_utils(pcie_tlp_mem_read_seq)
  function new(string name = "pcie_tlp_mem_read_seq"); super.new(name); endfunction

  virtual task body();
    bit [31:0] wdata[] = '{32'hDEAD_BEEF, 32'hCAFE_F00D, 32'h1234_5678, 32'h9ABC_DEF0};
    pcie_tlp_seq_item cpl;
    do_mem_write(64'h1000_0000, wdata, 16'h0100, 8'h10);
    do_mem_read(64'h1000_0000, 4, 16'h0100, cpl, 8'h11);
    if (cpl.cpl_status == CPL_SC && cpl.payload.size() == 4) begin
      foreach (wdata[i])
        if (cpl.payload[i] !== wdata[i])
          `uvm_error(get_name(), $sformatf("Readback mismatch at dw%0d: exp=0x%0h got=0x%0h",
                     i, wdata[i], cpl.payload[i]))
    end
    else
      `uvm_error(get_name(), $sformatf("Unexpected completion status %s or size %0d",
                 cpl.cpl_status.name(), cpl.payload.size()))
  endtask
endclass : pcie_tlp_mem_read_seq

class pcie_tlp_mem_read_test extends pcie_tlp_base_test;
  `uvm_component_utils(pcie_tlp_mem_read_test)
  function new(string name = "pcie_tlp_mem_read_test", uvm_component parent = null);
    super.new(name, parent);
  endfunction

  task run_phase(uvm_phase phase);
    pcie_tlp_mem_read_seq seq;
    phase.raise_objection(this);
    seq = pcie_tlp_mem_read_seq::type_id::create("seq");
    seq.start(env_h.rc_agent_h.sequencer_h);
    #500ns;
    phase.drop_objection(this);
  endtask
endclass : pcie_tlp_mem_read_test

`endif
