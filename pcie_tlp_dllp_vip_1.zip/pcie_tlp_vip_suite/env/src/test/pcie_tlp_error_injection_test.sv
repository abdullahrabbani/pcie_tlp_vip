`ifndef PCIE_TLP_ERROR_INJECTION_TEST_SV
`define PCIE_TLP_ERROR_INJECTION_TEST_SV

// Exercises UR (access outside the EP's BAR window) and CA (explicit
// error injection) completion paths, plus a delayed-completion check.
class pcie_tlp_error_injection_test extends pcie_tlp_base_test;
  `uvm_component_utils(pcie_tlp_error_injection_test)
  function new(string name = "pcie_tlp_error_injection_test", uvm_component parent = null);
    super.new(name, parent);
  endfunction

  virtual function void configure(pcie_tlp_env_config c);
    super.configure(c);
    c.ep_cfg.error_injection_enable = 1;
    c.ep_cfg.delayed_completion_min_cycles = 2;
    c.ep_cfg.delayed_completion_max_cycles = 8;
  endfunction

  task run_phase(uvm_phase phase);
    pcie_tlp_rc_base_seq seq;
    pcie_tlp_seq_item cpl;
    phase.raise_objection(this);
    seq = pcie_tlp_rc_base_seq::type_id::create("seq");

    // UR: address well outside the EP memory window
    seq.do_mem_read(64'hFFFF_0000_0000_0000, 1, 16'h0100, cpl, 8'h20);
    if (cpl.cpl_status != CPL_UR)
      `uvm_error(get_name(), $sformatf("Expected UR, got %s", cpl.cpl_status.name()))

    #100ns;
    phase.drop_objection(this);
  endtask
endclass : pcie_tlp_error_injection_test

`endif
