`ifndef PCIE_TLP_CFG_ACCESS_TEST_SV
`define PCIE_TLP_CFG_ACCESS_TEST_SV

class pcie_tlp_cfg_access_seq extends pcie_tlp_rc_base_seq;
  `uvm_object_utils(pcie_tlp_cfg_access_seq)
  function new(string name = "pcie_tlp_cfg_access_seq"); super.new(name); endfunction

  virtual task body();
    pcie_tlp_seq_item cpl;
    do_cfg_write(8'h00, 5'h00, 3'h0, 10'h004, 32'h0000_0007, 16'h0100); // command reg
    do_cfg_read(8'h00, 5'h00, 3'h0, 10'h000, 16'h0100, cpl);            // vendor/device id
    `uvm_info(get_name(), $sformatf("Cfg read completion: %s payload[0]=0x%0h",
              cpl.convert2string(), cpl.payload.size() ? cpl.payload[0] : 32'h0), UVM_LOW)
  endtask
endclass : pcie_tlp_cfg_access_seq

class pcie_tlp_cfg_access_test extends pcie_tlp_base_test;
  `uvm_component_utils(pcie_tlp_cfg_access_test)
  function new(string name = "pcie_tlp_cfg_access_test", uvm_component parent = null);
    super.new(name, parent);
  endfunction

  task run_phase(uvm_phase phase);
    pcie_tlp_cfg_access_seq seq;
    phase.raise_objection(this);
    seq = pcie_tlp_cfg_access_seq::type_id::create("seq");
    seq.start(env_h.rc_agent_h.sequencer_h);
    #200ns;
    phase.drop_objection(this);
  endtask
endclass : pcie_tlp_cfg_access_test

`endif
