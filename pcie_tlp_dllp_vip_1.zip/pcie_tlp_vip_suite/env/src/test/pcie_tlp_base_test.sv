`ifndef PCIE_TLP_BASE_TEST_SV
`define PCIE_TLP_BASE_TEST_SV

class pcie_tlp_base_test extends uvm_test;
  `uvm_component_utils(pcie_tlp_base_test)

  pcie_tlp_env        env_h;
  pcie_tlp_env_config  env_cfg;

  function new(string name = "pcie_tlp_base_test", uvm_component parent = null);
    super.new(name, parent);
  endfunction

  function void build_phase(uvm_phase phase);
    super.build_phase(phase);
    env_cfg = pcie_tlp_env_config::type_id::create("env_cfg");
    configure(env_cfg);
    uvm_config_db#(pcie_tlp_env_config)::set(this, "env_h", "cfg", env_cfg);
    env_h = pcie_tlp_env::type_id::create("env_h", this);
  endfunction

  // Override per test/mode. Default = VIP-to-VIP, both agents active.
  virtual function void configure(pcie_tlp_env_config c);
    c.mode = MODE_VIP_TO_VIP;
    c.has_rc_agent = 1;
    c.has_ep_agent = 1;

    c.rc_cfg = pcie_tlp_rc_agent_config::type_id::create("rc_cfg");
    c.rc_cfg.is_active = UVM_ACTIVE;

    c.ep_cfg = pcie_tlp_ep_agent_config::type_id::create("ep_cfg");
    c.ep_cfg.is_active = UVM_ACTIVE;
  endfunction

  function void end_of_elaboration_phase(uvm_phase phase);
    super.end_of_elaboration_phase(phase);
    uvm_top.print_topology();
  endfunction
endclass : pcie_tlp_base_test

`endif
