`ifndef PCIE_TLP_MEM_WRITE_TEST_SV
`define PCIE_TLP_MEM_WRITE_TEST_SV

class pcie_tlp_mem_write_seq extends pcie_tlp_rc_base_seq;
  `uvm_object_utils(pcie_tlp_mem_write_seq)
  function new(string name = "pcie_tlp_mem_write_seq"); super.new(name); endfunction

  virtual task body();
    bit [31:0] wdata[];
    repeat (10) begin
      int unsigned len = $urandom_range(1, 16);
      wdata = new[len];
      foreach (wdata[i]) wdata[i] = $urandom();
      do_mem_write($urandom_range(0,1) ? 64'h1000_0000 + ($urandom_range(0,255)*4)
                                        : 64'h1_0000_0000 + ($urandom_range(0,255)*4),
                    wdata, 16'h0100, $urandom());
    end
  endtask
endclass : pcie_tlp_mem_write_seq

class pcie_tlp_mem_write_test extends pcie_tlp_base_test;
  `uvm_component_utils(pcie_tlp_mem_write_test)
  function new(string name = "pcie_tlp_mem_write_test", uvm_component parent = null);
    super.new(name, parent);
  endfunction

  task run_phase(uvm_phase phase);
    pcie_tlp_mem_write_seq seq;
    phase.raise_objection(this);
    seq = pcie_tlp_mem_write_seq::type_id::create("seq");
    seq.start(env_h.rc_agent_h.sequencer_h);
    #500ns;
    phase.drop_objection(this);
  endtask
endclass : pcie_tlp_mem_write_test

`endif
