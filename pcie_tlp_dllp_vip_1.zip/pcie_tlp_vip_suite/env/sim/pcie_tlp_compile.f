// VIP-to-VIP (Mode 1) integration compile order: globals -> interface ->
// RC BFMs -> EP BFMs -> assertions -> env hdl_top -> RC pkg -> EP pkg ->
// env pkg -> test pkg -> env hvl_top.
-timescale 1ns/1ps
+incdir+../../rc_tlp_vip/src/globals
+incdir+../../rc_tlp_vip/src/hdl_top/pcie_tlp_interface
+incdir+../../rc_tlp_vip/src/hdl_top/rc_agent_bfm
+incdir+../../rc_tlp_vip/src/hvl_top/rc
+incdir+../../rc_tlp_vip/src/hvl_top/rc/sequences
+incdir+../../ep_tlp_vip/src/hdl_top/ep_agent_bfm
+incdir+../../ep_tlp_vip/src/hvl_top/ep
+incdir+../../ep_tlp_vip/src/hvl_top/ep/sequences
+incdir+../src/env
+incdir+../src/test
+incdir+../src/test/virtual_sequences

../../rc_tlp_vip/src/globals/pcie_tlp_globals_pkg.sv

../../rc_tlp_vip/src/hdl_top/pcie_tlp_interface/pcie_tlp_if.sv
../../rc_tlp_vip/src/hdl_top/rc_agent_bfm/pcie_tlp_rc_driver_bfm.sv
../../rc_tlp_vip/src/hdl_top/rc_agent_bfm/pcie_tlp_rc_monitor_bfm.sv
../../rc_tlp_vip/src/hdl_top/rc_agent_bfm/pcie_tlp_rc_agent_bfm.sv
../../rc_tlp_vip/src/hdl_top/pcie_tlp_rc_assertions.sv

../../ep_tlp_vip/src/hdl_top/ep_agent_bfm/pcie_tlp_ep_driver_bfm.sv
../../ep_tlp_vip/src/hdl_top/ep_agent_bfm/pcie_tlp_ep_monitor_bfm.sv
../../ep_tlp_vip/src/hdl_top/ep_agent_bfm/pcie_tlp_ep_agent_bfm.sv
../../ep_tlp_vip/src/hdl_top/pcie_tlp_ep_assertions.sv

../src/hdl_top/pcie_tlp_env_hdl_top.sv

../../rc_tlp_vip/src/hvl_top/rc/pcie_tlp_rc_pkg.sv
../../ep_tlp_vip/src/hvl_top/ep/pcie_tlp_ep_pkg.sv
../src/env/pcie_tlp_env_pkg.sv
../src/test/pcie_tlp_test_pkg.sv
../src/hvl_top/pcie_tlp_env_hvl_top.sv
