# PCIe TLP VIP Suite

A reusable, UVM-1.2 based PCIe Transaction-Layer-Packet Verification IP,
delivered as two **independent** VIPs -- `rc_tlp_vip` (Root Complex) and
`ep_tlp_vip` (Endpoint) -- plus an `env/` integration package and worked
examples for every supported topology.

## Directory map

```
pcie_tlp_vip_suite/
├── rc_tlp_vip/        # standalone RC VIP (own docs/src/sim, compiles alone)
├── ep_tlp_vip/         # standalone EP VIP (own docs/src/sim, compiles alone)
├── env/                 # RC+EP integration: env, virtual sequencer, scoreboard, tests
├── pcie_dll_vip/        # scaffolded DLL model: seq num, replay, ACK/NAK, credits (see its own README)
├── examples/
│   ├── vip_to_vip/     # Mode 1: RC VIP <-> EP VIP
│   ├── vip_to_dut/     # Mode 2: RC VIP <-> Endpoint DUT (or RC DUT <-> EP VIP, symmetric)
│   └── vip_to_dll/     # RC/EP VIP <-> DLL boundary (future DLL VIP slot)
└── docs/                # architecture, verification/coverage/assertion plans, user guide
```

Each VIP's own top-level README, `coding_guidelines.md`,
`contribution_guidelines.md`, and `LICENSE.md` are duplicated inside
`rc_tlp_vip/` and `ep_tlp_vip/` so either directory can be copied out and
used standalone in another project without depending on this suite
structure.

## What's here vs. what's a stand-in

This deliverable includes real, elaboration-ready UVM 1.2 SystemVerilog
(interfaces, BFMs, agents, sequences, scoreboard, tests) and full written
documentation (architecture, verification/coverage/assertion plans, user
guide) as Markdown with Mermaid diagrams for the block/flow/sequence
diagrams. It does **not** include an actual narrated video walkthrough or
a binary-typeset PDF/PPT -- those weren't things this environment can
produce meaningfully, so `docs/` contains the equivalent written content
instead; render the Mermaid blocks or paste the Markdown into a PDF/slide
tool if you need those formats.

## Requirement-to-deliverable map

| Requirement | Where |
|---|---|
| Two independent VIPs (RC, EP) | `rc_tlp_vip/`, `ep_tlp_vip/` |
| Agent (active/passive), coverage, analysis ports, callbacks | `*_agent.sv`, `*_coverage.sv`, `request_ap`/`completion_ap` on every agent, `pcie_tlp_callbacks` in globals pkg used via `\`uvm_do_callbacks` in both driver_proxies |
| Mode 1: VIP-to-VIP | `env/` (default config), `examples/vip_to_vip/` |
| Mode 2: VIP-to-DUT (either side) | `examples/vip_to_dut/` |
| DLL boundary, no ACK/NAK/replay/credits in TLP VIP | `pcie_tlp_if.sv` (identical in both VIPs), `examples/vip_to_dll/` |
| DLL scaffold (seq num, replay buffer, ACK/NAK, credit-based FC) | `pcie_dll_vip/` -- agent-structured (agent_bfm/driver_bfm + driver_proxy/monitor_proxy/coverage), functional but simplified; see its README for what's modeled vs. deferred |
| RC features (mem/cfg, posted/non-posted, 3DW/4DW, payload, configurable IDs) | `pcie_tlp_seq_item` + `pcie_tlp_rc_base_seq` |
| EP features (decode, memory model, completions incl. UR/CA/CRS, delayed/error-injected) | `pcie_tlp_ep_memory.sv`, `pcie_tlp_ep_driver_proxy.sv` |
| Scoreboard: tag/ID/byte-count/payload/status/ordering, violation reporting | `env/src/env/pcie_tlp_scoreboard.sv` |
| Configuration: active/passive, mode, addr width, MPS, MRRS, timeout, error injection | `pcie_tlp_rc_agent_config.sv`, `pcie_tlp_ep_agent_config.sv`, `pcie_tlp_env_config.sv` |
| Diagrams (block/flow/sequence) | `docs/pcie_architecture_document.md` (Mermaid) |
| Example tests | `env/src/test/pcie_tlp_mem_write_test.sv`, `pcie_tlp_mem_read_test.sv`, `pcie_tlp_cfg_access_test.sv`, `pcie_tlp_error_injection_test.sv` |

## Quick start

```bash
cd env/sim
make SIM=questa TEST=pcie_tlp_mem_read_test
```

See `docs/pcie_user_guide.md` for full instructions, and each VIP's own
`README.md` for standalone-compile instructions.
