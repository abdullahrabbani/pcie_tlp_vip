# EP TLP VIP

Standalone Endpoint PCIe Transaction-Layer-Packet VIP. Decodes incoming
Request TLPs against an internal memory/config-space model
(`pcie_tlp_ep_memory`), and auto-generates Completions (Successful,
Unsupported Request, Completer Abort, with/without data), with
configurable delayed-completion and error-injection behavior. Exposes the
same generic `pcie_tlp_if` boundary as the RC VIP.

## Compile order

See `sim/pcie_tlp_compile.f`. Summary: globals pkg -> `pcie_tlp_if` -> EP
BFMs -> EP assertions -> `pcie_tlp_ep_hdl_top` -> EP pkg -> EP test pkg ->
`pcie_tlp_ep_hvl_top`.

## Run (standalone base test)

```bash
cd sim
make SIM=questa TEST=pcie_tlp_ep_base_test
```

The EP agent is a responder: with nothing driving `rx_*`, it simply idles
waiting for a request. Connect it to the RC VIP (`env/`) or an RC DUT to
exercise the completion-generation logic.

## Key files

| File | Purpose |
|---|---|
| `src/globals/pcie_tlp_globals_pkg.sv` | shared `pcie_tlp_seq_item`, enums, callbacks base |
| `src/hdl_top/pcie_tlp_interface/pcie_tlp_if.sv` | generic TX/RX streaming boundary |
| `src/hdl_top/ep_agent_bfm/` | driver/monitor BFMs, agent BFM wrapper |
| `src/hvl_top/ep/pcie_tlp_ep_memory.sv` | sparse byte memory + config-space model, BAR decode |
| `src/hvl_top/ep/pcie_tlp_ep_driver_proxy.sv` | request decode + completion policy (SC/UR/CA, delay, error inject) |
| `src/hvl_top/ep/` | agent, agent_config, sequencer, monitor_proxy, coverage |

## Configuration knobs (`pcie_tlp_ep_agent_config`)

`is_active`, `addr_width`, `completer_id`, `max_payload_size_bytes`,
`max_read_req_size_bytes`, `mem_size_bytes`, `error_injection_enable`,
`delayed_completion_min_cycles`/`max_cycles`.

## Completion policy

Implemented in `pcie_tlp_ep_driver_proxy::build_completion()`:
1. `error_injection_enable && req.inject_error` -> Completer Abort.
2. Address (or, for config, always) outside the modeled window ->
   Unsupported Request.
3. Otherwise -> Successful Completion, with data for reads/config reads.

Extend this function for CRS (Configuration Request Retry Status) on a
specific register range, or to model additional error classes.
