-timescale 1ns/1ps
+incdir+../src/globals
+incdir+../src/hdl_top/pcie_tlp_interface
+incdir+../src/hdl_top/ep_agent_bfm
+incdir+../src/hvl_top/ep
+incdir+../src/hvl_top/ep/sequences
+incdir+../src/hvl_top/test

../src/globals/pcie_tlp_globals_pkg.sv

../src/hdl_top/pcie_tlp_interface/pcie_tlp_if.sv
../src/hdl_top/ep_agent_bfm/pcie_tlp_ep_driver_bfm.sv
../src/hdl_top/ep_agent_bfm/pcie_tlp_ep_monitor_bfm.sv
../src/hdl_top/ep_agent_bfm/pcie_tlp_ep_agent_bfm.sv
../src/hdl_top/pcie_tlp_ep_assertions.sv
../src/hdl_top/pcie_tlp_ep_hdl_top.sv

../src/hvl_top/ep/pcie_tlp_ep_pkg.sv
../src/hvl_top/test/pcie_tlp_ep_test_pkg.sv
../src/hvl_top/pcie_tlp_ep_hvl_top.sv
