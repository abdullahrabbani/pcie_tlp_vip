#!/usr/bin/env python3
"""
regression_handling.py - runs the RC TLP VIP regression list and reports
PASS/FAIL per test, mirroring pcie_tlp_regression.list.

Usage:
    python3 regression_handling.py --sim questa [--list ../../ep_tlp_vip/src/hvl_top/testlists/pcie_tlp_regression.list]
"""
import argparse
import subprocess
import sys
import os
import re

def parse_args():
    p = argparse.ArgumentParser()
    p.add_argument("--sim", default="questa", choices=["questa", "cadence", "synopsys"])
    p.add_argument("--list", default=None, help="path to regression .list file")
    p.add_argument("--dry-run", action="store_true")
    return p.parse_args()

def load_tests(list_path):
    tests = []
    with open(list_path) as f:
        for line in f:
            line = line.strip()
            if not line or line.startswith("//") or line.startswith("#"):
                continue
            m = re.match(r"^(\S+)\s*(seed=(\d+))?", line)
            if m:
                tests.append((m.group(1), m.group(3) or "1"))
    return tests

def run_test(sim, test, seed, dry_run):
    sim_dir = {"questa": "questasim", "cadence": "cadence_sim", "synopsys": "synopsys_sim"}[sim]
    cmd = ["make", "-C", sim_dir, "run", f"TEST={test}", f"SEED={seed}"]
    print(f"[REGRESSION] {' '.join(cmd)}")
    if dry_run:
        return "SKIPPED"
    result = subprocess.run(cmd, capture_output=True, text=True)
    log = result.stdout + result.stderr
    if "UVM_ERROR" in log and re.search(r"UVM_ERROR\s*:\s*0", log) is None:
        return "FAIL"
    if result.returncode != 0:
        return "FAIL"
    return "PASS"

def main():
    args = parse_args()
    default_list = os.path.join(os.path.dirname(__file__), "..", "src", "hvl_top",
                                 "testlists", "pcie_tlp_regression.list")
    list_path = args.list or default_list
    tests = load_tests(list_path)
    if not tests:
        print(f"No tests found in {list_path}")
        sys.exit(1)

    results = {}
    for test, seed in tests:
        results[test] = run_test(args.sim, test, seed, args.dry_run)

    print("\n===== REGRESSION SUMMARY =====")
    n_pass = sum(1 for r in results.values() if r == "PASS")
    for test, status in results.items():
        print(f"{status:8s} {test}")
    print(f"\n{n_pass}/{len(results)} tests passed")
    sys.exit(0 if n_pass == len(results) else 1)

if __name__ == "__main__":
    main()
