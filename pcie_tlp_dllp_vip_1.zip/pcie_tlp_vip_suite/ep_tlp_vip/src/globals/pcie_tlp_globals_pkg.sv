//-----------------------------------------------------------------------------
// pcie_tlp_globals_pkg.sv
// Shared type/parameter/transaction definitions for the PCIe TLP VIP.
// This file is identical in rc_tlp_vip and ep_tlp_vip so that either VIP can
// be dropped into a testbench standalone. When both VIPs are used together
// (env/ package) only one copy is compiled.
//-----------------------------------------------------------------------------
`ifndef PCIE_TLP_GLOBALS_PKG_SV
`define PCIE_TLP_GLOBALS_PKG_SV

package pcie_tlp_globals_pkg;

  import uvm_pkg::*;
`include "uvm_macros.svh"

  //---------------------------------------------------------------------
  // TLP Format field (Hdr DW0[30:29] + fmt[28])
  //---------------------------------------------------------------------
  typedef enum bit [1:0] {
    FMT_3DW_NO_DATA = 2'b00,
    FMT_4DW_NO_DATA = 2'b01,
    FMT_3DW_DATA    = 2'b10,
    FMT_4DW_DATA    = 2'b11
  } pcie_tlp_fmt_e;

  //---------------------------------------------------------------------
  // TLP Type field (Hdr DW0[24:19])
  //---------------------------------------------------------------------
  typedef enum bit [4:0] {
    TYPE_MEM_RW   = 5'b00000, // Memory Read / Write (fmt distinguishes RW)
    TYPE_MEM_RDLK = 5'b00001, // Memory Read Locked
    TYPE_IO_RW    = 5'b00010, // IO Read / Write
    TYPE_CFG0_RW  = 5'b00100, // Config Type 0 Read / Write
    TYPE_CFG1_RW  = 5'b00101, // Config Type 1 Read / Write
    TYPE_MSG      = 5'b10000, // Message
    TYPE_CPL      = 5'b01010, // Completion
    TYPE_CPL_LK   = 5'b01011  // Completion Locked
  } pcie_tlp_type_e;

  typedef enum bit {
    REQ_MEM_WRITE = 1,
    REQ_MEM_READ  = 0
  } pcie_tlp_rw_e;

  //---------------------------------------------------------------------
  // Overall transaction opcode as seen by sequences (user facing)
  //---------------------------------------------------------------------
  typedef enum bit [3:0] {
    TLP_MEM_READ,
    TLP_MEM_WRITE,
    TLP_IO_READ,
    TLP_IO_WRITE,
    TLP_CFG_READ,
    TLP_CFG_WRITE,
    TLP_COMPLETION,
    TLP_COMPLETION_DATA,
    TLP_MESSAGE
  } pcie_tlp_opcode_e;

  //---------------------------------------------------------------------
  // Completion status (Cpl Hdr DW1[15:13])
  //---------------------------------------------------------------------
  typedef enum bit [2:0] {
    CPL_SC  = 3'b000, // Successful Completion
    CPL_UR  = 3'b001, // Unsupported Request
    CPL_CRS = 3'b010, // Configuration Request Retry Status
    CPL_CA  = 3'b100  // Completer Abort
  } pcie_tlp_cpl_status_e;

  //---------------------------------------------------------------------
  // Global parameters (overridable by agent config)
  //---------------------------------------------------------------------
  parameter int PCIE_TLP_MAX_PAYLOAD_BYTES_DEFAULT   = 256;
  parameter int PCIE_TLP_MAX_READ_REQ_BYTES_DEFAULT  = 512;
  parameter int PCIE_TLP_DEFAULT_TIMEOUT_NS          = 50000;
  parameter int PCIE_TLP_MAX_PAYLOAD_DW              = 1024; // 4KB / 4

  //---------------------------------------------------------------------
  // Address width mode
  //---------------------------------------------------------------------
  typedef enum bit {
    ADDR_32BIT = 0,
    ADDR_64BIT = 1
  } pcie_tlp_addr_width_e;

  //---------------------------------------------------------------------
  // Agent operating mode
  //---------------------------------------------------------------------
  typedef enum bit {
    UVM_ACTIVE_AGENT_MODE  = 1,
    UVM_PASSIVE_AGENT_MODE = 0
  } pcie_tlp_agent_is_active_e; // mirrors uvm_active_passive_enum, kept local for VIP standalone use

  //=====================================================================
  // pcie_tlp_seq_item : the single transaction class shared by RC and EP
  // VIPs. Represents one TLP (request or completion) at the packet
  // level; the driver BFM handles byte/DW-level streaming to the
  // pcie_tlp_if / DLL boundary.
  //=====================================================================
  class pcie_tlp_seq_item extends uvm_sequence_item;

    // ---- generic header fields ----
    rand pcie_tlp_opcode_e        opcode;
    rand pcie_tlp_fmt_e           fmt;
    rand bit [4:0]                tlp_type;
    rand bit [2:0]                tc;          // Traffic Class
    rand bit                      td;          // TLP digest present (ECRC)
    rand bit                      ep_poison;   // Poisoned data
    rand bit [1:0]                attr;        // Relaxed Ordering / No Snoop
    rand bit [9:0]                length_dw;   // payload length in DWORDs
    rand bit [15:0]                requester_id;
    rand bit [7:0]                 tag;
    rand bit [3:0]                 last_be;
    rand bit [3:0]                 first_be;

    // ---- request address (mem/io) ----
    rand bit                      is_4dw_hdr;
    rand bit [63:0]                address;

    // ---- config request fields ----
    rand bit [7:0]                 cfg_bus;
    rand bit [4:0]                 cfg_device;
    rand bit [2:0]                 cfg_function;
    rand bit [9:0]                 cfg_register;

    // ---- completion fields ----
    rand bit [15:0]                completer_id;
    rand pcie_tlp_cpl_status_e    cpl_status;
    rand bit                      bcm;          // byte count modified
    rand bit [11:0]                byte_count;
    rand bit [6:0]                 lower_address;

    // ---- payload ----
    rand bit [31:0]                payload[];   // one entry per DW, size = length_dw

    // ---- VIP control (not part of the wire format) ----
    rand int unsigned             delay_cycles;     // for delayed completions / injected latency
    rand bit                      inject_error;     // force UR/CA/malformed on this item
    bit                           is_posted;        // derived: writes/messages
    time                          issue_time;
    time                          complete_time;
    int                           transaction_id;   // scoreboard correlation handle

    `uvm_object_utils_begin(pcie_tlp_seq_item)
      `uvm_field_enum(pcie_tlp_opcode_e, opcode,        UVM_ALL_ON)
      `uvm_field_int(tc,                                UVM_ALL_ON)
      `uvm_field_int(td,                                UVM_ALL_ON)
      `uvm_field_int(ep_poison,                         UVM_ALL_ON)
      `uvm_field_int(attr,                              UVM_ALL_ON)
      `uvm_field_int(length_dw,                         UVM_ALL_ON)
      `uvm_field_int(requester_id,                      UVM_ALL_ON|UVM_HEX)
      `uvm_field_int(tag,                               UVM_ALL_ON|UVM_HEX)
      `uvm_field_int(last_be,                           UVM_ALL_ON)
      `uvm_field_int(first_be,                          UVM_ALL_ON)
      `uvm_field_int(is_4dw_hdr,                        UVM_ALL_ON)
      `uvm_field_int(address,                           UVM_ALL_ON|UVM_HEX)
      `uvm_field_int(cfg_bus,                            UVM_ALL_ON)
      `uvm_field_int(cfg_device,                         UVM_ALL_ON)
      `uvm_field_int(cfg_function,                       UVM_ALL_ON)
      `uvm_field_int(cfg_register,                       UVM_ALL_ON)
      `uvm_field_int(completer_id,                      UVM_ALL_ON|UVM_HEX)
      `uvm_field_enum(pcie_tlp_cpl_status_e, cpl_status, UVM_ALL_ON)
      `uvm_field_int(bcm,                                UVM_ALL_ON)
      `uvm_field_int(byte_count,                         UVM_ALL_ON)
      `uvm_field_int(lower_address,                      UVM_ALL_ON)
      `uvm_field_array_int(payload,                      UVM_ALL_ON)
      `uvm_field_int(delay_cycles,                      UVM_ALL_ON)
      `uvm_field_int(inject_error,                      UVM_ALL_ON)
      `uvm_field_int(transaction_id,                    UVM_ALL_ON)
    `uvm_object_utils_end

    function new(string name = "pcie_tlp_seq_item");
      super.new(name);
    endfunction

    //-------------------------------------------------------------
    // Convenience constraints (opt-in: sequences can call this or
    // build with pre_randomize hooks; kept soft so any sequence can
    // override).
    //-------------------------------------------------------------
    constraint c_length {
      soft length_dw inside {[0:32]}; // small default payloads unless overridden
    }

    constraint c_payload_size {
      payload.size() == length_dw;
    }

    constraint c_addr_align {
      address[1:0] == 2'b00; // DW aligned
    }

    constraint c_delay {
      soft delay_cycles inside {[0:8]};
    }

    //-------------------------------------------------------------
    // is_posted: Memory Writes and Messages are posted; everything
    // else (reads, config, IO) is non-posted and expects a Completion.
    //-------------------------------------------------------------
    function void post_randomize();
      is_posted = (opcode == TLP_MEM_WRITE) || (opcode == TLP_IO_WRITE) ||
                  (opcode == TLP_MESSAGE);
    endfunction

    function string convert2string();
      return $sformatf("opcode=%s tag=%0d addr=0x%0h len_dw=%0d reqid=0x%0h cpl_status=%s err_inj=%0b",
                        opcode.name(), tag, address, length_dw, requester_id,
                        cpl_status.name(), inject_error);
    endfunction

    function bit is_completion();
      return (opcode == TLP_COMPLETION) || (opcode == TLP_COMPLETION_DATA);
    endfunction

    function bit is_config();
      return (opcode == TLP_CFG_READ) || (opcode == TLP_CFG_WRITE);
    endfunction

    function int pack_header(output bit [31:0] dw[4]);
      dw[0]  = '0;
      dw[0][30:29] = fmt[1:0];
      dw[0][28:24] = tlp_type;
      dw[0][22:20] = tc;
      dw[0][15]    = td;
      dw[0][14]    = ep_poison;
      dw[0][13:12] = attr;
      dw[0][9:0]   = length_dw;

      if (is_completion()) begin
        dw[1] = '0;
        dw[1][31:16] = completer_id;
        dw[1][15:13] = cpl_status;
        dw[1][12]    = bcm;
        dw[1][11:0]  = byte_count;
        dw[2] = '0;
        dw[2][31:16] = requester_id;
        dw[2][15:8]  = tag;
        dw[2][6:0]   = lower_address;
        return 3;
      end
      else if (is_config()) begin
        dw[1] = '0;
        dw[1][31:16] = requester_id;
        dw[1][15:8]  = tag;
        dw[1][7:4]   = last_be;
        dw[1][3:0]   = first_be;
        dw[2] = '0;
        dw[2][31:24] = cfg_bus;
        dw[2][23:19] = cfg_device;
        dw[2][18:16] = cfg_function;
        dw[2][11:2]  = cfg_register;
        return 3;
      end
      else begin
        dw[1] = '0;
        dw[1][31:16] = requester_id;
        dw[1][15:8]  = tag;
        dw[1][7:4]   = last_be;
        dw[1][3:0]   = first_be;
        if (is_4dw_hdr) begin
          dw[2] = address[63:32];
          dw[3] = {address[31:2], 2'b00};
          return 4;
        end
        else begin
          dw[2] = {address[31:2], 2'b00};
          return 3;
        end
      end
    endfunction

    function void unpack_header(input bit [31:0] dw[4], input int hdr_dw_count);
      bit [1:0] fmt_bits;
      fmt_bits    = dw[0][30:29];
      is_4dw_hdr  = fmt_bits[0];
      fmt         = pcie_tlp_fmt_e'(fmt_bits);
      tlp_type    = dw[0][28:24];
      tc          = dw[0][22:20];
      td          = dw[0][15];
      ep_poison   = dw[0][14];
      attr        = dw[0][13:12];
      length_dw   = dw[0][9:0];

      if (tlp_type == TYPE_CPL || tlp_type == TYPE_CPL_LK) begin
        opcode        = (length_dw != 0) ? TLP_COMPLETION_DATA : TLP_COMPLETION;
        completer_id  = dw[1][31:16];
        cpl_status    = pcie_tlp_cpl_status_e'(dw[1][15:13]);
        bcm           = dw[1][12];
        byte_count    = dw[1][11:0];
        requester_id  = dw[2][31:16];
        tag           = dw[2][15:8];
        lower_address = dw[2][6:0];
      end
      else if (tlp_type == TYPE_CFG0_RW || tlp_type == TYPE_CFG1_RW) begin
        opcode        = (fmt == FMT_3DW_DATA || fmt == FMT_4DW_DATA) ? TLP_CFG_WRITE : TLP_CFG_READ;
        requester_id  = dw[1][31:16];
        tag           = dw[1][15:8];
        last_be       = dw[1][7:4];
        first_be      = dw[1][3:0];
        cfg_bus       = dw[2][31:24];
        cfg_device    = dw[2][23:19];
        cfg_function  = dw[2][18:16];
        cfg_register  = dw[2][11:2];
      end
      else if (tlp_type == TYPE_MSG) begin
        opcode        = TLP_MESSAGE;
        requester_id  = dw[1][31:16];
        tag           = dw[1][15:8];
      end
      else begin
        bit is_io = (tlp_type == TYPE_IO_RW);
        bit is_write = (fmt == FMT_3DW_DATA || fmt == FMT_4DW_DATA);
        opcode        = is_io ? (is_write ? TLP_IO_WRITE : TLP_IO_READ)
                               : (is_write ? TLP_MEM_WRITE : TLP_MEM_READ);
        requester_id  = dw[1][31:16];
        tag           = dw[1][15:8];
        last_be       = dw[1][7:4];
        first_be      = dw[1][3:0];
        if (is_4dw_hdr) address = {dw[2], dw[3][31:2], 2'b00};
        else             address = {32'b0, dw[2][31:2], 2'b00};
      end
      is_posted = (opcode == TLP_MEM_WRITE) || (opcode == TLP_IO_WRITE) || (opcode == TLP_MESSAGE);
    endfunction

  endclass : pcie_tlp_seq_item

  //=====================================================================
  // pcie_tlp_callbacks : base callback class, extendable by users to
  // hook driver/monitor events (pre_send, post_send, post_predict,
  // on_error) without modifying VIP source.
  //=====================================================================
  class pcie_tlp_callbacks extends uvm_callback;
    function new(string name = "pcie_tlp_callbacks");
      super.new(name);
    endfunction

    virtual task pre_send(pcie_tlp_seq_item item);
    endtask

    virtual task post_send(pcie_tlp_seq_item item);
    endtask

    virtual function void post_predict(pcie_tlp_seq_item item);
    endfunction

    virtual function void on_protocol_violation(string msg, pcie_tlp_seq_item item);
    endfunction
  endclass : pcie_tlp_callbacks

endpackage : pcie_tlp_globals_pkg

`endif // PCIE_TLP_GLOBALS_PKG_SV
