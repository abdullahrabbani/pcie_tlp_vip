//-----------------------------------------------------------------------------
// pcie_tlp_if.sv
//
// Generic TLP-layer streaming interface. This is the ONLY boundary the TLP
// VIP exposes downward. It intentionally contains no ACK/NAK, replay,
// sequence-number-for-retry, or flow-control-credit signals -- those belong
// to the Data Link Layer (DLL). A future DLL VIP (or RTL DLL) can be
// connected on the tx_*/rx_* side without any change to this VIP:
//
//   TLP VIP TX  ---->  tx_data/tx_valid/tx_sop/tx_eop/tx_ready  ---->  DLL TX
//   DLL RX      ---->  rx_data/rx_valid/rx_sop/rx_eop/rx_ready  ---->  TLP VIP RX
//
// In Mode 1 (VIP-to-VIP) this same interface directly connects an RC VIP
// instance's tx_* to an EP VIP instance's rx_* (and vice versa) with no DLL
// in between -- the interface does not care who/what is on the other side.
//-----------------------------------------------------------------------------
`ifndef PCIE_TLP_IF_SV
`define PCIE_TLP_IF_SV

interface pcie_tlp_if #(
  parameter int DATA_WIDTH = 64,
  parameter int KEEP_WIDTH = DATA_WIDTH/8
) (
  input logic clk,
  input logic rst_n
);

  // ---------------- TX (this agent -> link partner / DLL) ----------------
  logic [DATA_WIDTH-1:0] tx_data;
  logic [KEEP_WIDTH-1:0] tx_keep;
  logic                  tx_valid;
  logic                  tx_ready;   // backpressure from DLL/partner
  logic                  tx_sop;
  logic                  tx_eop;
  logic                  tx_err;     // malformed TLP marker (error injection)

  // ---------------- RX (link partner / DLL -> this agent) ----------------
  logic [DATA_WIDTH-1:0] rx_data;
  logic [KEEP_WIDTH-1:0] rx_keep;
  logic                  rx_valid;
  logic                  rx_ready;   // backpressure to DLL/partner
  logic                  rx_sop;
  logic                  rx_eop;
  logic                  rx_err;

  clocking driver_cb @(posedge clk);
    default input #1step output #1step;
    output tx_data, tx_keep, tx_valid, tx_sop, tx_eop, tx_err;
    input  tx_ready;
    input  rx_data, rx_keep, rx_valid, rx_sop, rx_eop, rx_err;
    output rx_ready;
  endclocking

  clocking monitor_cb @(posedge clk);
    default input #1step output #1step;
    input tx_data, tx_keep, tx_valid, tx_ready, tx_sop, tx_eop, tx_err;
    input rx_data, rx_keep, rx_valid, rx_ready, rx_sop, rx_eop, rx_err;
  endclocking

  modport DRIVER (
    clocking driver_cb, input clk, rst_n
  );

  modport MONITOR (
    clocking monitor_cb, input clk, rst_n
  );

  // Passive/DUT-facing modport for connecting directly to DUT pins or a
  // future DLL VIP without clocking-block indirection.
  modport DUT (
    input  clk, rst_n,
    output tx_data, tx_keep, tx_valid, tx_sop, tx_eop, tx_err,
    input  tx_ready,
    input  rx_data, rx_keep, rx_valid, rx_sop, rx_eop, rx_err,
    output rx_ready
  );

  // Simple protocol assertions live in pcie_tlp_*_assertions.sv, bound to
  // this interface, so they can be reused for both RC and EP contexts.

endinterface : pcie_tlp_if

`endif // PCIE_TLP_IF_SV
