`ifndef PCIE_TLP_EP_AGENT_BFM_SV
`define PCIE_TLP_EP_AGENT_BFM_SV

module pcie_tlp_ep_agent_bfm (pcie_tlp_if.DUT vif);
  pcie_tlp_ep_driver_bfm  ep_driver_bfm_h  (vif);
  pcie_tlp_ep_monitor_bfm ep_monitor_bfm_h (vif);
endmodule : pcie_tlp_ep_agent_bfm

`endif
