//-----------------------------------------------------------------------------
// pcie_tlp_ep_driver_bfm.sv
// EP-side driver BFM: samples incoming requests on rx_*, and serializes
// pcie_tlp_seq_item completions onto tx_* on behalf of the driver_proxy.
//-----------------------------------------------------------------------------
`ifndef PCIE_TLP_EP_DRIVER_BFM_SV
`define PCIE_TLP_EP_DRIVER_BFM_SV

interface pcie_tlp_ep_driver_bfm (pcie_tlp_if.DUT vif);

  import uvm_pkg::*;
  import pcie_tlp_globals_pkg::*;
`include "uvm_macros.svh"

  string name = "PCIE_TLP_EP_DRIVER_BFM";

  task wait_for_reset();
    @(negedge vif.rst_n);
    default_values();
    @(posedge vif.rst_n);
  endtask

  task default_values();
    vif.tx_data  <= '0;
    vif.tx_keep  <= '0;
    vif.tx_valid <= 1'b0;
    vif.tx_sop   <= 1'b0;
    vif.tx_eop   <= 1'b0;
    vif.tx_err   <= 1'b0;
    vif.rx_ready <= 1'b1;
  endtask

  // Sample one request TLP arriving on rx_*.
  task automatic sample_request(output pcie_tlp_seq_item item, input pcie_tlp_seq_item factory_item);
    bit [31:0] hdr[4];
    item = factory_item;
    vif.rx_ready <= 1'b1;
    do @(posedge vif.clk); while (!(vif.rx_valid && vif.rx_sop));

    hdr[0] = vif.rx_data[31:0];
    hdr[1] = vif.rx_data[63:32];
    @(posedge vif.clk);
    hdr[2] = vif.rx_data[31:0];
    hdr[3] = vif.rx_data[63:32];
    item.unpack_header(hdr, 3);

    for (int i = 0; i < item.length_dw; i++) begin
      if (i % 2 == 0) @(posedge vif.clk);
      item.payload = new[item.length_dw](item.payload);
      item.payload[i] = (i % 2 == 0) ? vif.rx_data[31:0] : vif.rx_data[63:32];
    end
    item.issue_time = $time;
    `uvm_info(name, $sformatf("Sampled request: %s", item.convert2string()), UVM_HIGH)
  endtask

  // Drive one completion TLP out tx_*, with optional wait states to model
  // delayed completions.
  task automatic send_completion(input pcie_tlp_seq_item item);
    bit [31:0] hdr[4];
    int        hdr_dws;
    hdr_dws = item.pack_header(hdr); // completions are always 3DW

    repeat (item.delay_cycles) @(posedge vif.clk);

    @(posedge vif.clk);
    vif.tx_data  <= {hdr[1], hdr[0]};
    vif.tx_valid <= 1'b1;
    vif.tx_sop   <= 1'b1;
    vif.tx_eop   <= (item.length_dw == 0);
    vif.tx_err   <= item.inject_error;
    vif.tx_keep  <= '1;
    do @(posedge vif.clk); while (vif.tx_ready !== 1'b1);

    vif.tx_data <= {32'h0, hdr[2]};
    vif.tx_eop  <= (item.length_dw == 0);
    do @(posedge vif.clk); while (vif.tx_ready !== 1'b1);

    for (int i = 0; i < item.length_dw; i += 2) begin
      bit [63:0] beat;
      beat = item.payload[i];
      if (i+1 < item.length_dw) beat |= {item.payload[i+1], 32'h0};
      @(posedge vif.clk);
      vif.tx_data <= beat;
      vif.tx_eop  <= (i+2 >= item.length_dw);
      do @(posedge vif.clk); while (vif.tx_ready !== 1'b1);
    end

    @(posedge vif.clk);
    default_values();
    `uvm_info(name, $sformatf("Sent completion: %s", item.convert2string()), UVM_HIGH)
  endtask

endinterface : pcie_tlp_ep_driver_bfm

`endif
