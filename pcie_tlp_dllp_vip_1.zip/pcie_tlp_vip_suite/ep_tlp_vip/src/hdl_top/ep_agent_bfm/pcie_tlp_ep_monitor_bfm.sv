`ifndef PCIE_TLP_EP_MONITOR_BFM_SV
`define PCIE_TLP_EP_MONITOR_BFM_SV

interface pcie_tlp_ep_monitor_bfm (pcie_tlp_if.DUT vif);

  import uvm_pkg::*;
  import pcie_tlp_globals_pkg::*;
`include "uvm_macros.svh"

  string name = "PCIE_TLP_EP_MONITOR_BFM";

  task automatic sample_request(output pcie_tlp_seq_item item, input pcie_tlp_seq_item factory_item);
    bit [31:0] hdr[4];
    item = factory_item;
    do @(posedge vif.clk); while (!(vif.rx_valid && vif.rx_sop));
    hdr[0] = vif.rx_data[31:0];
    hdr[1] = vif.rx_data[63:32];
    @(posedge vif.clk);
    hdr[2] = vif.rx_data[31:0];
    hdr[3] = vif.rx_data[63:32];
    item.unpack_header(hdr, 3);
    for (int i = 0; i < item.length_dw; i++) begin
      if (i % 2 == 0) @(posedge vif.clk);
      item.payload = new[item.length_dw](item.payload);
      item.payload[i] = (i % 2 == 0) ? vif.rx_data[31:0] : vif.rx_data[63:32];
    end
    item.issue_time = $time;
    `uvm_info(name, $sformatf("Monitor observed request: %s", item.convert2string()), UVM_HIGH)
  endtask

  task automatic sample_completion(output pcie_tlp_seq_item item, input pcie_tlp_seq_item factory_item);
    bit [31:0] hdr[4];
    item = factory_item;
    do @(posedge vif.clk); while (!(vif.tx_valid && vif.tx_sop));
    hdr[0] = vif.tx_data[31:0];
    hdr[1] = vif.tx_data[63:32];
    @(posedge vif.clk);
    hdr[2] = vif.tx_data[31:0];
    hdr[3] = vif.tx_data[63:32];
    item.unpack_header(hdr, 3);
    for (int i = 0; i < item.length_dw; i++) begin
      if (i % 2 == 0) @(posedge vif.clk);
      item.payload = new[item.length_dw](item.payload);
      item.payload[i] = (i % 2 == 0) ? vif.tx_data[31:0] : vif.tx_data[63:32];
    end
    item.complete_time = $time;
    `uvm_info(name, $sformatf("Monitor observed completion: %s", item.convert2string()), UVM_HIGH)
  endtask

endinterface : pcie_tlp_ep_monitor_bfm

`endif
