`ifndef PCIE_TLP_EP_ASSERTIONS_SV
`define PCIE_TLP_EP_ASSERTIONS_SV

module pcie_tlp_ep_assertions (pcie_tlp_if vif);
  import uvm_pkg::*;
`include "uvm_macros.svh"

  property p_sop_with_valid;
    @(posedge vif.clk) disable iff (!vif.rst_n)
    vif.rx_sop |-> vif.rx_valid;
  endproperty
  a_sop_with_valid: assert property (p_sop_with_valid)
    else `uvm_error("PCIE_TLP_EP_ASSERT", "rx_sop asserted without rx_valid")

  property p_sop_implies_eop;
    @(posedge vif.clk) disable iff (!vif.rst_n)
    (vif.rx_valid && vif.rx_sop) |-> ##[1:64] (vif.rx_valid && vif.rx_eop);
  endproperty
  a_sop_implies_eop: assert property (p_sop_implies_eop)
    else `uvm_error("PCIE_TLP_EP_ASSERT", "rx_sop not followed by rx_eop within 64 cycles")

  // Completion timeout guard: once a request is accepted, the EP must
  // issue the corresponding completion (tx_sop on a completion type)
  // within PCIE_TLP_DEFAULT_TIMEOUT_NS -- checked structurally here as a
  // bounded-response property; exact tag correlation is done by the
  // scoreboard, not by this local assertion.
  property p_request_gets_response;
    @(posedge vif.clk) disable iff (!vif.rst_n)
    (vif.rx_valid && vif.rx_sop) |-> ##[1:2000] (vif.tx_valid && vif.tx_sop);
  endproperty
  a_request_gets_response: assert property (p_request_gets_response)
    else `uvm_warning("PCIE_TLP_EP_ASSERT", "No completion observed within timeout window of a request")

endmodule : pcie_tlp_ep_assertions

`endif
