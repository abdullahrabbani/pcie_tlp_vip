`ifndef PCIE_TLP_EP_HDL_TOP_SV
`define PCIE_TLP_EP_HDL_TOP_SV

module pcie_tlp_ep_hdl_top;
  import uvm_pkg::*;
`include "uvm_macros.svh"

  bit clk;
  bit rst_n;

  initial clk = 0;
  always #5 clk = ~clk;

  initial begin
    rst_n = 0;
    #20 rst_n = 1;
  end

  pcie_tlp_if ep_if (.clk(clk), .rst_n(rst_n));
  pcie_tlp_ep_agent_bfm ep_agent_bfm_h (.vif(ep_if));

  initial begin
    uvm_config_db#(virtual pcie_tlp_ep_driver_bfm)::set(null, "*", "bfm", ep_agent_bfm_h.ep_driver_bfm_h);
    uvm_config_db#(virtual pcie_tlp_ep_monitor_bfm)::set(null, "*", "bfm", ep_agent_bfm_h.ep_monitor_bfm_h);
    uvm_config_db#(virtual pcie_tlp_if)::set(null, "*", "vif", ep_if);
  end

  pcie_tlp_ep_assertions ep_assertions_h (.vif(ep_if));

endmodule : pcie_tlp_ep_hdl_top

`endif
