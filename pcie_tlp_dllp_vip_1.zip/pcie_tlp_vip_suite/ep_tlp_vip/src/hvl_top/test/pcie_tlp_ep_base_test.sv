`ifndef PCIE_TLP_EP_BASE_TEST_SV
`define PCIE_TLP_EP_BASE_TEST_SV

class pcie_tlp_ep_base_test extends uvm_test;
  `uvm_component_utils(pcie_tlp_ep_base_test)

  pcie_tlp_ep_agent        ep_agent_h;
  pcie_tlp_ep_agent_config ep_cfg;

  function new(string name = "pcie_tlp_ep_base_test", uvm_component parent = null);
    super.new(name, parent);
  endfunction

  function void build_phase(uvm_phase phase);
    super.build_phase(phase);
    ep_cfg = pcie_tlp_ep_agent_config::type_id::create("ep_cfg");
    ep_cfg.is_active = UVM_ACTIVE;
    uvm_config_db#(pcie_tlp_ep_agent_config)::set(this, "ep_agent_h", "cfg", ep_cfg);
    ep_agent_h = pcie_tlp_ep_agent::type_id::create("ep_agent_h", this);
  endfunction

  function void end_of_elaboration_phase(uvm_phase phase);
    super.end_of_elaboration_phase(phase);
    uvm_top.print_topology();
  endfunction
endclass : pcie_tlp_ep_base_test

`endif
