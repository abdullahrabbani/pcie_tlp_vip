`ifndef PCIE_TLP_EP_TEST_PKG_SV
`define PCIE_TLP_EP_TEST_PKG_SV

package pcie_tlp_ep_test_pkg;
  import uvm_pkg::*;
  import pcie_tlp_globals_pkg::*;
  import pcie_tlp_ep_pkg::*;
`include "uvm_macros.svh"

`include "pcie_tlp_ep_base_test.sv"

endpackage : pcie_tlp_ep_test_pkg

`endif
