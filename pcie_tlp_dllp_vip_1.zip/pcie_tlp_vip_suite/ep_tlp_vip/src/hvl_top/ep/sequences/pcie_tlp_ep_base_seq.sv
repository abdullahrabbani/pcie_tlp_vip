`ifndef PCIE_TLP_EP_BASE_SEQ_SV
`define PCIE_TLP_EP_BASE_SEQ_SV

// Optional directed sequence hook for the EP responder. The default
// driver_proxy auto-responds using pcie_tlp_ep_memory + cfg policy; this
// sequence class exists so advanced tests can seed cfg fields (e.g. force
// error_injection_enable for a window of time) from a sequence context
// rather than poking the driver directly.
class pcie_tlp_ep_base_seq extends uvm_sequence #(pcie_tlp_seq_item);
  `uvm_object_utils(pcie_tlp_ep_base_seq)
  `uvm_declare_p_sequencer(pcie_tlp_ep_sequencer)

  function new(string name = "pcie_tlp_ep_base_seq");
    super.new(name);
  endfunction

  virtual task body();
    // Intentionally empty: extend for directed EP response scenarios.
  endtask
endclass : pcie_tlp_ep_base_seq

`endif
