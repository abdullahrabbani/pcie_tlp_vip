`ifndef PCIE_TLP_EP_SEQUENCER_SV
`define PCIE_TLP_EP_SEQUENCER_SV

// The EP sequencer arbitrates *response* items: a directed test sequence
// may pre-load specific completion behavior (status, delay, error inject)
// which the driver_proxy consumes with priority over its default
// auto-responder policy driven by pcie_tlp_ep_memory.
class pcie_tlp_ep_sequencer extends uvm_sequencer #(pcie_tlp_seq_item);
  `uvm_component_utils(pcie_tlp_ep_sequencer)

  pcie_tlp_ep_agent_config cfg;

  function new(string name = "pcie_tlp_ep_sequencer", uvm_component parent = null);
    super.new(name, parent);
  endfunction
endclass : pcie_tlp_ep_sequencer

`endif
