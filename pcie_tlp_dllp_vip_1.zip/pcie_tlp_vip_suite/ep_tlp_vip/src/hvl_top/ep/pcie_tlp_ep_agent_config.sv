`ifndef PCIE_TLP_EP_AGENT_CONFIG_SV
`define PCIE_TLP_EP_AGENT_CONFIG_SV

class pcie_tlp_ep_agent_config extends uvm_object;
  `uvm_object_utils(pcie_tlp_ep_agent_config)

  uvm_active_passive_enum is_active = UVM_ACTIVE;
  pcie_tlp_addr_width_e   addr_width = ADDR_64BIT;

  bit  [15:0] completer_id            = 16'h0800;
  int         max_payload_size_bytes  = PCIE_TLP_MAX_PAYLOAD_BYTES_DEFAULT;
  int         max_read_req_size_bytes = PCIE_TLP_MAX_READ_REQ_BYTES_DEFAULT;
  int         mem_size_bytes          = 1 << 20; // 1MB default BAR window
  bit         error_injection_enable  = 0;
  int         delayed_completion_min_cycles = 0;
  int         delayed_completion_max_cycles = 0;

  virtual pcie_tlp_if vif;

  function new(string name = "pcie_tlp_ep_agent_config");
    super.new(name);
  endfunction
endclass : pcie_tlp_ep_agent_config

`endif
