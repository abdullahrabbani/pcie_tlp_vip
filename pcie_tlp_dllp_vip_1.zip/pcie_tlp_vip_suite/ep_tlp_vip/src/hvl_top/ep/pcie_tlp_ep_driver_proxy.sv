`ifndef PCIE_TLP_EP_DRIVER_PROXY_SV
`define PCIE_TLP_EP_DRIVER_PROXY_SV

// EP driver_proxy: decodes each incoming Request TLP and builds the
// appropriate Completion (SC / UR / CA / CRS, with or without data),
// applying delayed-completion and error-injection policy from cfg.
// A directed test may optionally push a "response override" item into
// the EP sequencer to force a specific status/delay/corruption on the
// next N completions; absent an override the driver auto-responds using
// pcie_tlp_ep_memory.
class pcie_tlp_ep_driver_proxy extends uvm_driver #(pcie_tlp_seq_item);
  `uvm_component_utils(pcie_tlp_ep_driver_proxy)

  virtual pcie_tlp_ep_driver_bfm bfm;
  pcie_tlp_ep_agent_config       cfg;
  pcie_tlp_ep_memory             mem_model;

  uvm_analysis_port #(pcie_tlp_seq_item) request_ap;
  uvm_analysis_port #(pcie_tlp_seq_item) completion_ap;

  `uvm_declare_p_sequencer(pcie_tlp_ep_sequencer)

  function new(string name = "pcie_tlp_ep_driver_proxy", uvm_component parent = null);
    super.new(name, parent);
    request_ap    = new("request_ap", this);
    completion_ap = new("completion_ap", this);
  endfunction

  function void build_phase(uvm_phase phase);
    super.build_phase(phase);
    if (!uvm_config_db#(virtual pcie_tlp_ep_driver_bfm)::get(this, "", "bfm", bfm))
      `uvm_fatal("NOVIF", "virtual pcie_tlp_ep_driver_bfm not found in config_db")
    if (mem_model == null) mem_model = pcie_tlp_ep_memory::type_id::create("mem_model");
  endfunction

  task run_phase(uvm_phase phase);
    bfm.wait_for_reset();
    forever begin
      pcie_tlp_seq_item req;
      pcie_tlp_seq_item cpl;

      bfm.sample_request(req, pcie_tlp_seq_item::type_id::create("ep_req"));
      `uvm_do_callbacks(pcie_tlp_ep_driver_proxy, pcie_tlp_callbacks, pre_send(req))
      request_ap.write(req);

      handle_request(req);

      if (!req.is_posted) begin
        cpl = build_completion(req);
        `uvm_do_callbacks(pcie_tlp_ep_driver_proxy, pcie_tlp_callbacks, pre_send(cpl))
        bfm.send_completion(cpl);
        completion_ap.write(cpl);
        `uvm_do_callbacks(pcie_tlp_ep_driver_proxy, pcie_tlp_callbacks, post_send(cpl))
      end
    end
  endtask

  // Update the memory model for posted/non-posted writes.
  virtual function void handle_request(pcie_tlp_seq_item req);
    if (req.opcode == TLP_MEM_WRITE) begin
      for (int i = 0; i < req.length_dw; i++) begin
        bit [3:0] be = (req.length_dw == 1) ? (req.first_be & req.last_be)
                     : (i == 0) ? req.first_be
                     : (i == req.length_dw-1) ? req.last_be : 4'hF;
        mem_model.write_dw(req.address + i*4, req.payload[i], be);
      end
    end
    else if (req.opcode == TLP_CFG_WRITE) begin
      mem_model.write_cfg(req.cfg_register, req.payload[0]);
    end
  endfunction

  // Build the Completion TLP for a given Request, choosing status per
  // address decode / error-injection policy from cfg.
  virtual function pcie_tlp_seq_item build_completion(pcie_tlp_seq_item req);
    pcie_tlp_seq_item cpl = pcie_tlp_seq_item::type_id::create("ep_cpl");
    bit                addr_ok;

    cpl.opcode        = TLP_COMPLETION; // upgraded below if data present
    cpl.fmt            = FMT_3DW_NO_DATA;
    cpl.tlp_type       = TYPE_CPL;
    cpl.tc              = req.tc;
    cpl.completer_id    = cfg.completer_id;
    cpl.requester_id    = req.requester_id;
    cpl.tag             = req.tag;
    cpl.lower_address    = req.address[6:0];
    cpl.transaction_id  = req.tag;
    cpl.delay_cycles    = (cfg.delayed_completion_max_cycles > 0)
                            ? $urandom_range(cfg.delayed_completion_min_cycles,
                                              cfg.delayed_completion_max_cycles)
                            : 0;

    addr_ok = (req.opcode == TLP_CFG_READ) ? 1 : mem_model.addr_in_range(req.address);

    if (cfg.error_injection_enable && req.inject_error) begin
      cpl.cpl_status   = CPL_CA;
      cpl.length_dw     = 0;
      cpl.byte_count    = 0;
      cpl.inject_error = 1;
      `uvm_info(get_name(), $sformatf("Error-injected Completer Abort for tag %0d", req.tag), UVM_MEDIUM)
    end
    else if (!addr_ok) begin
      cpl.cpl_status = CPL_UR;
      cpl.length_dw   = 0;
      cpl.byte_count  = 0;
    end
    else if (req.opcode == TLP_MEM_READ || req.opcode == TLP_IO_READ) begin
      cpl.length_dw = req.length_dw;
      cpl.payload    = new[req.length_dw];
      for (int i = 0; i < req.length_dw; i++)
        cpl.payload[i] = mem_model.read_dw(req.address + i*4);
      cpl.byte_count = req.length_dw * 4;
      cpl.cpl_status = CPL_SC;
      cpl.opcode      = TLP_COMPLETION_DATA;
      cpl.fmt          = FMT_3DW_DATA;
    end
    else if (req.opcode == TLP_CFG_READ) begin
      cpl.length_dw = 1;
      cpl.payload    = new[1];
      cpl.payload[0] = mem_model.read_cfg(req.cfg_register);
      cpl.byte_count = 4;
      cpl.cpl_status = CPL_SC;
      cpl.opcode      = TLP_COMPLETION_DATA;
      cpl.fmt          = FMT_3DW_DATA;
    end
    else begin // CFG_WRITE completion (no data)
      cpl.cpl_status = CPL_SC;
      cpl.length_dw   = 0;
      cpl.byte_count  = 0;
    end

    return cpl;
  endfunction
endclass : pcie_tlp_ep_driver_proxy

`endif
