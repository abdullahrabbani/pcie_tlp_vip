`ifndef PCIE_TLP_EP_COVERAGE_SV
`define PCIE_TLP_EP_COVERAGE_SV

class pcie_tlp_ep_coverage extends uvm_subscriber #(pcie_tlp_seq_item);
  `uvm_component_utils(pcie_tlp_ep_coverage)

  pcie_tlp_ep_agent_config cfg;
  pcie_tlp_seq_item        item;

  covergroup ep_tlp_cg;
    option.per_instance = 1;
    cp_opcode: coverpoint item.opcode;
    cp_status: coverpoint item.cpl_status;
    cp_delay:  coverpoint item.delay_cycles { bins none = {0}; bins some = {[1:$]}; }
    cp_err:    coverpoint item.inject_error;
    cross_status_err: cross cp_status, cp_err;
  endgroup

  function new(string name = "pcie_tlp_ep_coverage", uvm_component parent = null);
    super.new(name, parent);
    ep_tlp_cg = new();
  endfunction

  function void write(pcie_tlp_seq_item t);
    item = t;
    ep_tlp_cg.sample();
  endfunction
endclass : pcie_tlp_ep_coverage

`endif
