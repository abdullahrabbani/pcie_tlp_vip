`ifndef PCIE_TLP_EP_MEMORY_SV
`define PCIE_TLP_EP_MEMORY_SV

// Internal memory + configuration-space model used by the EP VIP to
// decode incoming requests and build accurate completions. Kept
// intentionally simple (associative array, sparse) so it scales to large
// address ranges without allocating the full window.
class pcie_tlp_ep_memory extends uvm_object;
  `uvm_object_utils(pcie_tlp_ep_memory)

  bit [7:0] mem [bit [63:0]];              // sparse byte-addressed memory
  bit [31:0] cfg_space [bit [11:0]];       // dword-addressed config space (by register offset)
  bit [63:0] bar_base  = 64'h0000_0000_1000_0000;
  bit [63:0] bar_limit;
  int        size_bytes = PCIE_TLP_MAX_PAYLOAD_BYTES_DEFAULT * 4096;

  function new(string name = "pcie_tlp_ep_memory");
    super.new(name);
    bar_limit = bar_base + size_bytes - 1;
    // A minimal, plausible Type-0 config header.
    cfg_space[12'h000] = 32'h1234_ABCD; // device/vendor id
    cfg_space[12'h004] = 32'h0000_0000; // status/command
    cfg_space[12'h008] = 32'h0600_0000; // class code / rev id
  endfunction

  function bit addr_in_range(bit [63:0] addr);
    return (addr >= bar_base) && (addr <= bar_limit);
  endfunction

  function void write_dw(bit [63:0] addr, bit [31:0] data, bit [3:0] be);
    for (int i = 0; i < 4; i++)
      if (be[i]) mem[addr+i] = data[i*8 +: 8];
  endfunction

  function bit [31:0] read_dw(bit [63:0] addr);
    bit [31:0] d = 32'hFFFF_FFFF; // model unimplemented bytes as all-Fs
    for (int i = 0; i < 4; i++)
      if (mem.exists(addr+i)) d[i*8 +: 8] = mem[addr+i];
    return d;
  endfunction

  function void write_cfg(bit [9:0] reg_addr, bit [31:0] data);
    cfg_space[{reg_addr, 2'b00}] = data;
  endfunction

  function bit [31:0] read_cfg(bit [9:0] reg_addr);
    bit [11:0] off = {reg_addr, 2'b00};
    if (cfg_space.exists(off)) return cfg_space[off];
    return 32'h0;
  endfunction
endclass : pcie_tlp_ep_memory

`endif
