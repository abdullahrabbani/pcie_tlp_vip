`ifndef PCIE_TLP_EP_PKG_SV
`define PCIE_TLP_EP_PKG_SV

package pcie_tlp_ep_pkg;
  import uvm_pkg::*;
  import pcie_tlp_globals_pkg::*;
`include "uvm_macros.svh"

`include "pcie_tlp_ep_agent_config.sv"
`include "pcie_tlp_ep_memory.sv"
`include "pcie_tlp_ep_sequencer.sv"
`include "pcie_tlp_ep_driver_proxy.sv"
`include "pcie_tlp_ep_monitor_proxy.sv"
`include "pcie_tlp_ep_coverage.sv"
`include "pcie_tlp_ep_agent.sv"
`include "sequences/pcie_tlp_ep_base_seq.sv"

endpackage : pcie_tlp_ep_pkg

`endif
