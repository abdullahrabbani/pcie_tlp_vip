`ifndef PCIE_TLP_EP_AGENT_SV
`define PCIE_TLP_EP_AGENT_SV

class pcie_tlp_ep_agent extends uvm_agent;
  `uvm_component_utils(pcie_tlp_ep_agent)

  pcie_tlp_ep_agent_config  cfg;
  pcie_tlp_ep_sequencer     sequencer_h;
  pcie_tlp_ep_driver_proxy  driver_h;
  pcie_tlp_ep_monitor_proxy monitor_h;
  pcie_tlp_ep_coverage      coverage_h;

  uvm_analysis_port #(pcie_tlp_seq_item) request_ap;
  uvm_analysis_port #(pcie_tlp_seq_item) completion_ap;

  function new(string name = "pcie_tlp_ep_agent", uvm_component parent = null);
    super.new(name, parent);
  endfunction

  function void build_phase(uvm_phase phase);
    super.build_phase(phase);
    if (!uvm_config_db#(pcie_tlp_ep_agent_config)::get(this, "", "cfg", cfg))
      `uvm_fatal("NOCFG", "pcie_tlp_ep_agent_config not found in config_db")
    is_active = cfg.is_active;

    monitor_h  = pcie_tlp_ep_monitor_proxy::type_id::create("monitor_h", this);
    monitor_h.cfg = cfg;
    coverage_h = pcie_tlp_ep_coverage::type_id::create("coverage_h", this);
    coverage_h.cfg = cfg;

    if (is_active == UVM_ACTIVE) begin
      sequencer_h = pcie_tlp_ep_sequencer::type_id::create("sequencer_h", this);
      sequencer_h.cfg = cfg;
      driver_h    = pcie_tlp_ep_driver_proxy::type_id::create("driver_h", this);
      driver_h.cfg = cfg;
    end
  endfunction

  function void connect_phase(uvm_phase phase);
    super.connect_phase(phase);
    request_ap    = monitor_h.request_ap;
    completion_ap = monitor_h.completion_ap;
    monitor_h.completion_ap.connect(coverage_h.analysis_export);
  endfunction
endclass : pcie_tlp_ep_agent

`endif
