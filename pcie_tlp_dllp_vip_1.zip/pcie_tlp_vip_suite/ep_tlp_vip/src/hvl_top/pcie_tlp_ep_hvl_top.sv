`ifndef PCIE_TLP_EP_HVL_TOP_SV
`define PCIE_TLP_EP_HVL_TOP_SV

module pcie_tlp_ep_hvl_top;
  import uvm_pkg::*;
  import pcie_tlp_globals_pkg::*;
  import pcie_tlp_ep_pkg::*;
  import pcie_tlp_ep_test_pkg::*;
`include "uvm_macros.svh"

  initial run_test();

endmodule : pcie_tlp_ep_hvl_top

`endif
