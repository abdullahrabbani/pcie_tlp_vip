# Coding Guidelines

- Follow UVM 1.2 base class conventions; no direct `$` system-task usage
  inside class code except `$sformatf`/`$urandom*`/`$time`.
- One class per file; filename == class name.
- All components use `\`uvm_component_utils`; all transactions/objects use
  `\`uvm_object_utils`.
- Every agent exposes `cfg` (config object), analysis ports named
  `request_ap` / `completion_ap`, and is buildable in both `UVM_ACTIVE`
  and `UVM_PASSIVE` mode.
- No hierarchical references (`.`) across module/class boundaries other
  than through `uvm_config_db` or virtual interface handles.
- BFM tasks are named as verbs (`sample_request`, `drive_request`,
  `send_completion`) and take/return `pcie_tlp_seq_item`, never raw
  structs, so HVL and HDL stay decoupled from wire encoding.
- All rand fields use `soft` constraints where a sensible default exists,
  so `with { }` overrides at the sequence call site always work.
- Every new opcode/status must update `pcie_tlp_seq_item::pack_header`
  and `unpack_header` together, in the same commit.
- Use `\`uvm_info` at `UVM_HIGH` for per-beat BFM tracing, `UVM_MEDIUM` for
  per-transaction driver/monitor tracing, `UVM_LOW` for env/test level
  milestones only.
- No `initial`/`always` blocks in class-based code; only inside
  interfaces/modules (BFMs, DUT stubs, hdl_top).
