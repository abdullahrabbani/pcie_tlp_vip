# PCIe TLP VIP Assertion Plan

Assertions live at the `pcie_tlp_if` boundary (bound per-role) rather
than inside class code, so they check the actual wire protocol
independent of whichever agent (VIP or DUT) is driving it.

## 1. RC-side assertions (`pcie_tlp_rc_assertions.sv`, checks `tx_*`)

| ID | Property | Severity | Rationale |
|---|---|---|---|
| A1 `a_sop_with_valid` | `tx_sop -> tx_valid` | error | `sop` must never be asserted on a dead/invalid beat |
| A2 `a_stable_under_backpressure` | `(tx_valid && !tx_ready) |=> $stable(tx_data) && tx_valid` | error | data/valid must hold steady while the link partner is stalling us |
| A3 `a_sop_implies_eop` | `(tx_valid && tx_sop) |-> ##[1:64] (tx_valid && tx_eop)` | error | no dangling/truncated TLP; every packet must close within a bounded beat window |

## 2. EP-side assertions (`pcie_tlp_ep_assertions.sv`, checks `rx_*`/`tx_*`)

| ID | Property | Severity | Rationale |
|---|---|---|---|
| B1 `a_sop_with_valid` | `rx_sop -> rx_valid` | error | mirror of A1 on the receive side |
| B2 `a_sop_implies_eop` | `(rx_valid && rx_sop) |-> ##[1:64] (rx_valid && rx_eop)` | error | mirror of A3 on the receive side |
| B3 `a_request_gets_response` | `(rx_valid && rx_sop) |-> ##[1:2000] (tx_valid && tx_sop)` | **warning** | every accepted request should eventually produce *some* TLP on tx (not tag-correlated -- that precision belongs to the scoreboard, this is a coarse liveness check) |

## 3. Deliberately out of scope for these assertion modules

- Tag/ID/byte-count/payload correctness: these require transaction-level
  state (what was actually requested) that a structural `assert
  property` on raw wire signals cannot reconstruct cleanly. They are
  checked in `pcie_tlp_scoreboard` instead (see
  `pcie_verification_plan.md` and `pcie_coverage_plan.md`).
- DLL-layer properties (ACK/NAK timing, replay-buffer depth, credit
  exhaustion): out of scope for the TLP VIP by design; belong in a future
  DLL VIP's own assertion set.

## 4. Adding new assertions

New protocol properties go in the appropriate `pcie_tlp_{rc,ep}_assertions.sv`
module, bound to `pcie_tlp_if`, using `\`uvm_error`/`\`uvm_warning` (not bare
`$error`) so failures integrate with UVM's report catcher and
`UVM_ERROR`/`UVM_WARNING` counts used by CI pass/fail gating.
