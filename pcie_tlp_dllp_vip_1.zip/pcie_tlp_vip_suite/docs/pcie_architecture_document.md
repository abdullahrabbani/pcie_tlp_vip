# PCIe TLP VIP Architecture Document

> Diagrams below are Mermaid; render with any Mermaid-compatible viewer
> (GitHub, VS Code Mermaid extension, mermaid.live) or paste into a
> PDF/slide tool. This document stands in for `pcie_architecture_document.pdf`
> and `video_pcie_vip.mp4` in the original requirements list -- see the
> suite README for why.

## 1. Layering and scope

```mermaid
flowchart TB
    subgraph RC["RC side"]
      RCSEQ["RC sequences"] --> RCAGENT["RC TLP VIP agent"]
    end
    subgraph EP["EP side"]
      EPAGENT["EP TLP VIP agent"] --> EPMEM["EP memory / cfg model"]
    end
    RCAGENT -- "pcie_tlp_if (tx_*/rx_*)" --> EPAGENT
    RCAGENT -. "future: DLL VIP between here" .-> DLL1["DLL"]
    EPAGENT -. "future: DLL VIP between here" .-> DLL2["DLL"]
    DLL1 -.-> PHY1["PHY (future)"]
    DLL2 -.-> PHY2["PHY (future)"]
```

The TLP VIP owns Transaction-Layer semantics only: TLP construction/
decode, request/completion correlation, memory & config-space modeling on
the EP side. It never implements ACK/NAK, the replay buffer, retry
sequence numbers, or flow-control credits -- those are DLL responsibilities
and belong in a separate DLL VIP that plugs in below `pcie_tlp_if`.

## 2. Block diagram: single agent (either role)

```mermaid
flowchart LR
    subgraph AGENT["pcie_tlp_*_agent (uvm_agent)"]
      SEQR["sequencer (ACTIVE only)"] --> DRV["driver_proxy"]
      DRV <--> BFM["driver_bfm (interface)"]
      MON["monitor_proxy"] <--> MBFM["monitor_bfm (interface)"]
      DRV -- request_ap/completion_ap --> COV["coverage (uvm_subscriber)"]
      MON -- request_ap/completion_ap --> EXT["external subscribers / scoreboard"]
    end
    BFM <--> IF["pcie_tlp_if"]
    MBFM -. passive sampling .-> IF
    CFG["agent_config (cfg)"] -. uvm_config_db .-> DRV
    CFG -. uvm_config_db .-> MON
    CFG -. uvm_config_db .-> SEQR
```

Every agent -- RC or EP -- follows this identical shape. The only
difference between RC and EP is what `driver_proxy` *does*: RC's
driver_proxy sends requests and waits for completions (initiator); EP's
driver_proxy waits for requests and generates completions (responder).

## 3. VIP-to-VIP topology (Mode 1)

```mermaid
flowchart LR
    RCseq["RC test sequence"] --> RCsqr["RC sequencer"]
    RCsqr --> RCdrv["RC driver_proxy"]
    RCdrv --> RCbfm["RC driver BFM"]
    RCbfm <-- "shared pcie_tlp_if" --> EPbfm["EP driver BFM"]
    EPbfm --> EPdrv["EP driver_proxy"]
    EPdrv --> EPmem["EP memory model"]
    EPdrv --> EPbfm
    RCmon["RC monitor_proxy"] -. observes tx_*/rx_* .-> RCbfm
    RCmon --> SB["pcie_tlp_scoreboard"]
```

## 4. VIP-to-DUT topology (Mode 2)

```mermaid
flowchart LR
    subgraph "RC VIP <-> EP DUT"
      A1["RC TLP VIP"] <--> A2["Endpoint DUT"]
    end
    subgraph "RC DUT <-> EP VIP"
      B1["Root Complex DUT"] <--> B2["EP TLP VIP"]
    end
```

Both are the same `pcie_tlp_if` boundary; only which side is VIP vs. DUT
changes. See `examples/vip_to_dut/`.

## 5. RC driver_proxy flow (request/completion loop)

```mermaid
flowchart TD
    START(["get_next_item"]) --> CB1["pre_send callback"]
    CB1 --> DRIVE["bfm.drive_request(req)"]
    DRIVE --> POSTED{"req.is_posted?"}
    POSTED -- yes --> DONE1["item_done()"]
    POSTED -- no --> WAIT["fork: sample_completion() vs timeout"]
    WAIT --> GOTCPL{"completion before timeout?"}
    GOTCPL -- yes --> PUB["completion_ap.write(cpl)"]
    GOTCPL -- no --> ERR["uvm_error: completion timeout"]
    PUB --> CB2["post_send callback"]
    ERR --> CB2
    CB2 --> DONE2["item_done()"]
```

## 6. EP driver_proxy flow (responder / completion policy)

```mermaid
flowchart TD
    RX(["bfm.sample_request(req)"]) --> PUB1["request_ap.write(req)"]
    PUB1 --> UPDATE["handle_request(): update memory / cfg space"]
    UPDATE --> POSTED{"req.is_posted?"}
    POSTED -- yes --> LOOP(["back to sample_request"])
    POSTED -- no --> BUILD["build_completion(req)"]
    BUILD --> ERRINJ{"error_injection_enable && req.inject_error?"}
    ERRINJ -- yes --> CA["status = CA"]
    ERRINJ -- no --> RANGE{"address in range?"}
    RANGE -- no --> UR["status = UR"]
    RANGE -- yes --> SC["status = SC, attach data if read"]
    CA --> SEND["bfm.send_completion(cpl)"]
    UR --> SEND
    SC --> SEND
    SEND --> PUB2["completion_ap.write(cpl)"]
    PUB2 --> LOOP
```

## 7. Sequence diagram: Memory Read, VIP-to-VIP

```mermaid
sequenceDiagram
    participant Test as RC test sequence
    participant RCDrv as RC driver_proxy
    participant IF as pcie_tlp_if
    participant EPDrv as EP driver_proxy
    participant Mem as EP memory model
    participant SB as scoreboard

    Test->>RCDrv: mem_read(addr, len, tag)
    RCDrv->>IF: tx_* (3/4DW header, no data)
    IF->>EPDrv: rx_* (request observed)
    EPDrv->>Mem: read_dw(addr) x len
    Mem-->>EPDrv: data[]
    EPDrv->>IF: tx_* (Cpl+Data, status=SC)
    IF->>RCDrv: rx_* (completion observed)
    RCDrv-->>Test: cpl (payload, status)
    RCDrv->>SB: completion_ap.write(cpl)
    Note over SB: matches by {requester_id,tag},<br/>checks byte_count & payload size
```

## 8. Sequence diagram: Delayed / error-injected completion

```mermaid
sequenceDiagram
    participant RCDrv as RC driver_proxy
    participant EPDrv as EP driver_proxy
    RCDrv->>EPDrv: request (tag=T)
    Note over EPDrv: cfg.error_injection_enable=1<br/>req.inject_error=1
    EPDrv->>EPDrv: delay_cycles = rand(min,max)
    EPDrv-->>EPDrv: wait delay_cycles
    EPDrv->>RCDrv: completion, status=CA
    Note over RCDrv: if timeout elapses first,<br/>uvm_error("completion timeout")
```

## 9. TLP header layout (as implemented in `pack_header`/`unpack_header`)

```
DW0: [30:29] fmt | [28:24] type | [22:20] TC | [15] TD | [14] EP | [13:12] Attr | [9:0] Length(DW)

Memory/IO Request:
DW1: [31:16] Requester ID | [15:8] Tag | [7:4] Last BE | [3:0] First BE
DW2: Address[31:2] (3DW) | DW2/DW3: Address[63:32]/[31:2] (4DW)

Config Request:
DW1: [31:16] Requester ID | [15:8] Tag | [7:4] Last BE | [3:0] First BE
DW2: [31:24] Bus | [23:19] Device | [18:16] Function | [11:2] Register

Completion:
DW1: [31:16] Completer ID | [15:13] Status | [12] BCM | [11:0] Byte Count
DW2: [31:16] Requester ID | [15:8] Tag | [6:0] Lower Address
```

## 10. Config/coverage/error-injection ownership summary

| Concern | Owner class |
|---|---|
| Active/passive | `pcie_tlp_{rc,ep}_agent_config.is_active` |
| RC/EP mode selection at env level | `pcie_tlp_env_config.mode` |
| Address width | `pcie_tlp_{rc,ep}_agent_config.addr_width` |
| Max payload size | `*_agent_config.max_payload_size_bytes` |
| Max read request size | `*_agent_config.max_read_req_size_bytes` |
| Completion timeout | `pcie_tlp_rc_agent_config.completion_timeout_ns` (checked in RC driver_proxy) |
| Error injection enable | `*_agent_config.error_injection_enable` (policy applied in EP driver_proxy) |
