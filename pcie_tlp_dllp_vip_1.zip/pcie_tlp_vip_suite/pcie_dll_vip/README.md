# PCIe DLL VIP (scaffold)

A functional -- not bit-accurate -- Data Link Layer model, structured to
match `rc_tlp_vip`/`ep_tlp_vip`'s agent pattern (agent_bfm/driver_bfm at
the HDL level, agent/driver_proxy/monitor_proxy/coverage/agent_config at
the HVL level), so it plugs into the same env/scoreboard conventions.
See `examples/vip_to_dll/` for the wired-up full stack, including a UVM
test (`pcie_tlp_dll_smoke_test`) that runs a write/read-back through it.

## Structure

```
pcie_dll_vip/
├── src/globals/pcie_dll_globals_pkg.sv    # enums, pcie_dll_event, credit ledger struct
├── src/hdl_top/pcie_dll_agent_bfm/
│   ├── pcie_dll_driver_bfm.sv              # ONE direction: capture, credit-gate, seq, replay, forward
│   └── pcie_dll_agent_bfm.sv                # instantiates 2x driver_bfm (a->b, b->a) across side_a/side_b
└── src/hvl_top/
    ├── pcie_dll_agent_config.sv
    ├── pcie_dll_driver_proxy.sv             # active-mode only: runs forward + replay_watchdog loops
    ├── pcie_dll_monitor_proxy.sv            # always created: drains bfm.event_mbx -> event_ap
    ├── pcie_dll_coverage.sv                 # covergroup on pcie_dll_event (dir x kind, fc_type, replay)
    ├── pcie_dll_agent.sv                     # one agent = both directions of one link segment
    └── pcie_dll_pkg.sv
```

An agent instance covers **both directions** of one link segment (it owns
`a_to_b_*` and `b_to_a_*` driver/monitor/coverage pairs), because a DLL
link is inherently bidirectional -- unlike RC/EP agents which each own
one direction of intent (initiator vs. responder).

## Modeled (functionally correct, verification-useful today)

- Sequence number assignment per direction (`pcie_dll_driver_bfm.next_seq`)
- Replay buffer (go-back-N) with a timeout-driven retransmit and a
  `MAX_REPLAY_COUNT`-triggered modeled "link down" error
  (`replay_watchdog`, driven from `pcie_dll_driver_proxy.run_phase`)
- Credit-based flow control: separate Posted / Non-Posted / Completion
  ledgers, header + data credits, classified from the TLP header's
  Fmt/Type/Length fields (`classify()`)
- Structured events (`pcie_dll_event`: FORWARD / REPLAY / LINK_DOWN) on
  `pcie_dll_monitor_proxy.event_ap`, feeding `pcie_dll_coverage`
- Active/passive agent mode: passive = observe-only, for pairing next to
  a DUT/RTL DLL that forwards traffic itself (that RTL would need its own
  bridge into `event_mbx` for the monitor to see anything -- see caveat
  below)

## Simplified (documented, not hidden)

- **ACK/NAK delivery**: modeled as an immediate internal self-ack inside
  `forward_one_packet` (retire from the replay buffer right after a
  successful forward), not as DLLP packets driven on the wire. Only the
  **timeout** path (`replay_watchdog`) exercises retransmission today --
  there is no NAK-triggered replay yet, since nothing currently generates
  a NAK from the receive side.
- **Credit return**: freed the instant a packet is forwarded to the far
  TLP VIP (`return_credits` called right after `drive_beats`), modeling
  an always-draining receiver -- not gated on the receiver's actual
  buffer occupancy the way a real `UpdateFC` DLLP would be. Credit
  exhaustion/stall is therefore not currently reachable in test.
- **No DLLP symbol encoding / LCRC / physical framing** -- out of scope
  until a PHY VIP exists.
- **Passive-mode caveat**: if you build a `pcie_dll_agent` `UVM_PASSIVE`
  next to a real RTL DLL, the monitor_proxy still expects to read
  `bfm.event_mbx`, which only `pcie_dll_driver_bfm`'s own
  `forward_one_packet`/`replay_watchdog` populate today -- an RTL DLL
  won't drive that mailbox. Passive mode is scaffolded but not yet
  useful against non-VIP DLL implementations without additional bridging
  work.

## Next steps to increase fidelity

1. Wire `pcie_dll_agent_config` into `pcie_dll_driver_bfm` via
   `uvm_config_db` (replacing the module `#()` parameters), matching how
   `rc_tlp_vip`/`ep_tlp_vip` source their config -- currently the agent
   builds `cfg` but the BFM still reads compile-time parameters.
2. Model DLLPs as actual beats (dedicated `pcie_dllp_if` or a reserved
   encoding) instead of the immediate self-ack, so NAK-triggered replay
   is independently testable from timeout-triggered replay.
3. Gate `return_credits` on simulated receive-buffer occupancy instead of
   auto-returning on forward, so credit exhaustion/stall scenarios become
   reachable.
4. Add a bridging shim so a passive `pcie_dll_agent` can observe a real
   RTL/DUT DLL's forwarding decisions (today it only works meaningfully
   in active mode, or passive alongside another VIP instance of this same
   BFM).
