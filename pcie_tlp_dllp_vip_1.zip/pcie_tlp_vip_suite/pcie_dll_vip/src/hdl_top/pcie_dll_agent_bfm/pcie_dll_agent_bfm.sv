//-----------------------------------------------------------------------------
// pcie_dll_agent_bfm.sv
// Instantiates one pcie_dll_driver_bfm per direction across two
// pcie_tlp_if instances (side_a facing e.g. the RC TLP VIP, side_b
// facing e.g. the EP TLP VIP), replacing the earlier monolithic
// pcie_dll_link_bfm with the agent_bfm/driver_bfm split used by
// rc_tlp_vip and ep_tlp_vip.
//-----------------------------------------------------------------------------
`ifndef PCIE_DLL_AGENT_BFM_SV
`define PCIE_DLL_AGENT_BFM_SV

module pcie_dll_agent_bfm #(
  parameter int REPLAY_TIMEOUT_CYCLES = 200,
  parameter int MAX_REPLAY_COUNT      = 4,
  parameter int INIT_P_HDR_CREDITS    = 64,
  parameter int INIT_P_DATA_CREDITS   = 256,
  parameter int INIT_NP_HDR_CREDITS   = 32,
  parameter int INIT_CPL_HDR_CREDITS  = 64,
  parameter int INIT_CPL_DATA_CREDITS = 256
) (
  pcie_tlp_if.DUT side_a,
  pcie_tlp_if.DUT side_b
);

  import pcie_dll_globals_pkg::*;

  pcie_dll_driver_bfm #(
    .REPLAY_TIMEOUT_CYCLES(REPLAY_TIMEOUT_CYCLES), .MAX_REPLAY_COUNT(MAX_REPLAY_COUNT),
    .INIT_P_HDR_CREDITS(INIT_P_HDR_CREDITS), .INIT_P_DATA_CREDITS(INIT_P_DATA_CREDITS),
    .INIT_NP_HDR_CREDITS(INIT_NP_HDR_CREDITS),
    .INIT_CPL_HDR_CREDITS(INIT_CPL_HDR_CREDITS), .INIT_CPL_DATA_CREDITS(INIT_CPL_DATA_CREDITS)
  ) a_to_b_bfm_h (.rx_if(side_a), .tx_if(side_b));

  pcie_dll_driver_bfm #(
    .REPLAY_TIMEOUT_CYCLES(REPLAY_TIMEOUT_CYCLES), .MAX_REPLAY_COUNT(MAX_REPLAY_COUNT),
    .INIT_P_HDR_CREDITS(INIT_P_HDR_CREDITS), .INIT_P_DATA_CREDITS(INIT_P_DATA_CREDITS),
    .INIT_NP_HDR_CREDITS(INIT_NP_HDR_CREDITS),
    .INIT_CPL_HDR_CREDITS(INIT_CPL_HDR_CREDITS), .INIT_CPL_DATA_CREDITS(INIT_CPL_DATA_CREDITS)
  ) b_to_a_bfm_h (.rx_if(side_b), .tx_if(side_a));

  initial begin
    a_to_b_bfm_h.init(DLL_DIR_A_TO_B);
    b_to_a_bfm_h.init(DLL_DIR_B_TO_A);
  end

endmodule : pcie_dll_agent_bfm

`endif
