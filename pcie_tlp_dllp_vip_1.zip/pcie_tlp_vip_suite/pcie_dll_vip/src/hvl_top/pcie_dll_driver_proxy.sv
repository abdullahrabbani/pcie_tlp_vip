`ifndef PCIE_DLL_DRIVER_PROXY_SV
`define PCIE_DLL_DRIVER_PROXY_SV

// Owns ONE direction's active forwarding: runs pcie_dll_driver_bfm's
// forward_one_packet() in a loop plus its replay_watchdog() in parallel.
// Only created when the owning pcie_dll_agent is UVM_ACTIVE -- if you
// bind a passive DLL agent next to a DUT/RTL DLL that already forwards
// traffic itself, no driver_proxy is created and only the monitor_proxy
// observes (via the same event_mbx the RTL/BFM populates -- see
// pcie_dll_vip/README.md for the caveat that a real RTL DLL would need
// its own bridge into event_mbx to make that combination meaningful).
class pcie_dll_driver_proxy extends uvm_component;
  `uvm_component_utils(pcie_dll_driver_proxy)

  virtual pcie_dll_driver_bfm bfm;
  pcie_dll_agent_config       cfg;
  string                      bfm_name = "bfm"; // config_db field name, set by agent per direction

  function new(string name = "pcie_dll_driver_proxy", uvm_component parent = null);
    super.new(name, parent);
  endfunction

  function void build_phase(uvm_phase phase);
    super.build_phase(phase);
    if (!uvm_config_db#(virtual pcie_dll_driver_bfm)::get(this, "", bfm_name, bfm))
      `uvm_fatal("NOVIF", $sformatf("virtual pcie_dll_driver_bfm not found in config_db (field=%s)", bfm_name))
  endfunction

  task run_phase(uvm_phase phase);
    fork
      forever begin
        pcie_dll_event evt;
        bfm.forward_one_packet(evt);
      end
      bfm.replay_watchdog();
    join
  endtask
endclass : pcie_dll_driver_proxy

`endif
