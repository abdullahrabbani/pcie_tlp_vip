`ifndef PCIE_DLL_COVERAGE_SV
`define PCIE_DLL_COVERAGE_SV

class pcie_dll_coverage extends uvm_subscriber #(pcie_dll_event);
  `uvm_component_utils(pcie_dll_coverage)

  pcie_dll_agent_config cfg;
  pcie_dll_event         evt;

  covergroup dll_cg;
    option.per_instance = 1;
    cp_dir:     coverpoint evt.direction;
    cp_kind:    coverpoint evt.kind;
    cp_fc:      coverpoint evt.fc_type;
    cp_replay:  coverpoint evt.replay_count { bins none = {0}; bins some = {[1:$]}; }
    cross_dir_kind: cross cp_dir, cp_kind;
  endgroup

  function new(string name = "pcie_dll_coverage", uvm_component parent = null);
    super.new(name, parent);
    dll_cg = new();
  endfunction

  function void write(pcie_dll_event t);
    evt = t;
    dll_cg.sample();
  endfunction
endclass : pcie_dll_coverage

`endif
