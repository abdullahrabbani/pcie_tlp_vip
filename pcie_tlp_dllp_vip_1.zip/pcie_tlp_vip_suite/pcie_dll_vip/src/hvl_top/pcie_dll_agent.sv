`ifndef PCIE_DLL_AGENT_SV
`define PCIE_DLL_AGENT_SV

// One pcie_dll_agent instance covers BOTH directions of a single link
// segment (mirroring pcie_dll_agent_bfm, which instantiates one
// pcie_dll_driver_bfm per direction). is_active gates whether this
// agent actively forwards traffic (driver_proxy pair) or only observes
// a link some other active instance / RTL DLL is already forwarding
// (monitor_proxy pair only) -- see pcie_dll_driver_proxy's class comment.
class pcie_dll_agent extends uvm_agent;
  `uvm_component_utils(pcie_dll_agent)

  pcie_dll_agent_config cfg;

  pcie_dll_driver_proxy  a_to_b_driver_h,  b_to_a_driver_h;
  pcie_dll_monitor_proxy a_to_b_monitor_h, b_to_a_monitor_h;
  pcie_dll_coverage      a_to_b_coverage_h, b_to_a_coverage_h;

  uvm_analysis_port #(pcie_dll_event) a_to_b_event_ap;
  uvm_analysis_port #(pcie_dll_event) b_to_a_event_ap;

  function new(string name = "pcie_dll_agent", uvm_component parent = null);
    super.new(name, parent);
  endfunction

  function void build_phase(uvm_phase phase);
    super.build_phase(phase);
    if (!uvm_config_db#(pcie_dll_agent_config)::get(this, "", "cfg", cfg))
      `uvm_fatal("NOCFG", "pcie_dll_agent_config not found in config_db")
    is_active = cfg.is_active;

    a_to_b_monitor_h = pcie_dll_monitor_proxy::type_id::create("a_to_b_monitor_h", this);
    a_to_b_monitor_h.cfg = cfg; a_to_b_monitor_h.bfm_name = "a_to_b_bfm";
    b_to_a_monitor_h = pcie_dll_monitor_proxy::type_id::create("b_to_a_monitor_h", this);
    b_to_a_monitor_h.cfg = cfg; b_to_a_monitor_h.bfm_name = "b_to_a_bfm";

    a_to_b_coverage_h = pcie_dll_coverage::type_id::create("a_to_b_coverage_h", this);
    a_to_b_coverage_h.cfg = cfg;
    b_to_a_coverage_h = pcie_dll_coverage::type_id::create("b_to_a_coverage_h", this);
    b_to_a_coverage_h.cfg = cfg;

    if (is_active == UVM_ACTIVE) begin
      a_to_b_driver_h = pcie_dll_driver_proxy::type_id::create("a_to_b_driver_h", this);
      a_to_b_driver_h.cfg = cfg; a_to_b_driver_h.bfm_name = "a_to_b_bfm";
      b_to_a_driver_h = pcie_dll_driver_proxy::type_id::create("b_to_a_driver_h", this);
      b_to_a_driver_h.cfg = cfg; b_to_a_driver_h.bfm_name = "b_to_a_bfm";
    end
  endfunction

  function void connect_phase(uvm_phase phase);
    super.connect_phase(phase);
    a_to_b_event_ap = a_to_b_monitor_h.event_ap;
    b_to_a_event_ap = b_to_a_monitor_h.event_ap;
    a_to_b_monitor_h.event_ap.connect(a_to_b_coverage_h.analysis_export);
    b_to_a_monitor_h.event_ap.connect(b_to_a_coverage_h.analysis_export);
  endfunction
endclass : pcie_dll_agent

`endif
