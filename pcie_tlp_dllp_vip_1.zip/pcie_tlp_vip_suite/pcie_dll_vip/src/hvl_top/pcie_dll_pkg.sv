`ifndef PCIE_DLL_PKG_SV
`define PCIE_DLL_PKG_SV

package pcie_dll_pkg;
  import uvm_pkg::*;
  import pcie_dll_globals_pkg::*;
`include "uvm_macros.svh"

`include "pcie_dll_agent_config.sv"
`include "pcie_dll_driver_proxy.sv"
`include "pcie_dll_monitor_proxy.sv"
`include "pcie_dll_coverage.sv"
`include "pcie_dll_agent.sv"

endpackage : pcie_dll_pkg

`endif
