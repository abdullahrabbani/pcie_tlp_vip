`ifndef PCIE_DLL_MONITOR_PROXY_SV
`define PCIE_DLL_MONITOR_PROXY_SV

// Passively drains bfm.event_mbx (populated by forward_one_packet and
// replay_watchdog) and republishes each pcie_dll_event on event_ap.
// Always created, active or passive agent mode alike.
class pcie_dll_monitor_proxy extends uvm_monitor;
  `uvm_component_utils(pcie_dll_monitor_proxy)

  virtual pcie_dll_driver_bfm bfm;
  pcie_dll_agent_config       cfg;
  string                      bfm_name = "bfm";

  uvm_analysis_port #(pcie_dll_event) event_ap;

  function new(string name = "pcie_dll_monitor_proxy", uvm_component parent = null);
    super.new(name, parent);
    event_ap = new("event_ap", this);
  endfunction

  function void build_phase(uvm_phase phase);
    super.build_phase(phase);
    if (!uvm_config_db#(virtual pcie_dll_driver_bfm)::get(this, "", bfm_name, bfm))
      `uvm_fatal("NOVIF", $sformatf("virtual pcie_dll_driver_bfm not found in config_db (field=%s)", bfm_name))
  endfunction

  task run_phase(uvm_phase phase);
    forever begin
      pcie_dll_event evt;
      bfm.event_mbx.get(evt);
      event_ap.write(evt);
    end
  endtask
endclass : pcie_dll_monitor_proxy

`endif
