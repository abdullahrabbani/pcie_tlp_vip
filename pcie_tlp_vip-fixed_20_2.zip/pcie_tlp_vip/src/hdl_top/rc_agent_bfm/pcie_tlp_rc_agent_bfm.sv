// RC Agent BFM
`ifndef PCIE_TLP_RC_AGENT_BFM_SVH
`define PCIE_TLP_RC_AGENT_BFM_SVH

import uvm_pkg::*;
`include "uvm_macros.svh"
import pcie_tlp_globals_pkg::*;
import pcie_tlp_rc_pkg::*;

module pcie_tlp_rc_agent_bfm #(parameter int RC_ID = 0)(
    pcie_tlp_if intf
);

    pcie_tlp_rc_driver_bfm rc_drv_bfm (
        .clk(intf.clk),
        .rst_n(intf.rst_n),
        .tx_data(intf.tx_data),
        .tx_keep(intf.tx_keep),
        .tx_valid(intf.tx_valid),
        .tx_ready(intf.tx_ready),
        .tx_sop(intf.tx_sop),
        .tx_eop(intf.tx_eop),
        .tx_empty(intf.tx_empty),
        .tx_seq_num(intf.tx_seq_num),
        .tx_vc_id(intf.tx_vc_id),
        .tx_tc(intf.tx_tc),
        .rx_data(intf.rx_data),
        .rx_keep(intf.rx_keep),
        .rx_valid(intf.rx_valid),
        .rx_ready(intf.rx_ready),
        .rx_sop(intf.rx_sop),
        .rx_eop(intf.rx_eop),
        .rx_empty(intf.rx_empty),
        .rx_seq_num(intf.rx_seq_num),
        .rx_vc_id(intf.rx_vc_id),
        .rx_tc(intf.rx_tc)
    );

    pcie_tlp_rc_monitor_bfm rc_mon_bfm (
        .clk(intf.clk),
        .rst_n(intf.rst_n),
        .tx_data(intf.tx_data),
        .tx_keep(intf.tx_keep),
        .tx_valid(intf.tx_valid),
        .tx_ready(intf.tx_ready),
        .tx_sop(intf.tx_sop),
        .tx_eop(intf.tx_eop),
        .tx_empty(intf.tx_empty),
        .tx_seq_num(intf.tx_seq_num),
        .tx_vc_id(intf.tx_vc_id),
        .tx_tc(intf.tx_tc),
        .rx_data(intf.rx_data),
        .rx_keep(intf.rx_keep),
        .rx_valid(intf.rx_valid),
        .rx_ready(intf.rx_ready),
        .rx_sop(intf.rx_sop),
        .rx_eop(intf.rx_eop),
        .rx_empty(intf.rx_empty),
        .rx_seq_num(intf.rx_seq_num),
        .rx_vc_id(intf.rx_vc_id),
        .rx_tc(intf.rx_tc)
    );

    initial begin
        uvm_config_db#(virtual pcie_tlp_rc_driver_bfm)::set(null, "*", "pcie_tlp_rc_driver_bfm", rc_drv_bfm);
        uvm_config_db#(virtual pcie_tlp_rc_monitor_bfm)::set(null, "*", "pcie_tlp_rc_monitor_bfm", rc_mon_bfm);
        `uvm_info("PCIE_TLP_RC_AGENT_BFM", $sformatf("RC Agent BFM instantiated with ID %0d", RC_ID), UVM_LOW)
    end

endmodule : pcie_tlp_rc_agent_bfm

`endif
