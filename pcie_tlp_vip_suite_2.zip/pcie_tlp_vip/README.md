# PCIe TLP VIP

A reusable, UVM-1.2 based PCIe Transaction-Layer-Packet Verification IP,
in a single unified layout: RC and EP each get their own driver/monitor/
agent under `src/hvl_top/{rc,ep}`, sharing one `pcie_tlp_globals_pkg` and
one `pcie_tlp_if` boundary, integrated by a common env/scoreboard and a
single `hdl_top`/`hvl_top` pair.

## Directory layout

```
pcie_tlp_vip/
├── README.md, LICENSE.md, coding_guidelines.md, contribution_guidelines.md, pcie_script
├── docs/                             # architecture, verification/coverage/assertion plans, user guide
├── src/
│   ├── globals/pcie_tlp_globals_pkg.sv     # pcie_tlp_seq_item, enums, callbacks base (shared by RC+EP)
│   ├── hdl_top/
│   │   ├── pcie_tlp_interface/pcie_tlp_if.sv   # generic TX/RX streaming boundary (DLL-ready)
│   │   ├── rc_agent_bfm/                        # RC driver/monitor BFMs + agent BFM wrapper
│   │   ├── ep_agent_bfm/                        # EP driver/monitor BFMs + agent BFM wrapper
│   │   ├── pcie_tlp_rc_assertions.sv
│   │   ├── pcie_tlp_ep_assertions.sv
│   │   └── pcie_tlp_hdl_top.sv                   # Mode 1 default: RC BFM <-> EP BFM on one shared pcie_tlp_if
│   └── hvl_top/
│       ├── rc/                        # agent_config, sequencer, driver_proxy, monitor_proxy, coverage, agent, sequences/
│       ├── ep/                        # same, plus pcie_tlp_ep_memory.sv (BAR + config-space model)
│       ├── env/                       # pcie_tlp_env(_config), virtual_sequencer, scoreboard
│       ├── test/                      # base/mem_write/mem_read/cfg_access/error_injection tests + virtual_sequences/
│       ├── testlists/pcie_tlp_regression.list
│       └── pcie_tlp_hvl_top.sv
└── sim/                                # compile.f, makefile + questasim/cadence_sim/synopsys_sim, regression_handling.py
```

`pcie_dll_vip/` (DLL scaffold) and `examples/` (vip_to_vip, vip_to_dut,
vip_to_dll) are siblings of this folder in the suite root, not nested
inside it -- the DLL is a distinct future layer, and the examples show
this VIP wired to different partners without living inside it.

## Quick start

```bash
cd sim
make SIM=questa TEST=pcie_tlp_mem_read_test
```

`pcie_tlp_hdl_top.sv` builds both an RC agent BFM and an EP agent BFM on
one shared `pcie_tlp_if` (VIP-to-VIP, Mode 1) by default. For Mode 2
(VIP-to-DUT) or DLL integration, see `../examples/` -- those swap in a
different `hdl_top` that instantiates only one agent BFM alongside a DUT
or the DLL agent, reusing every file under `src/` here unchanged.

## Requirement-to-file map

| Requirement | Where |
|---|---|
| RC agent (active/passive), coverage, analysis ports, callbacks | `src/hvl_top/rc/pcie_tlp_rc_agent.sv`, `pcie_tlp_rc_coverage.sv`, `request_ap`/`completion_ap`, `pcie_tlp_callbacks` in globals pkg |
| EP agent (decode, memory model, UR/CA/CRS completions, delay, error injection) | `src/hvl_top/ep/pcie_tlp_ep_memory.sv`, `pcie_tlp_ep_driver_proxy.sv` |
| Mem/Config Read/Write, posted/non-posted, 3DW/4DW, payload, configurable IDs | `pcie_tlp_seq_item` (globals pkg) + `src/hvl_top/rc/sequences/pcie_tlp_rc_base_seq.sv` |
| Scoreboard: tag/ID/byte-count/payload/status, violation reporting | `src/hvl_top/env/pcie_tlp_scoreboard.sv` |
| Configuration (active/passive, addr width, MPS, MRRS, timeout, error injection) | `pcie_tlp_rc_agent_config.sv`, `pcie_tlp_ep_agent_config.sv`, `pcie_tlp_env_config.sv` |
| Example tests | `src/hvl_top/test/pcie_tlp_mem_write_test.sv`, `pcie_tlp_mem_read_test.sv`, `pcie_tlp_cfg_access_test.sv`, `pcie_tlp_error_injection_test.sv` |
| Diagrams | `../docs/pcie_architecture_document.md` (Mermaid) |

See `docs/pcie_user_guide.md` for full run/extend instructions.
