# Contribution Guidelines

1. Open an issue describing the TLP feature/bug before large changes.
2. One logical change per PR; keep RC-only and EP-only changes separate
   commits even within the same PR.
3. Run `sim/regression_handling.py --sim questa` (or your simulator) and
   attach the summary before requesting review.
4. New opcodes/statuses require: globals pkg update, coverage bins,
   scoreboard handling, and at least one directed test in
   `src/hvl_top/test/`.
5. Follow `coding_guidelines.md`. Non-conforming files will be asked to
   change before merge, not rewritten by reviewers.
6. Do not add ACK/NAK, replay, sequence-number-for-retry, or
   flow-control-credit signals to `pcie_tlp_if` -- those belong to a DLL
   VIP layered below it.
