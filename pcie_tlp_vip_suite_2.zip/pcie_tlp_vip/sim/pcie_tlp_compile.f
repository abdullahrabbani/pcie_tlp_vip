// pcie_tlp_vip unified compile order: globals -> interface -> RC/EP BFMs
// -> assertions -> hdl_top -> rc/ep hvl pkgs -> env pkg (scoreboard,
// virtual sequencer) -> test pkg -> hvl_top.
-timescale 1ns/1ps
+incdir+../src/globals
+incdir+../src/hdl_top/pcie_tlp_interface
+incdir+../src/hdl_top/rc_agent_bfm
+incdir+../src/hdl_top/ep_agent_bfm
+incdir+../src/hvl_top/rc
+incdir+../src/hvl_top/rc/sequences
+incdir+../src/hvl_top/ep
+incdir+../src/hvl_top/ep/sequences
+incdir+../src/hvl_top/env
+incdir+../src/hvl_top/test
+incdir+../src/hvl_top/test/virtual_sequences

../src/globals/pcie_tlp_globals_pkg.sv

../src/hdl_top/pcie_tlp_interface/pcie_tlp_if.sv
../src/hdl_top/rc_agent_bfm/pcie_tlp_rc_driver_bfm.sv
../src/hdl_top/rc_agent_bfm/pcie_tlp_rc_monitor_bfm.sv
../src/hdl_top/rc_agent_bfm/pcie_tlp_rc_agent_bfm.sv
../src/hdl_top/ep_agent_bfm/pcie_tlp_ep_driver_bfm.sv
../src/hdl_top/ep_agent_bfm/pcie_tlp_ep_monitor_bfm.sv
../src/hdl_top/ep_agent_bfm/pcie_tlp_ep_agent_bfm.sv
../src/hdl_top/pcie_tlp_rc_assertions.sv
../src/hdl_top/pcie_tlp_ep_assertions.sv
../src/hdl_top/pcie_tlp_hdl_top.sv

../src/hvl_top/rc/pcie_tlp_rc_pkg.sv
../src/hvl_top/ep/pcie_tlp_ep_pkg.sv
../src/hvl_top/env/pcie_tlp_env_pkg.sv
../src/hvl_top/test/pcie_tlp_test_pkg.sv
../src/hvl_top/pcie_tlp_hvl_top.sv
