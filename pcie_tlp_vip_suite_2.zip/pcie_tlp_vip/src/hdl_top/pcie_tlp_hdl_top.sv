`ifndef PCIE_TLP_HDL_TOP_SV
`define PCIE_TLP_HDL_TOP_SV

// VIP-to-VIP HDL top (Mode 1): one shared pcie_tlp_if instance whose
// tx_*/rx_* are cross-connected between an RC agent BFM and an EP agent
// BFM. Because pcie_tlp_if is symmetric (tx_*/rx_* are just "this side
// out" / "this side in"), a single interface instance IS the link: what
// the RC agent transmits is what the EP agent receives, and vice versa.
module pcie_tlp_hdl_top;
  import uvm_pkg::*;
`include "uvm_macros.svh"

  bit clk;
  bit rst_n;
  initial clk = 0;
  always #5 clk = ~clk;
  initial begin
    rst_n = 0;
    #20 rst_n = 1;
  end

  pcie_tlp_if link_if (.clk(clk), .rst_n(rst_n));

  pcie_tlp_rc_agent_bfm rc_agent_bfm_h (.vif(link_if));
  pcie_tlp_ep_agent_bfm ep_agent_bfm_h (.vif(link_if));

  initial begin
    uvm_config_db#(virtual pcie_tlp_rc_driver_bfm)::set(null, "*rc_agent_h*", "bfm", rc_agent_bfm_h.rc_driver_bfm_h);
    uvm_config_db#(virtual pcie_tlp_rc_monitor_bfm)::set(null, "*rc_agent_h*", "bfm", rc_agent_bfm_h.rc_monitor_bfm_h);
    uvm_config_db#(virtual pcie_tlp_ep_driver_bfm)::set(null, "*ep_agent_h*", "bfm", ep_agent_bfm_h.ep_driver_bfm_h);
    uvm_config_db#(virtual pcie_tlp_ep_monitor_bfm)::set(null, "*ep_agent_h*", "bfm", ep_agent_bfm_h.ep_monitor_bfm_h);
  end

  pcie_tlp_rc_assertions rc_assertions_h (.vif(link_if));
  pcie_tlp_ep_assertions ep_assertions_h (.vif(link_if));

endmodule : pcie_tlp_hdl_top

`endif
