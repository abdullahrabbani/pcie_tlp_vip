# video_pcie_vip.mp4 -- storyboard (text stand-in)

This environment cannot render an actual narrated video, so here is the
walkthrough script/storyboard the video would follow; each scene maps to
a diagram in `pcie_architecture_document.md` or a file in the repo, so it
can be recorded separately with screen capture + this narration.

1. **Title / scope (0:00)** -- "Two independent PCIe TLP VIPs: RC and EP,
   reusable standalone or together." Show `README.md` directory map.
2. **Why no ACK/NAK here (0:20)** -- show `pcie_tlp_if.sv`, point out the
   absence of sequence-number/credit signals; show the Mermaid layering
   diagram from the architecture doc.
3. **RC agent internals (0:50)** -- open `pcie_tlp_rc_agent.sv`, trace
   build_phase creating sequencer/driver/monitor/coverage; overlay the
   block-diagram Mermaid figure.
4. **RC driver flow (1:30)** -- step through `pcie_tlp_rc_driver_proxy.sv`
   run_phase alongside the "RC driver_proxy flow" flowchart.
5. **EP memory model + completion policy (2:10)** -- open
   `pcie_tlp_ep_memory.sv` then `build_completion()` in
   `pcie_tlp_ep_driver_proxy.sv`; overlay the "EP driver_proxy flow"
   flowchart, calling out the UR/CA/SC branches.
6. **Run VIP-to-VIP (3:00)** -- terminal: `cd pcie_tlp_vip/sim && make SIM=questa
   TEST=pcie_tlp_mem_read_test`; show log output and scoreboard
   `report_phase` summary.
7. **Swap in a DUT (3:40)** -- show `examples/vip_to_dut/`, highlight that
   only the module instantiated on the EP side of `pcie_tlp_if` changed.
8. **DLL boundary slot (4:10)** -- show `examples/vip_to_dll/`, explain
   the passthrough stub is where a future DLL VIP plugs in.
9. **Close (4:40)** -- recap requirement-to-deliverable table in the
   top-level `README.md`.
