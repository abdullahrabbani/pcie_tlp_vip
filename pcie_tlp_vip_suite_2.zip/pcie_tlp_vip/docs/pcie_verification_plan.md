# PCIe TLP VIP Verification Plan

## 1. Objectives

Verify that the RC TLP VIP and EP TLP VIP correctly generate, transport,
and check PCIe Transaction Layer Packets across all three supported
topologies (VIP-to-VIP, VIP-to-DUT, VIP-to-DLL boundary), for the request/
completion classes listed in section 3.

## 2. DUT / environment under test

The "DUT" varies by mode:
- Mode 1: no external DUT -- RC VIP and EP VIP verify each other.
- Mode 2: a real Endpoint or Root Complex RTL DUT, VIP on the other side.
- DLL integration: a (future) DLL VIP or RTL DLL sits below the TLP VIP.

## 3. Features to verify

| # | Feature | Test(s) |
|---|---|---|
| 1 | Memory Write, posted, 3DW | `pcie_tlp_mem_write_test` |
| 2 | Memory Write, posted, 4DW (addr[63:32]!=0) | `pcie_tlp_mem_write_seq` (randomizes 3DW/4DW) |
| 3 | Memory Read, non-posted, readback matches write | `pcie_tlp_mem_read_test` |
| 4 | Config Write / Read | `pcie_tlp_cfg_access_test` |
| 5 | Successful Completion (SC), with and without data | `pcie_tlp_mem_read_test`, `pcie_tlp_cfg_access_test` |
| 6 | Unsupported Request (UR) -- out-of-range address | `pcie_tlp_error_injection_test` |
| 7 | Completer Abort (CA) -- explicit error injection | `pcie_tlp_error_injection_test` |
| 8 | Delayed completion | `pcie_tlp_error_injection_test` (`delayed_completion_min/max_cycles`) |
| 9 | Completion timeout detection (RC side) | directed: set `completion_timeout_ns` low, don't respond from EP; expect `uvm_error` |
| 10 | Requester ID / Tag correlation across concurrent outstanding requests | directed: multiple `do_mem_read` with distinct tags before draining |
| 11 | Byte-enable handling (first_be/last_be) on partial-DW writes | directed: 1-DW write with non-0xF `first_be`/`last_be`, check `EP memory` byte-level state |
| 12 | Active vs Passive agent mode | build both agents `UVM_PASSIVE`, confirm no sequencer/driver created, only monitor/coverage active |
| 13 | 32-bit vs 64-bit address width | `addr_width` config sweeps combined with mem_read/write |
| 14 | Scoreboard: unmatched completion detection | directed: monitor_proxy sees a spoofed/injected completion with no matching request |
| 15 | Scoreboard: request never completed detection | directed: EP configured to silently drop instead of complete; check `report_phase` error |
| 16 | VIP-to-DUT (RC VIP <-> EP DUT stub) | `examples/vip_to_dut` |
| 17 | VIP-to-DLL passthrough boundary | `examples/vip_to_dll` |

## 4. Test strategy

- **Directed tests** for protocol-defined corner cases (UR/CA/CRS,
  4DW header boundary, byte-enable edge cases, timeout).
- **Constrained-random** for opcode/length/TC/attribute mixes
  (`pcie_tlp_seq_item` constraints, overridden per-sequence with `with {}`).
- **Regression** via `sim/regression_handling.py`, driven by
  `src/hvl_top/testlists/pcie_tlp_regression.list`.
- The DLL-integrated stack (`examples/vip_to_dll/`) is regressed
  separately via `pcie_dll_vip/sim/`, since it adds `pcie_dll_agent`
  into the mix on top of the same RC/EP sequences and scoreboard.

## 5. Pass/fail criteria

- Zero `UVM_ERROR`/`UVM_FATAL` in a test run (excluding intentionally
  injected/expected errors, which are checked via explicit sequence-level
  assertions, not by suppressing the log).
- Scoreboard `report_phase` shows `num_protocol_violations == 0` for
  non-error-injection tests.
- Functional coverage (see `pcie_coverage_plan.md`) at or above the
  target closure percentage before sign-off.

## 6. Regression entry points

```
pcie_tlp_vip/sim/regression_handling.py   # Mode 1 (VIP-to-VIP) regression
pcie_dll_vip/sim/                          # DLL-integrated stack (examples/vip_to_dll)
```
