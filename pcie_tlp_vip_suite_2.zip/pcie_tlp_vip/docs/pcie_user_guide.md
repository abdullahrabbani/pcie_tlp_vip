# PCIe TLP VIP User Guide

## 1. Prerequisites

- A SystemVerilog simulator with UVM 1.2 support (Questa, Xcelium, or VCS
  -- makefiles provided for all three under `sim/`).
- `UVM_HOME` (or simulator-specific equivalent) pointing at a UVM 1.2
  installation, unless your simulator bundles it.

## 2. Running VIP-to-VIP (Mode 1, the default)

```bash
cd pcie_tlp_vip/sim
make SIM=questa TEST=pcie_tlp_mem_read_test
make SIM=questa TEST=pcie_tlp_mem_write_test
make SIM=questa TEST=pcie_tlp_cfg_access_test
make SIM=questa TEST=pcie_tlp_error_injection_test
```

`pcie_tlp_hdl_top.sv` builds an RC agent BFM and an EP agent BFM on one
shared `pcie_tlp_if` by default -- this is Mode 1. Switch simulators with
`SIM=cadence` or `SIM=synopsys`. Override the random seed with `SEED=<n>`
and message verbosity with `VERBOSITY=UVM_HIGH` (useful for per-beat BFM
tracing).

## 3. Running VIP-to-DUT (Mode 2)

See `../examples/vip_to_dut/README.md`. In short: compile
`examples/vip_to_dut/pcie_tlp_vip_to_dut_hdl_top.sv` instead of
`pcie_tlp_vip/src/hdl_top/pcie_tlp_hdl_top.sv`, replacing
`pcie_tlp_ep_dut_stub` with your real Endpoint RTL (same `pcie_tlp_if.DUT`
modport). Every file under `pcie_tlp_vip/src/hvl_top/rc/` (agent, config,
sequences, tests) is unchanged -- only which `hdl_top` you compile
differs. The mirror case (RC DUT <-> EP VIP) is structurally identical on
the EP side.

## 4. Connecting a DLL layer

See `../examples/vip_to_dll/README.md` and `../pcie_dll_vip/README.md`.
Compile `examples/vip_to_dll/pcie_tlp_vip_to_dll_hdl_top.sv`, which wires
`pcie_dll_agent_bfm` (from `pcie_dll_vip/`) between the RC and EP agent
BFMs instead of the single shared `pcie_tlp_if` Mode-1 uses. No changes
to `pcie_tlp_vip/src/` are required either way.

## 5. Writing a new directed test

```systemverilog
class my_test extends pcie_tlp_base_test;
  `uvm_component_utils(my_test)
  function new(string name = "my_test", uvm_component parent = null);
    super.new(name, parent);
  endfunction

  task run_phase(uvm_phase phase);
    pcie_tlp_rc_base_seq seq;
    pcie_tlp_seq_item cpl;
    bit [31:0] wdata[] = '{32'hA5A5_A5A5};
    phase.raise_objection(this);
    seq = pcie_tlp_rc_base_seq::type_id::create("seq");
    seq.do_mem_write(64'h1000_0100, wdata, 16'h0100, 8'h05);
    seq.do_mem_read(64'h1000_0100, 1, 16'h0100, cpl, 8'h06);
    if (cpl.payload[0] !== wdata[0])
      `uvm_error(get_name(), "readback mismatch")
    phase.drop_objection(this);
  endtask
endclass
```

Add the class to `src/hvl_top/test/pcie_tlp_test_pkg.sv`'s `\`include`
list, and to `src/hvl_top/testlists/pcie_tlp_regression.list`.

## 6. Configuration reference

| Config object | Field | Meaning |
|---|---|---|
| `pcie_tlp_rc_agent_config` | `is_active` | `UVM_ACTIVE`/`UVM_PASSIVE` |
| | `addr_width` | `ADDR_32BIT`/`ADDR_64BIT` |
| | `requester_id` | RC's Requester ID field for all requests |
| | `max_payload_size_bytes`, `max_read_req_size_bytes` | MPS/MRRS, informational -- enforce in sequences via `length_dw` constraints |
| | `completion_timeout_ns` | RC driver_proxy error threshold for missing completions |
| | `error_injection_enable` | gates whether `req.inject_error` is honored |
| `pcie_tlp_ep_agent_config` | `completer_id` | EP's Completer ID field for all completions |
| | `mem_size_bytes` | size of the modeled BAR window (`pcie_tlp_ep_memory`) |
| | `delayed_completion_min/max_cycles` | randomized extra latency window before EP responds |
| `pcie_tlp_env_config` | `mode` | one of `MODE_VIP_TO_VIP`, `MODE_VIP_TO_EP_DUT`, `MODE_RC_DUT_TO_VIP`, `MODE_WITH_DLL` (drives which agents `pcie_tlp_env` builds) |

## 7. Troubleshooting

| Symptom | Likely cause |
|---|---|
| `NOVIF` fatal at build_phase | forgot to `uvm_config_db#(virtual pcie_tlp_*_bfm)::set(...)` in your `hdl_top` before `run_test()` |
| `completion timeout` on every non-posted request | nothing connected to the RC's `rx_*`, or EP agent built `UVM_PASSIVE` |
| `Byte count mismatch` from scoreboard | check `length_dw` / `first_be`/`last_be` on the request match what the EP model wrote/read |
| No coverage collected | `coverage_h` is only connected for the monitor's `request_ap` (RC) / `completion_ap` (EP) -- confirm you're checking the right covergroup for the traffic direction you generated |
