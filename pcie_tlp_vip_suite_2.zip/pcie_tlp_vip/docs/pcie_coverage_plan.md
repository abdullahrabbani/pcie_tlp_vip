# PCIe TLP VIP Coverage Plan

## 1. Coverage model overview

Two covergroups, one per agent role, each sampled from the corresponding
agent's `coverage_h` (`uvm_subscriber`) on every observed transaction.

## 2. RC coverage (`pcie_tlp_rc_coverage.rc_tlp_cg`)

| Coverpoint | Bins | Purpose |
|---|---|---|
| `cp_opcode` | all `pcie_tlp_opcode_e` values | every request/completion type issued from RC side |
| `cp_tc` | 0-7 (auto) | Traffic Class spread |
| `cp_attr` | 0-3 (auto) | Relaxed Ordering / No Snoop combinations |
| `cp_hdr` | `dw3`, `dw4` | 3DW vs 4DW header usage |
| `cp_len` | `zero`, `small(1-16)`, `medium(17-64)`, `large(65+)` | payload size distribution |
| `cp_err` | 0/1 | error-injected vs. clean requests observed from RC |
| `cross_opcode_len` | `cp_opcode x cp_len` | every opcode exercised across the length spectrum, not just once |

## 3. EP coverage (`pcie_tlp_ep_coverage.ep_tlp_cg`)

| Coverpoint | Bins | Purpose |
|---|---|---|
| `cp_opcode` | all `pcie_tlp_opcode_e` values | completion types generated |
| `cp_status` | `SC`, `UR`, `CRS`, `CA` | every completion status class hit at least once |
| `cp_delay` | `none(0)`, `some(1+)` | delayed-completion path exercised |
| `cp_err` | 0/1 | error-injection path exercised |
| `cross_status_err` | `cp_status x cp_err` | e.g. confirms CA only paired with `inject_error=1`, and SC/UR reachable both with and without the feature enabled |

> `CRS` is defined in the status enum and scoreboard-checkable, but the
> reference `build_completion()` policy in this deliverable does not yet
> emit it (it only emits SC/UR/CA) -- see `pcie_verification_plan.md` #6
> and the "Extending" note in `pcie_tlp_vip`'s completion-policy section
> (`src/hvl_top/ep/pcie_tlp_ep_driver_proxy.sv`). Add a CRS path
> (e.g. for Configuration Requests to a not-yet-ready function) and its
> directed test before claiming closure on the `cp_status` CRS bin.

## 4. Structural / interface coverage (candidates for extension)

Not yet implemented as SystemVerilog covergroups in this deliverable, but
identified as required for full closure:
- `tx_ready`/`rx_ready` backpressure toggling per beat (stall vs. no-stall).
- Config Type 0 vs Type 1 request coverage (`TYPE_CFG0_RW` vs
  `TYPE_CFG1_RW` -- currently the seq_item model only builds Type 0).
- Back-to-back non-posted requests with outstanding-tag depth > 1.

## 5. Closure process

1. Run the full regression (`sim/regression_handling.py`).
2. Merge coverage databases per simulator's standard flow (e.g.
   `vcover merge` for Questa).
3. Review cross-bin holes first (`cross_opcode_len`,
   `cross_status_err`) -- these catch combinations directed tests miss
   even when each axis individually looks closed.
4. File a coverage-hole ticket per open bin; do not waive without a
   documented reason (e.g. "CRS bin: not modeled by this EP policy yet,
   tracked in issue #NN").
