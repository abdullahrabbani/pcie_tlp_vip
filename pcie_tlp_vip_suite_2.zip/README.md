# PCIe VIP Suite

Three sibling deliverables, unzip and use together or independently:

```
.
├── pcie_tlp_vip/    # the PCIe TLP VIP itself -- RC + EP agents, unified
│                     # single layout (src/hvl_top/rc + src/hvl_top/ep
│                     # together, one hdl_top/hvl_top, one sim/)
├── pcie_dll_vip/    # scaffolded Data Link Layer model (seq num, replay
│                     # buffer, ACK/NAK, credit-based flow control) that
│                     # plugs into pcie_tlp_vip's pcie_tlp_if boundary
└── examples/        # vip_to_vip, vip_to_dut, vip_to_dll -- worked
                       # examples showing pcie_tlp_vip wired to each kind
                       # of partner
```

Start with `pcie_tlp_vip/README.md` -- it has the full directory map,
quick-start commands, and a requirement-to-file table. `pcie_tlp_vip/docs/`
has the architecture document (Mermaid diagrams), verification/coverage/
assertion plans, and user guide.

`pcie_dll_vip/` and `examples/` are kept as siblings rather than nested
inside `pcie_tlp_vip/` because they're both about *connecting to*
`pcie_tlp_vip`, not part of the VIP's own required deliverable set.
