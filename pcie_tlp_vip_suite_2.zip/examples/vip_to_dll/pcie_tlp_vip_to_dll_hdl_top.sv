//-----------------------------------------------------------------------------
// pcie_tlp_vip_to_dll_hdl_top.sv
// Full stack: RC TLP VIP <-> pcie_dll_agent_bfm <-> EP TLP VIP. Each TLP
// VIP only ever sees a plain pcie_tlp_if; the DLL agent_bfm does real
// seq-num/replay/credit accounting per direction in between. Compare to
// pcie_tlp_vip/src/hdl_top/pcie_tlp_hdl_top.sv (Mode 1, no DLL) -- the only
// difference is this extra module and the two pcie_tlp_if instances
// instead of one shared instance.
//-----------------------------------------------------------------------------
module pcie_tlp_vip_to_dll_hdl_top;
  import uvm_pkg::*;
`include "uvm_macros.svh"

  bit clk;
  bit rst_n;
  initial clk = 0;
  always #5 clk = ~clk;
  initial begin rst_n = 0; #20 rst_n = 1; end

  pcie_tlp_if rc_side_if (.clk(clk), .rst_n(rst_n)); // RC TLP VIP <-> DLL
  pcie_tlp_if ep_side_if (.clk(clk), .rst_n(rst_n)); // DLL <-> EP TLP VIP

  pcie_tlp_rc_agent_bfm rc_agent_bfm_h (.vif(rc_side_if));
  pcie_tlp_ep_agent_bfm ep_agent_bfm_h (.vif(ep_side_if));

  pcie_dll_agent_bfm #(
    .REPLAY_TIMEOUT_CYCLES (200),
    .MAX_REPLAY_COUNT      (4)
  ) dll_agent_bfm_h (
    .side_a (rc_side_if),
    .side_b (ep_side_if)
  );

  initial begin
    uvm_config_db#(virtual pcie_tlp_rc_driver_bfm)::set(null, "*rc_agent_h*", "bfm", rc_agent_bfm_h.rc_driver_bfm_h);
    uvm_config_db#(virtual pcie_tlp_rc_monitor_bfm)::set(null, "*rc_agent_h*", "bfm", rc_agent_bfm_h.rc_monitor_bfm_h);
    uvm_config_db#(virtual pcie_tlp_ep_driver_bfm)::set(null, "*ep_agent_h*", "bfm", ep_agent_bfm_h.ep_driver_bfm_h);
    uvm_config_db#(virtual pcie_tlp_ep_monitor_bfm)::set(null, "*ep_agent_h*", "bfm", ep_agent_bfm_h.ep_monitor_bfm_h);

    // DLL agent config_db field names ("a_to_b_bfm"/"b_to_a_bfm") match
    // pcie_dll_driver_proxy/pcie_dll_monitor_proxy.bfm_name.
    uvm_config_db#(virtual pcie_dll_driver_bfm)::set(null, "*dll_agent_h*", "a_to_b_bfm", dll_agent_bfm_h.a_to_b_bfm_h);
    uvm_config_db#(virtual pcie_dll_driver_bfm)::set(null, "*dll_agent_h*", "b_to_a_bfm", dll_agent_bfm_h.b_to_a_bfm_h);
  end

  pcie_tlp_rc_assertions rc_assertions_h (.vif(rc_side_if));
  pcie_tlp_ep_assertions ep_assertions_h (.vif(ep_side_if));

endmodule : pcie_tlp_vip_to_dll_hdl_top
