# Example: VIP connected to a DLL layer

Two variants:

## 1. `pcie_tlp_dll_passthrough_stub.sv` -- boundary illustration only
Pure combinational pass-through between a TLP-VIP-facing `pcie_tlp_if`
and a PHY-facing `pcie_tlp_if`. Useful for confirming the interface
contract compiles/elaborates cleanly with nothing in between.

## 2. `pcie_tlp_vip_to_dll_hdl_top.sv` -- full stack with the DLL scaffold
`RC TLP VIP <-> pcie_dll_agent_bfm <-> EP TLP VIP`, using the (scaffolded)
`pcie_dll_vip` from `../../pcie_dll_vip/`. This is a real, if simplified,
functional DLL: sequence numbers, an internal ACK/NAK side-channel, a
replay buffer with timeout-driven retransmit, and credit-based flow
control accounting classified from the TLP header's Fmt/Type/Length
fields.

Both TLP VIPs are completely unmodified from the VIP-to-VIP example --
they only ever see `pcie_tlp_if`. Swap `pcie_dll_agent_bfm` for a
bit-accurate DLL (real DLLP encoding, LCRC, credit-return-on-drain
instead of the current auto-return simplification) whenever that's
built, again without touching `pcie_tlp_vip`.

See `pcie_dll_vip/README.md` for what's modeled vs. simplified in the
current scaffold, and `docs/pcie_architecture_document.md` §1 for how
this fits the overall layering.
