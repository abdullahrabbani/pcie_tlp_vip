`ifndef PCIE_TLP_DLL_SMOKE_TEST_SV
`define PCIE_TLP_DLL_SMOKE_TEST_SV

// Same write-then-readback check as pcie_tlp_vip/src/hvl_top/test/pcie_tlp_mem_read_test.sv, but now
// routed through pcie_dll_agent -- exercises sequence tagging, credit
// accounting, and (if you shrink REPLAY_TIMEOUT_CYCLES enough relative
// to link latency) the replay path, end to end.
class pcie_tlp_dll_smoke_seq extends pcie_tlp_rc_base_seq;
  `uvm_object_utils(pcie_tlp_dll_smoke_seq)
  function new(string name = "pcie_tlp_dll_smoke_seq"); super.new(name); endfunction

  virtual task body();
    bit [31:0] wdata[] = '{32'hDEAD_BEEF, 32'hCAFE_F00D, 32'h1111_2222, 32'h3333_4444};
    pcie_tlp_seq_item cpl;
    do_mem_write(64'h1000_0000, wdata, 16'h0100, 8'h30);
    do_mem_read(64'h1000_0000, 4, 16'h0100, cpl, 8'h31);
    if (cpl.cpl_status == CPL_SC && cpl.payload.size() == 4) begin
      foreach (wdata[i])
        if (cpl.payload[i] !== wdata[i])
          `uvm_error(get_name(), $sformatf("Readback mismatch (via DLL) at dw%0d: exp=0x%0h got=0x%0h",
                     i, wdata[i], cpl.payload[i]))
    end else
      `uvm_error(get_name(), $sformatf("Unexpected completion via DLL: %s", cpl.convert2string()))
  endtask
endclass : pcie_tlp_dll_smoke_seq

class pcie_tlp_dll_smoke_test extends uvm_test;
  `uvm_component_utils(pcie_tlp_dll_smoke_test)

  pcie_tlp_dll_env env_h;

  function new(string name = "pcie_tlp_dll_smoke_test", uvm_component parent = null);
    super.new(name, parent);
  endfunction

  function void build_phase(uvm_phase phase);
    super.build_phase(phase);
    env_h = pcie_tlp_dll_env::type_id::create("env_h", this);
  endfunction

  task run_phase(uvm_phase phase);
    pcie_tlp_dll_smoke_seq seq;
    phase.raise_objection(this);
    seq = pcie_tlp_dll_smoke_seq::type_id::create("seq");
    seq.start(env_h.rc_agent_h.sequencer_h);
    #2000ns;
    phase.drop_objection(this);
  endtask
endclass : pcie_tlp_dll_smoke_test

`endif
