//-----------------------------------------------------------------------------
// pcie_dll_driver_bfm.sv
//
// One direction of the DLL: captures TLPs off rx_if, credit-gates them,
// tags with a sequence number, retires (self-)acks immediately on
// forward (see pcie_dll_vip/README.md for why), and drives them out on
// tx_if. A replay watchdog retransmits on timeout.
//
// This interface owns all wire-level and per-direction state; the HVL
// pcie_dll_driver_proxy owns the run_phase loop and publishes
// pcie_dll_event structs pulled from event_mbx onto its analysis port --
// the same driver_bfm/driver_proxy split used by pcie_tlp_vip's RC/EP agents.
//-----------------------------------------------------------------------------
`ifndef PCIE_DLL_DRIVER_BFM_SV
`define PCIE_DLL_DRIVER_BFM_SV

interface pcie_dll_driver_bfm #(
  parameter int REPLAY_TIMEOUT_CYCLES = 200,
  parameter int MAX_REPLAY_COUNT      = 4,
  parameter int INIT_P_HDR_CREDITS    = 64,
  parameter int INIT_P_DATA_CREDITS   = 256,
  parameter int INIT_NP_HDR_CREDITS   = 32,
  parameter int INIT_CPL_HDR_CREDITS  = 64,
  parameter int INIT_CPL_DATA_CREDITS = 256
) (
  pcie_tlp_if.DUT rx_if,
  pcie_tlp_if.DUT tx_if
);

  import uvm_pkg::*;
  import pcie_tlp_globals_pkg::*; // reused only for Fmt/Type constants used in FC classification
  import pcie_dll_globals_pkg::*;
`include "uvm_macros.svh"

  string name = "PCIE_DLL_DRIVER_BFM";

  pcie_dll_direction_e     direction; // set by hdl_top after binding
  int unsigned              next_seq;
  pcie_dll_replay_entry_t   replay_q[$];
  pcie_dll_credits_t        credits;
  mailbox #(pcie_dll_event) event_mbx;

  function automatic void init(pcie_dll_direction_e dir);
    direction = dir;
    next_seq  = 0;
    credits.p_header_avail   = INIT_P_HDR_CREDITS;
    credits.p_data_avail     = INIT_P_DATA_CREDITS;
    credits.np_header_avail  = INIT_NP_HDR_CREDITS;
    credits.cpl_header_avail = INIT_CPL_HDR_CREDITS;
    credits.cpl_data_avail   = INIT_CPL_DATA_CREDITS;
    event_mbx = new();
  endfunction

  function automatic void classify(
    input  bit [31:0]         dw0,
    output pcie_dll_fc_type_e fc_type,
    output int unsigned       header_credits,
    output int unsigned       data_credits
  );
    bit [1:0] fmt       = dw0[30:29];
    bit [4:0] tlp_type  = dw0[28:24];
    bit [9:0] length_dw = dw0[9:0];
    bit       has_data  = fmt[1];

    header_credits = 1;
    data_credits   = has_data ? (((length_dw*4) + PCIE_DLL_CREDIT_UNIT_BYTES-1) /
                                   PCIE_DLL_CREDIT_UNIT_BYTES) : 0;
    if (tlp_type == TYPE_CPL || tlp_type == TYPE_CPL_LK) fc_type = FC_CPL;
    else if (has_data || tlp_type == TYPE_MSG)           fc_type = FC_POSTED;
    else                                                  fc_type = FC_NON_POSTED;
  endfunction

  function automatic bit credits_available(pcie_dll_fc_type_e fc_type,
                                            int unsigned hdr_c, int unsigned data_c);
    case (fc_type)
      FC_POSTED:     return (credits.p_header_avail   >= hdr_c) && (credits.p_data_avail   >= data_c);
      FC_NON_POSTED: return (credits.np_header_avail  >= hdr_c);
      FC_CPL:        return (credits.cpl_header_avail >= hdr_c) && (credits.cpl_data_avail >= data_c);
    endcase
  endfunction

  function automatic void spend_credits(pcie_dll_fc_type_e fc_type,
                                         int unsigned hdr_c, int unsigned data_c);
    case (fc_type)
      FC_POSTED:     begin credits.p_header_avail   -= hdr_c; credits.p_data_avail   -= data_c; end
      FC_NON_POSTED: begin credits.np_header_avail  -= hdr_c; end
      FC_CPL:        begin credits.cpl_header_avail -= hdr_c; credits.cpl_data_avail -= data_c; end
    endcase
  endfunction

  // Simplified: freed the instant the packet is forwarded (always-
  // draining-receiver model) -- see README for the fidelity note.
  function automatic void return_credits(pcie_dll_fc_type_e fc_type,
                                          int unsigned hdr_c, int unsigned data_c);
    case (fc_type)
      FC_POSTED:     begin credits.p_header_avail   += hdr_c; credits.p_data_avail   += data_c; end
      FC_NON_POSTED: begin credits.np_header_avail  += hdr_c; end
      FC_CPL:        begin credits.cpl_header_avail += hdr_c; credits.cpl_data_avail += data_c; end
    endcase
  endfunction

  task automatic drive_beats(pcie_dll_replay_entry_t entry);
    for (int i = 0; i < entry.beat_data.size(); i++) begin
      @(posedge tx_if.clk);
      tx_if.tx_data  <= entry.beat_data[i];
      tx_if.tx_keep  <= entry.beat_keep[i];
      tx_if.tx_valid <= 1'b1;
      tx_if.tx_sop   <= (i == 0);
      tx_if.tx_eop   <= (i == entry.beat_data.size()-1);
      tx_if.tx_err   <= entry.beat_err[i];
      do @(posedge tx_if.clk); while (tx_if.tx_ready !== 1'b1);
    end
    @(posedge tx_if.clk);
    tx_if.tx_valid <= 1'b0;
    tx_if.tx_sop   <= 1'b0;
    tx_if.tx_eop   <= 1'b0;
  endtask

  //-------------------------------------------------------------
  // forward_one_packet: called in a loop by pcie_dll_driver_proxy.
  // Captures one TLP, credit-gates, sequences, pushes to the replay
  // buffer, forwards it, self-acks (retires it), and returns the
  // published event by reference for the proxy to write to its
  // analysis port (in addition to it being queued on event_mbx, which
  // pcie_dll_monitor_proxy also drains -- both exist so either the
  // driver-side or a fully passive monitor-side agent can observe it).
  //-------------------------------------------------------------
  task automatic forward_one_packet(output pcie_dll_event evt);
    pcie_dll_replay_entry_t entry;
    bit [31:0] dw0;
    pcie_dll_fc_type_e fc_type;
    int unsigned hdr_c, data_c;

    do @(posedge rx_if.clk); while (!(rx_if.rx_valid && rx_if.rx_sop));
    dw0 = rx_if.rx_data[31:0];
    classify(dw0, fc_type, hdr_c, data_c);

    while (!credits_available(fc_type, hdr_c, data_c))
      @(posedge rx_if.clk);
    spend_credits(fc_type, hdr_c, data_c);

    entry.seq_num     = next_seq++;
    entry.sent_time    = $time;
    entry.replay_count = 0;

    entry.beat_data.push_back(rx_if.rx_data);
    entry.beat_keep.push_back(rx_if.rx_keep);
    entry.beat_err.push_back(rx_if.rx_err);

    while (!rx_if.rx_eop) begin
      @(posedge rx_if.clk);
      if (rx_if.rx_valid) begin
        entry.beat_data.push_back(rx_if.rx_data);
        entry.beat_keep.push_back(rx_if.rx_keep);
        entry.beat_err.push_back(rx_if.rx_err);
      end
    end
    @(posedge rx_if.clk);

    replay_q.push_back(entry);
    drive_beats(entry);
    return_credits(fc_type, hdr_c, data_c);

    // self-ack: retire immediately (see class-level comment / README)
    while (replay_q.size() > 0 && replay_q[0].seq_num <= entry.seq_num)
      void'(replay_q.pop_front());

    evt = pcie_dll_event::type_id::create("evt");
    evt.direction      = direction;
    evt.kind           = DLL_EVT_FORWARD;
    evt.seq_num        = entry.seq_num;
    evt.fc_type        = fc_type;
    evt.header_credits = hdr_c;
    evt.data_credits   = data_c;
    evt.replay_count   = 0;
    evt.ack_status     = DLL_ACK;
    evt.event_time     = $time;
    event_mbx.put(evt);

    `uvm_info(name, $sformatf("[%s] %s", direction.name(), evt.convert2string()), UVM_HIGH)
  endtask

  //-------------------------------------------------------------
  // replay_watchdog: run continuously by pcie_dll_driver_proxy in a
  // parallel fork alongside forward_one_packet's loop.
  //-------------------------------------------------------------
  task automatic replay_watchdog();
    forever begin
      @(posedge tx_if.clk);
      if (replay_q.size() > 0 &&
          ($time - replay_q[0].sent_time) > (REPLAY_TIMEOUT_CYCLES * 10ns)) begin
        pcie_dll_event evt;
        replay_q[0].replay_count++;
        if (replay_q[0].replay_count > MAX_REPLAY_COUNT) begin
          evt = pcie_dll_event::type_id::create("evt");
          evt.direction    = direction;
          evt.kind         = DLL_EVT_LINK_DOWN;
          evt.seq_num      = replay_q[0].seq_num;
          evt.replay_count = replay_q[0].replay_count;
          evt.ack_status   = DLL_NAK;
          evt.event_time   = $time;
          event_mbx.put(evt);
          `uvm_error(name, $sformatf(
            "[%s] seq=%0d exceeded MAX_REPLAY_COUNT=%0d -- modeled link-down condition",
            direction.name(), replay_q[0].seq_num, MAX_REPLAY_COUNT))
        end
        else begin
          evt = pcie_dll_event::type_id::create("evt");
          evt.direction    = direction;
          evt.kind         = DLL_EVT_REPLAY;
          evt.seq_num      = replay_q[0].seq_num;
          evt.replay_count = replay_q[0].replay_count;
          evt.ack_status   = DLL_NAK;
          evt.event_time   = $time;
          event_mbx.put(evt);
          `uvm_warning(name, $sformatf("[%s] replay timeout seq=%0d attempt=%0d",
                       direction.name(), replay_q[0].seq_num, replay_q[0].replay_count))
          drive_beats(replay_q[0]);
          replay_q[0].sent_time = $time;
        end
      end
    end
  endtask

endinterface : pcie_dll_driver_bfm

`endif
