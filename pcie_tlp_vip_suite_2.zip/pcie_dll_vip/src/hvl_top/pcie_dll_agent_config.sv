`ifndef PCIE_DLL_AGENT_CONFIG_SV
`define PCIE_DLL_AGENT_CONFIG_SV

// Present for API symmetry with the RC/EP agent configs. pcie_dll_driver_bfm
// itself is currently parameterized directly (see its header) rather than
// reading this object via uvm_config_db -- wiring that up (replacing the
// module `#()` parameters with a proper config_db lookup, matching how
// pcie_tlp_vip's RC/EP agents source their config) is the next fidelity
// step listed in pcie_dll_vip/README.md.
class pcie_dll_agent_config extends uvm_object;
  `uvm_object_utils(pcie_dll_agent_config)

  int unsigned replay_timeout_cycles = 200;
  int unsigned max_replay_count      = 4;
  int unsigned init_p_hdr_credits    = 64;
  int unsigned init_p_data_credits   = 256;
  int unsigned init_np_hdr_credits   = 32;
  int unsigned init_cpl_hdr_credits  = 64;
  int unsigned init_cpl_data_credits = 256;

  function new(string name = "pcie_dll_agent_config");
    super.new(name);
  endfunction
endclass : pcie_dll_agent_config

`endif
