//-----------------------------------------------------------------------------
// pcie_dll_globals_pkg.sv
// Shared types for the (scaffolded) PCIe Data Link Layer VIP.
//
// Scope note: this models DLL *behavior* that matters for verifying the
// TLP layer above it -- sequence numbers, ACK/NAK, the replay buffer, and
// credit-based flow control accounting. It does NOT implement bit-accurate
// DLLP symbol encoding, LCRC, or physical-layer framing -- those are PHY-
// adjacent concerns out of scope until a PHY VIP exists. ACK/NAK are
// modeled as an internal, immediate side-channel inside pcie_dll_driver_bfm
// rather than as DLLP packets driven on the wire.
//-----------------------------------------------------------------------------
`ifndef PCIE_DLL_GLOBALS_PKG_SV
`define PCIE_DLL_GLOBALS_PKG_SV

package pcie_dll_globals_pkg;

  import uvm_pkg::*;
`include "uvm_macros.svh"

  // Flow-control classification a DLL must derive from the TLP header's
  // Fmt/Type fields (per PCIe Base Spec, the DLL is allowed to look at
  // this much of the header for FC purposes -- it does not need to
  // understand the rest of the TLP semantics).
  typedef enum {
    FC_POSTED,
    FC_NON_POSTED,
    FC_CPL
  } pcie_dll_fc_type_e;

  typedef enum {
    DLL_ACK,
    DLL_NAK
  } pcie_dll_ack_status_e;

  // One credit unit = 4 DWORDs (16 bytes) of data payload, plus 1 header
  // credit per TLP, matching the PCIe Base Spec credit granularity.
  parameter int PCIE_DLL_CREDIT_UNIT_BYTES = 16;

  // Replay buffer entry: the raw beats of one captured TLP (opaque to the
  // DLL beyond the FC classification above), tagged with its sequence
  // number for retransmission on NAK/timeout.
  typedef struct {
    int unsigned seq_num;
    bit [63:0]   beat_data[$];
    bit [7:0]    beat_keep[$];
    bit          beat_err[$];
    time         sent_time;
    int unsigned replay_count;
  } pcie_dll_replay_entry_t;

  // Per-direction credit ledger.
  typedef struct {
    int unsigned p_header_avail;
    int unsigned p_data_avail;    // in PCIE_DLL_CREDIT_UNIT_BYTES units
    int unsigned np_header_avail;
    int unsigned cpl_header_avail;
    int unsigned cpl_data_avail;  // in PCIE_DLL_CREDIT_UNIT_BYTES units
  } pcie_dll_credits_t;

  typedef enum {
    DLL_DIR_A_TO_B,
    DLL_DIR_B_TO_A
  } pcie_dll_direction_e;

  typedef enum {
    DLL_EVT_FORWARD, // a TLP was captured, credit-gated, and forwarded
    DLL_EVT_REPLAY,  // a TLP was retransmitted after a replay timeout
    DLL_EVT_LINK_DOWN // MAX_REPLAY_COUNT exceeded (modeled escalation)
  } pcie_dll_event_kind_e;

  //=====================================================================
  // pcie_dll_event : published on pcie_dll_monitor_proxy's analysis port
  // for every forward/replay/link-down occurrence, so coverage and any
  // external checker can observe DLL behavior without parsing raw beats.
  //=====================================================================
  class pcie_dll_event extends uvm_object;
    `uvm_object_utils(pcie_dll_event)

    pcie_dll_direction_e   direction;
    pcie_dll_event_kind_e  kind;
    int unsigned           seq_num;
    pcie_dll_fc_type_e     fc_type;
    int unsigned           header_credits;
    int unsigned           data_credits;
    int unsigned           replay_count;
    pcie_dll_ack_status_e  ack_status;
    time                   event_time;

    function new(string name = "pcie_dll_event");
      super.new(name);
    endfunction

    function string convert2string();
      return $sformatf("dir=%s kind=%s seq=%0d fc=%s hdr_cr=%0d data_cr=%0d replay_cnt=%0d ack=%s",
                        direction.name(), kind.name(), seq_num, fc_type.name(),
                        header_credits, data_credits, replay_count, ack_status.name());
    endfunction
  endclass : pcie_dll_event

endpackage : pcie_dll_globals_pkg

`endif
