// Compile order for the full RC-VIP <-> DLL-agent <-> EP-VIP stack
// (examples/vip_to_dll/). Globals -> interface -> RC/EP BFMs+assertions
// -> DLL BFMs -> DLL example hdl_top -> RC/EP hvl pkgs -> DLL hvl pkg ->
// env pkg (scoreboard reuse) -> example test pkg -> example hvl_top.
-timescale 1ns/1ps
+incdir+../../pcie_tlp_vip/src/globals
+incdir+../../pcie_tlp_vip/src/hdl_top/pcie_tlp_interface
+incdir+../../pcie_tlp_vip/src/hdl_top/rc_agent_bfm
+incdir+../../pcie_tlp_vip/src/hdl_top/ep_agent_bfm
+incdir+../../pcie_tlp_vip/src/hvl_top/rc
+incdir+../../pcie_tlp_vip/src/hvl_top/rc/sequences
+incdir+../../pcie_tlp_vip/src/hvl_top/ep
+incdir+../../pcie_tlp_vip/src/hvl_top/ep/sequences
+incdir+../../pcie_tlp_vip/src/hvl_top/env
+incdir+../src/globals
+incdir+../src/hdl_top/pcie_dll_agent_bfm
+incdir+../src/hvl_top
+incdir+../../examples/vip_to_dll

../../pcie_tlp_vip/src/globals/pcie_tlp_globals_pkg.sv
../../pcie_tlp_vip/src/hdl_top/pcie_tlp_interface/pcie_tlp_if.sv

../../pcie_tlp_vip/src/hdl_top/rc_agent_bfm/pcie_tlp_rc_driver_bfm.sv
../../pcie_tlp_vip/src/hdl_top/rc_agent_bfm/pcie_tlp_rc_monitor_bfm.sv
../../pcie_tlp_vip/src/hdl_top/rc_agent_bfm/pcie_tlp_rc_agent_bfm.sv
../../pcie_tlp_vip/src/hdl_top/pcie_tlp_rc_assertions.sv

../../pcie_tlp_vip/src/hdl_top/ep_agent_bfm/pcie_tlp_ep_driver_bfm.sv
../../pcie_tlp_vip/src/hdl_top/ep_agent_bfm/pcie_tlp_ep_monitor_bfm.sv
../../pcie_tlp_vip/src/hdl_top/ep_agent_bfm/pcie_tlp_ep_agent_bfm.sv
../../pcie_tlp_vip/src/hdl_top/pcie_tlp_ep_assertions.sv

../src/globals/pcie_dll_globals_pkg.sv
../src/hdl_top/pcie_dll_agent_bfm/pcie_dll_driver_bfm.sv
../src/hdl_top/pcie_dll_agent_bfm/pcie_dll_agent_bfm.sv

../../examples/vip_to_dll/pcie_tlp_vip_to_dll_hdl_top.sv

../../pcie_tlp_vip/src/hvl_top/rc/pcie_tlp_rc_pkg.sv
../../pcie_tlp_vip/src/hvl_top/ep/pcie_tlp_ep_pkg.sv
../src/hvl_top/pcie_dll_pkg.sv
../../pcie_tlp_vip/src/hvl_top/env/pcie_tlp_env_pkg.sv

../../examples/vip_to_dll/pcie_tlp_dll_env.sv
../../examples/vip_to_dll/pcie_tlp_dll_smoke_test.sv
../../examples/vip_to_dll/pcie_tlp_dll_test_pkg.sv
../../examples/vip_to_dll/pcie_tlp_dll_hvl_top.sv
