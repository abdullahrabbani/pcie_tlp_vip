// ============================================================================
// PCIe DLL VIP - Compile File
// ============================================================================

-sv

// Include Directories
+incdir+../src/globals/
+incdir+../src/hdl_top/pcie_dll_interface/
+incdir+../src/hdl_top/rc_agent_bfm/
+incdir+../src/hdl_top/ep_agent_bfm/
+incdir+../src/hvl_top/rc/
+incdir+../src/hvl_top/ep/
+incdir+../src/hvl_top/env/
+incdir+../src/hvl_top/test/
+incdir+../src/hvl_top/test/sequences/rc_sequences/

// Global Package
../src/globals/pcie_dll_globals_pkg.sv

// HVL Packages
../src/hvl_top/rc/pcie_dll_rc_pkg.sv
../src/hvl_top/ep/pcie_dll_ep_pkg.sv
../src/hvl_top/env/pcie_dll_env_pkg.sv

// Sequence Packages
../src/hvl_top/test/sequences/rc_sequences/pcie_dll_rc_seq_pkg.sv

// Tests
../src/hvl_top/test/pcie_dll_test_pkg.sv

// Interface
../src/hdl_top/pcie_dll_interface/pcie_dll_if.sv

// RC Agent BFMs (HDL)
../src/hdl_top/rc_agent_bfm/pcie_dll_rc_agent_bfm.sv
../src/hdl_top/rc_agent_bfm/pcie_dll_rc_driver_bfm.sv
../src/hdl_top/rc_agent_bfm/pcie_dll_rc_monitor_bfm.sv

// EP Agent BFMs (HDL)
../src/hdl_top/ep_agent_bfm/pcie_dll_ep_agent_bfm.sv
../src/hdl_top/ep_agent_bfm/pcie_dll_ep_driver_bfm.sv
../src/hdl_top/ep_agent_bfm/pcie_dll_ep_monitor_bfm.sv

// Top-Level Modules
../src/hdl_top/pcie_dll_hdl_top.sv
../src/hvl_top/pcie_dll_hvl_top.sv
