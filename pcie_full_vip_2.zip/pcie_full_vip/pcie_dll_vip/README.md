# pcie_dll_vip

Data Link Layer VIP, built in the same hdl_top/hvl_top + BFM-interface
architecture as the uploaded `pcie_tlp_vip` skeleton, with real DLL
protocol logic (not placeholder stubs).

## What's real here

- **Sequence numbers + LCRC**: every frame is tagged and checksummed on
  transmit (`pcie_dll_rc_driver_bfm.send_frame`), and checked on
  receive (`pcie_dll_ep_driver_bfm.receive_frame`).
- **ACK/NAK + replay**: a NAK'd frame is re-presented with the same
  seq#/LCRC until it's ACK'd or `DLL_REPLAY_TIMEOUT_CYCLES` is
  exceeded, at which point the driver logs a real `uvm_error` instead
  of hanging forever.
- **Posted/Non-posted awareness**: `is_posted()` in the globals
  package, consulted by the EP driver proxy's logging (a full
  posted-vs-non-posted completion split lives in the TLP layer, not
  here - the DLL layer's job is reliable delivery, not knowing what a
  Memory Write means).
- **Single RC sequencer**, not the split read/write-sequencer pattern
  from the TLP skeleton that turned out to leave `write_sequencer`
  unconnected - see the port notes below.

## Architecture notes worth knowing

- **EP side has no sequencer** (`pcie_dll_ep_driver_proxy` is a plain
  `uvm_component`, not a `uvm_driver`). Real DLL reception is
  autonomous - it reacts to whatever the RC side sends, it doesn't
  wait for test stimulus the way a TLP requester's driver does.
- **EP reuses `pcie_dll_rc_tx`** as its observed-frame shape rather
  than defining a separate `pcie_dll_ep_tx` - the frame fields are
  identical on both ends of the wire, so a second nearly-identical
  class would just be duplication.
- **hdl_top and hvl_top each declare their own `pcie_dll_if` instance**,
  matching the uploaded TLP skeleton's pattern - this is the standard
  dual-top HDL/HVL methodology: both are compiled as separate
  simulation tops in the same run, and `uvm_config_db`'s global
  resource pool is what actually connects them (the BFM handles set in
  `hdl_top`'s agent BFMs become visible to `hvl_top`'s UVM component
  hierarchy because they share one simulation, not because the two
  interface instances are the same object).

## What's honestly NOT modeled

- LCRC is an illustrative XOR/fold digest, not the real 32-bit CRC
  polynomial from the spec.
- Flow-control credits (still assumes infinite downstream buffering).
- Single frame outstanding per direction - no pipelining multiple
  un-ACKed frames.
- ACK/NAK is a signal-level handshake, not its own framed DLLP packet
  subject to the same wire transport as data.
