// DLL HVL Top module
`ifndef PCIE_DLL_HVL_TOP_SVH
`define PCIE_DLL_HVL_TOP_SVH

module pcie_dll_hvl_top;

    import uvm_pkg::*;
    `include "uvm_macros.svh"
    import pcie_dll_globals_pkg::*;
    import pcie_dll_test_pkg::*;

    logic clk;
    logic rst_n;
    pcie_dll_if if0 (.clk(clk), .rst_n(rst_n));

    initial begin
        clk = 1'b0;
        forever #5 clk = ~clk;
    end

    initial begin
        rst_n = 1'b0;
        #20;
        rst_n = 1'b1;
        `uvm_info("HVL_TOP", "Reset deasserted", UVM_LOW)
    end

    initial begin
        uvm_config_db#(virtual pcie_dll_if)::set(null, "*", "pcie_dll_if", if0);
    end

    initial begin : START_TEST
        run_test("pcie_dll_base_test");
    end

endmodule : pcie_dll_hvl_top

`endif
