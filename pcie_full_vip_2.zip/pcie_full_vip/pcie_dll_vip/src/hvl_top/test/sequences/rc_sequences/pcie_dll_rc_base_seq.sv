// RC DLL Base Sequence
`ifndef PCIE_DLL_RC_BASE_SEQ_SVH
`define PCIE_DLL_RC_BASE_SEQ_SVH

import uvm_pkg::*; `include "uvm_macros.svh"
import pcie_dll_globals_pkg::*;
import pcie_dll_rc_pkg::*;

class pcie_dll_rc_base_seq extends uvm_sequence #(pcie_dll_rc_tx);
    `uvm_object_utils(pcie_dll_rc_base_seq)

    int num_frames = 5;
    int address_min = 32'h0000_0000;
    int address_max = 32'h0000_0FFF;

    function new(string name = "pcie_dll_rc_base_seq");
        super.new(name);
    endfunction

    task body();
        `uvm_info(get_type_name(), $sformatf("Starting DLL RC sequence: %0d frames", num_frames), UVM_LOW)
        repeat (num_frames) begin
            pcie_dll_rc_tx tx = pcie_dll_rc_tx::type_id::create("tx");
            start_item(tx);
            if (!tx.randomize() with {
                  fmt inside {TLP_FMT_MEM_READ, TLP_FMT_MEM_WRITE};
                  typ inside {TLP_TYPE_MEM_RD, TLP_TYPE_MEM_WR};
                  address inside {[address_min:address_max]};
                  transaction_id >= 1;
                }) `uvm_fatal(get_type_name(), "Randomization failed")
            finish_item(tx);
            `uvm_info(get_type_name(), $sformatf("Issued frame ID %0d, %s addr=0x%08x",
                       tx.transaction_id, tx.fmt.name(), tx.address), UVM_MEDIUM)
            get_response(tx);
        end
        `uvm_info(get_type_name(), "All frames issued", UVM_LOW)
    endtask

endclass

`endif
