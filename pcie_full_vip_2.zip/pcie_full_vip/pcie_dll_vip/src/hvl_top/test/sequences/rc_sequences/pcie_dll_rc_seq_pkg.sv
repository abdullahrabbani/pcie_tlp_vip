// RC DLL Sequence Package
`ifndef PCIE_DLL_RC_SEQ_PKG_SVH
`define PCIE_DLL_RC_SEQ_PKG_SVH

package pcie_dll_rc_seq_pkg;
    `include "uvm_macros.svh"
    import uvm_pkg::*;
    import pcie_dll_globals_pkg::*;
    import pcie_dll_rc_pkg::*;

    `include "pcie_dll_rc_base_seq.sv"
endpackage

`endif
