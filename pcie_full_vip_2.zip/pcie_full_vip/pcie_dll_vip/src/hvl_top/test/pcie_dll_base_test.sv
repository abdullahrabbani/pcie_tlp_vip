// DLL Base Test
`ifndef PCIE_DLL_BASE_TEST_SVH
`define PCIE_DLL_BASE_TEST_SVH

class pcie_dll_base_test extends uvm_test;
    `uvm_component_utils(pcie_dll_base_test)
    pcie_dll_env        env;
    pcie_dll_env_config env_cfg;

    function new(string name = "pcie_dll_base_test", uvm_component parent = null);
        super.new(name, parent);
    endfunction

    function void build_phase(uvm_phase phase);
        super.build_phase(phase);
        env_cfg = pcie_dll_env_config::type_id::create("env_cfg");
        env_cfg.rc_cfg = pcie_dll_rc_agent_config::type_id::create("rc_cfg");
        env_cfg.ep_cfg = pcie_dll_ep_agent_config::type_id::create("ep_cfg");
        env_cfg.rc_cfg.is_active = UVM_ACTIVE;
        env_cfg.ep_cfg.is_active = UVM_ACTIVE;
        uvm_config_db#(pcie_dll_env_config)::set(this, "env", "cfg", env_cfg);
        env = pcie_dll_env::type_id::create("env", this);
    endfunction

    task run_phase(uvm_phase phase);
        pcie_dll_rc_base_seq seq = pcie_dll_rc_base_seq::type_id::create("seq");
        phase.raise_objection(this);
        seq.start(env.rc_agent.sequencer);
        #200;
        phase.drop_objection(this);
    endtask

endclass

`endif
