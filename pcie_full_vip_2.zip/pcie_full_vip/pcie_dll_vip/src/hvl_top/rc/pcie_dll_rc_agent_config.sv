// RC DLL Agent Configuration
`ifndef PCIE_DLL_RC_AGENT_CONFIG_SVH
`define PCIE_DLL_RC_AGENT_CONFIG_SVH

import uvm_pkg::*; `include "uvm_macros.svh"

class pcie_dll_rc_agent_config extends uvm_object;
    `uvm_object_utils(pcie_dll_rc_agent_config)
    uvm_active_passive_enum is_active = UVM_ACTIVE;
    bit has_coverage = 1'b0;

    function new(string name = "pcie_dll_rc_agent_config");
        super.new(name);
    endfunction
endclass

`endif
