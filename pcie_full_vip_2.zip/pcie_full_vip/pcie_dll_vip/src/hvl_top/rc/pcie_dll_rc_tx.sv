// RC DLL Transaction
`ifndef PCIE_DLL_RC_TX_SVH
`define PCIE_DLL_RC_TX_SVH

import uvm_pkg::*; `include "uvm_macros.svh"; import pcie_dll_globals_pkg::*;

class pcie_dll_rc_tx extends uvm_sequence_item;
    `uvm_object_utils(pcie_dll_rc_tx)

    rand tlp_fmt_e    fmt;
    rand tlp_type_e   typ;
    rand logic [31:0] address;
    rand logic [9:0]  length;
    rand logic [31:0] tag;
    rand logic [31:0] wdata;
    rand int          transaction_id;

    bit acked;   // set by driver proxy after send_frame() returns

    constraint fmt_type_c {
        (fmt == TLP_FMT_MEM_READ)  -> typ inside {TLP_TYPE_MEM_RD};
        (fmt == TLP_FMT_MEM_WRITE) -> typ inside {TLP_TYPE_MEM_WR};
        (fmt == TLP_FMT_CFG_READ)  -> typ inside {TLP_TYPE_CFG_RD};
        (fmt == TLP_FMT_CFG_WRITE) -> typ inside {TLP_TYPE_CFG_WR};
    }
    constraint trans_id_c { transaction_id > 0; }

    function new(string name = "pcie_dll_rc_tx");
        super.new(name);
        fmt = TLP_FMT_MEM_READ;
        typ = TLP_TYPE_MEM_RD;
        address = 0; length = 1; tag = 0; wdata = 0; transaction_id = 1;
    endfunction

    function void do_copy(uvm_object rhs);
        pcie_dll_rc_tx c;
        if (!$cast(c, rhs)) `uvm_fatal("do_copy", "cast failed")
        super.do_copy(rhs);
        fmt = c.fmt; typ = c.typ; address = c.address; length = c.length;
        tag = c.tag; wdata = c.wdata; transaction_id = c.transaction_id; acked = c.acked;
    endfunction

    function void do_print(uvm_printer printer);
        super.do_print(printer);
        printer.print_string("fmt", fmt.name());
        printer.print_string("typ", typ.name());
        printer.print_field("address", address, $bits(address), UVM_HEX);
        printer.print_field("tag", tag, $bits(tag), UVM_HEX);
        printer.print_field("transaction_id", transaction_id, $bits(transaction_id), UVM_DEC);
        printer.print_field("acked", acked, 1, UVM_BIN);
    endfunction

endclass

`endif
