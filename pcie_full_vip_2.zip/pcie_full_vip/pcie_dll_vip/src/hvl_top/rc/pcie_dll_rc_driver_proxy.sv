// RC DLL Driver Proxy
`ifndef PCIE_DLL_RC_DRIVER_PROXY_SVH
`define PCIE_DLL_RC_DRIVER_PROXY_SVH

class pcie_dll_rc_driver_proxy extends uvm_driver #(pcie_dll_rc_tx);
    `uvm_component_utils(pcie_dll_rc_driver_proxy)
    virtual pcie_dll_rc_driver_bfm bfm;
    pcie_dll_rc_agent_config cfg;
    uvm_analysis_port #(pcie_dll_rc_tx) resp_port;

    function new(string name = "pcie_dll_rc_driver_proxy", uvm_component parent = null);
        super.new(name, parent);
        resp_port = new("resp_port", this);
    endfunction

    function void build_phase(uvm_phase phase);
        super.build_phase(phase);
        if (!uvm_config_db#(virtual pcie_dll_rc_driver_bfm)::get(this, "", "pcie_dll_rc_driver_bfm", bfm))
            `uvm_fatal(get_type_name(), "Failed to get BFM handle")
    endfunction

    task run_phase(uvm_phase phase);
        pcie_dll_rc_tx req, rsp;
        bit acked;
        super.run_phase(phase);
        bfm.wait_for_reset();
        forever begin
            seq_item_port.get_next_item(req);
            `uvm_info(get_type_name(), $sformatf("Sending frame ID %0d, %s %s",
                       req.transaction_id, req.fmt.name(), req.typ.name()), UVM_MEDIUM)
            bfm.send_frame(req.fmt, req.typ, req.address, req.length, req.tag, req.wdata, acked);

            rsp = pcie_dll_rc_tx::type_id::create("rsp");
            rsp.set_id_info(req);
            rsp.set_transaction_id(req.transaction_id);
            rsp.acked = acked;
            if (!acked)
                `uvm_error(get_type_name(), $sformatf("Frame ID %0d never got ACK'd (replay timeout)", req.transaction_id))
            seq_item_port.item_done(rsp);
        end
    endtask

    // Exposed for the TLP layer above (in a Full Stack integration)
    // to call when a non-posted request needs to wait for a real
    // completion arriving via DLL, instead of the DLL layer trying to
    // guess TLP-level posted/non-posted semantics itself.
    task receive_completion(output tlp_type_e typ_o, output logic [31:0] tag_o,
                             output logic [31:0] data_o, output bit good);
        bfm.receive_completion(typ_o, tag_o, data_o, good);
    endtask

endclass

`endif
