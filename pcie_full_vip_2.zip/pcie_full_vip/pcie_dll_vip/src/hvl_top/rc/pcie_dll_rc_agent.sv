// RC DLL Agent
`ifndef PCIE_DLL_RC_AGENT_SVH
`define PCIE_DLL_RC_AGENT_SVH

class pcie_dll_rc_agent extends uvm_agent;
    `uvm_component_utils(pcie_dll_rc_agent)

    pcie_dll_rc_agent_config cfg;
    pcie_dll_rc_driver_proxy  driver;
    pcie_dll_rc_monitor_proxy monitor;
    pcie_dll_rc_sequencer     sequencer;

    function new(string name = "pcie_dll_rc_agent", uvm_component parent = null);
        super.new(name, parent);
    endfunction

    function void build_phase(uvm_phase phase);
        super.build_phase(phase);
        if (!uvm_config_db#(pcie_dll_rc_agent_config)::get(this, "", "cfg", cfg))
            `uvm_fatal(get_type_name(), "No configuration object found")
        monitor = pcie_dll_rc_monitor_proxy::type_id::create("monitor", this);
        if (cfg.is_active == UVM_ACTIVE) begin
            driver    = pcie_dll_rc_driver_proxy::type_id::create("driver", this);
            sequencer = pcie_dll_rc_sequencer::type_id::create("sequencer", this);
        end
    endfunction

    function void connect_phase(uvm_phase phase);
        super.connect_phase(phase);
        monitor.cfg = cfg;
        if (cfg.is_active == UVM_ACTIVE) begin
            driver.cfg = cfg;
            sequencer.cfg = cfg;
            driver.seq_item_port.connect(sequencer.seq_item_export);
        end
    endfunction

endclass

`endif
