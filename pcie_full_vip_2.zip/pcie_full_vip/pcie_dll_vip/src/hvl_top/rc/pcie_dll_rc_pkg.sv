// RC DLL Agent Package
`ifndef PCIE_DLL_RC_PKG_SVH
`define PCIE_DLL_RC_PKG_SVH

package pcie_dll_rc_pkg;
    `include "uvm_macros.svh"
    import uvm_pkg::*;
    import pcie_dll_globals_pkg::*;

    `include "pcie_dll_rc_agent_config.sv"
    `include "pcie_dll_rc_tx.sv"
    `include "pcie_dll_rc_seq_item_converter.sv"
    `include "pcie_dll_rc_sequencer.sv"
    `include "pcie_dll_rc_driver_proxy.sv"
    `include "pcie_dll_rc_monitor_proxy.sv"
    `include "pcie_dll_rc_agent.sv"
endpackage

`endif
