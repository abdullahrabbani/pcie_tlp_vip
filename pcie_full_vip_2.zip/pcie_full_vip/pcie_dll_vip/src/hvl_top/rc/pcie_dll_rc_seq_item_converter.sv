// RC DLL Sequence Item Converter
`ifndef PCIE_DLL_RC_SEQ_ITEM_CONVERTER_SVH
`define PCIE_DLL_RC_SEQ_ITEM_CONVERTER_SVH

class pcie_dll_rc_seq_item_converter extends uvm_object;
    `uvm_object_utils(pcie_dll_rc_seq_item_converter)

    function new(string name = "pcie_dll_rc_seq_item_converter");
        super.new(name);
    endfunction

    static function void from_tx_class(input pcie_dll_rc_tx tx, output dll_frame_t frame);
        frame.fmt            = tx.fmt;
        frame.typ            = tx.typ;
        frame.address         = tx.address;
        frame.length            = tx.length;
        frame.tag                 = tx.tag;
        frame.payload               = {992'h0, tx.wdata};
        frame.payload_size             = 4;
        frame.transaction_id             = tx.transaction_id;
        frame.timestamp                    = $time;
    endfunction

endclass

`endif
