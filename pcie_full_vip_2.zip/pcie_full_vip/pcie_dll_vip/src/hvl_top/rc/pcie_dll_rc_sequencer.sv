// RC DLL Sequencer
`ifndef PCIE_DLL_RC_SEQUENCER_SVH
`define PCIE_DLL_RC_SEQUENCER_SVH

class pcie_dll_rc_sequencer extends uvm_sequencer #(pcie_dll_rc_tx);
    `uvm_component_utils(pcie_dll_rc_sequencer)
    pcie_dll_rc_agent_config cfg;

    function new(string name, uvm_component parent);
        super.new(name, parent);
    endfunction
endclass

`endif
