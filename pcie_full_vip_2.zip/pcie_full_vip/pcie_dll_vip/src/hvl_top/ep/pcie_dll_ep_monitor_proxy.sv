// EP DLL Monitor Proxy
`ifndef PCIE_DLL_EP_MONITOR_PROXY_SVH
`define PCIE_DLL_EP_MONITOR_PROXY_SVH

class pcie_dll_ep_monitor_proxy extends uvm_monitor;
    `uvm_component_utils(pcie_dll_ep_monitor_proxy)
    virtual pcie_dll_ep_monitor_bfm bfm;
    pcie_dll_ep_agent_config cfg;
    uvm_analysis_port #(pcie_dll_rc_tx) frame_ap;

    function new(string name = "pcie_dll_ep_monitor_proxy", uvm_component parent = null);
        super.new(name, parent);
        frame_ap = new("frame_ap", this);
    endfunction

    function void build_phase(uvm_phase phase);
        super.build_phase(phase);
        if (!uvm_config_db#(virtual pcie_dll_ep_monitor_bfm)::get(this, "", "pcie_dll_ep_monitor_bfm", bfm))
            `uvm_fatal(get_type_name(), "Failed to get BFM handle")
    endfunction

    task run_phase(uvm_phase phase);
        dll_frame_t frame;
        pcie_dll_rc_tx item;
        forever begin
            bfm.sample_frame(frame);
            item = pcie_dll_rc_tx::type_id::create("item");
            item.fmt = frame.fmt; item.typ = frame.typ; item.address = frame.address;
            item.length = frame.length; item.tag = frame.tag; item.wdata = frame.payload[31:0];
            item.transaction_id = frame.transaction_id;
            frame_ap.write(item);
        end
    endtask

endclass

`endif
