// EP DLL Driver Proxy
`ifndef PCIE_DLL_EP_DRIVER_PROXY_SVH
`define PCIE_DLL_EP_DRIVER_PROXY_SVH

// Deliberately NOT a uvm_driver#(T) - a real DLL receiver is
// autonomous, not sequence-item-driven the way TLP stimulus is: it
// doesn't wait for a test to hand it a "receive this" item, it
// reactively frames-checks whatever the RC side sends. Pulling
// dllp_pkg-style DIRECT-mode sequencer stimulus onto the EP side
// would be modeling something that doesn't exist in real hardware.
class pcie_dll_ep_driver_proxy extends uvm_component;
    `uvm_component_utils(pcie_dll_ep_driver_proxy)
    virtual pcie_dll_ep_driver_bfm bfm;
    pcie_dll_ep_agent_config cfg;
    uvm_analysis_port #(pcie_dll_rc_tx) frame_ap;   // reuses rc_tx shape - same field set, no need for a separate ep_tx type

    int unsigned frames_received  = 0;
    int unsigned frames_nakd      = 0;

    function new(string name = "pcie_dll_ep_driver_proxy", uvm_component parent = null);
        super.new(name, parent);
        frame_ap = new("frame_ap", this);
    endfunction

    function void build_phase(uvm_phase phase);
        super.build_phase(phase);
        if (!uvm_config_db#(virtual pcie_dll_ep_driver_bfm)::get(this, "", "pcie_dll_ep_driver_bfm", bfm))
            `uvm_fatal(get_type_name(), "Failed to get BFM handle")
    endfunction

    task run_phase(uvm_phase phase);
        dll_frame_t frame;
        bit good;
        bfm.wait_for_reset();
        forever begin
            bfm.receive_frame(frame, good);
            if (good) begin
                pcie_dll_rc_tx item = pcie_dll_rc_tx::type_id::create("item");
                item.fmt = frame.fmt; item.typ = frame.typ; item.address = frame.address;
                item.length = frame.length; item.tag = frame.tag; item.wdata = frame.payload[31:0];
                item.transaction_id = frame.transaction_id;
                frames_received++;
                `uvm_info(get_type_name(), $sformatf("Accepted frame seq=%0d, %s %s addr=0x%08x",
                           frame.seq, frame.typ.name(), is_posted(frame.fmt) ? "(posted)" : "(non-posted)", frame.address), UVM_MEDIUM)
                frame_ap.write(item);
            end else begin
                frames_nakd++;
                `uvm_info(get_type_name(), "Frame failed LCRC check - NAK sent", UVM_MEDIUM)
            end
        end
    endtask

    function void report_phase(uvm_phase phase);
        `uvm_info(get_type_name(), $sformatf(
            "Summary: frames_received=%0d frames_nakd=%0d", frames_received, frames_nakd), UVM_NONE)
    endfunction

    // Exposed for the TLP layer above to call after it decides (based
    // on TLP-level posted/non-posted semantics the DLL layer doesn't
    // know about) that a completion needs to go back to the RC.
    task send_completion(input tlp_type_e typ_i, input logic [31:0] tag_i,
                          input logic [31:0] data_i, output bit acked);
        bfm.send_completion(typ_i, tag_i, data_i, acked);
    endtask

endclass

`endif
