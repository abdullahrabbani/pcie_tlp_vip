// EP DLL Agent Package
`ifndef PCIE_DLL_EP_PKG_SVH
`define PCIE_DLL_EP_PKG_SVH

package pcie_dll_ep_pkg;
    `include "uvm_macros.svh"
    import uvm_pkg::*;
    import pcie_dll_globals_pkg::*;
    import pcie_dll_rc_pkg::*;   // reuses pcie_dll_rc_tx as the common frame-shaped item

    `include "pcie_dll_ep_agent_config.sv"
    `include "pcie_dll_ep_driver_proxy.sv"
    `include "pcie_dll_ep_monitor_proxy.sv"
    `include "pcie_dll_ep_agent.sv"
endpackage

`endif
