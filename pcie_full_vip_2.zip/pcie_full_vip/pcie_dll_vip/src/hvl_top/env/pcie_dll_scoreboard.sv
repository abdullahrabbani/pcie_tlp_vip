// DLL Scoreboard
`ifndef PCIE_DLL_SCOREBOARD_SVH
`define PCIE_DLL_SCOREBOARD_SVH

`uvm_analysis_imp_decl(_rc_sent)
`uvm_analysis_imp_decl(_ep_recv)

class pcie_dll_scoreboard extends uvm_scoreboard;
    `uvm_component_utils(pcie_dll_scoreboard)

    uvm_analysis_imp_rc_sent #(pcie_dll_rc_tx, pcie_dll_scoreboard) rc_sent_imp;
    uvm_analysis_imp_ep_recv #(pcie_dll_rc_tx, pcie_dll_scoreboard) ep_recv_imp;

    pcie_dll_rc_tx rc_sent_q[$];
    int unsigned matched_count = 0;
    int unsigned mismatch_count = 0;

    function new(string name = "pcie_dll_scoreboard", uvm_component parent = null);
        super.new(name, parent);
        rc_sent_imp = new("rc_sent_imp", this);
        ep_recv_imp = new("ep_recv_imp", this);
    endfunction

    function void write_rc_sent(pcie_dll_rc_tx t);
        rc_sent_q.push_back(t);
    endfunction

    // Matches by transaction_id - integrity check that what the EP
    // actually received (post seq#/LCRC/ACK-NAK/replay) matches what
    // the RC originally sent, catching corruption in transit that a
    // "did it get ACK'd" check alone would miss.
    function void write_ep_recv(pcie_dll_rc_tx act);
        foreach (rc_sent_q[i]) begin
            if (rc_sent_q[i].transaction_id == act.transaction_id) begin
                pcie_dll_rc_tx exp = rc_sent_q[i];
                rc_sent_q.delete(i);
                if (exp.fmt == act.fmt && exp.typ == act.typ && exp.address == act.address &&
                    exp.tag == act.tag && exp.wdata == act.wdata) begin
                    matched_count++;
                    `uvm_info(get_type_name(), $sformatf("MATCH ID %0d", act.transaction_id), UVM_HIGH)
                end else begin
                    mismatch_count++;
                    `uvm_error(get_type_name(), $sformatf("MISMATCH ID %0d: sent vs received differ", act.transaction_id))
                end
                return;
            end
        end
        `uvm_warning(get_type_name(), $sformatf("EP received frame ID %0d with no matching RC send record", act.transaction_id))
    endfunction

    function void report_phase(uvm_phase phase);
        `uvm_info(get_type_name(), $sformatf(
            "Summary: matched=%0d mismatches=%0d unmatched_sent=%0d",
            matched_count, mismatch_count, rc_sent_q.size()), UVM_NONE)
        if (mismatch_count > 0)
            `uvm_error(get_type_name(), $sformatf("%0d integrity mismatches detected", mismatch_count))
    endfunction

endclass

`endif
