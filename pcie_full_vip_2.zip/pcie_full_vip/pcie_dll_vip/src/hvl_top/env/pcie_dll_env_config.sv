// DLL Env Configuration
`ifndef PCIE_DLL_ENV_CONFIG_SVH
`define PCIE_DLL_ENV_CONFIG_SVH

class pcie_dll_env_config extends uvm_object;
    `uvm_object_utils(pcie_dll_env_config)
    pcie_dll_rc_agent_config rc_cfg;
    pcie_dll_ep_agent_config ep_cfg;
    bit has_scoreboard = 1'b1;

    function new(string name = "pcie_dll_env_config");
        super.new(name);
    endfunction
endclass

`endif
