// DLL Env Package
`ifndef PCIE_DLL_ENV_PKG_SVH
`define PCIE_DLL_ENV_PKG_SVH

package pcie_dll_env_pkg;
    `include "uvm_macros.svh"
    import uvm_pkg::*;
    import pcie_dll_globals_pkg::*;
    import pcie_dll_rc_pkg::*;
    import pcie_dll_ep_pkg::*;

    `include "pcie_dll_env_config.sv"
    `include "pcie_dll_scoreboard.sv"
    `include "pcie_dll_env.sv"
endpackage

`endif
