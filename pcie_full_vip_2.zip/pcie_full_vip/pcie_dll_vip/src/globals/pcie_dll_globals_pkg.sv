// PCIe DLL VIP - Global Package
`ifndef PCIE_DLL_GLOBALS_PKG_SVH
`define PCIE_DLL_GLOBALS_PKG_SVH

package pcie_dll_globals_pkg;

    // Reuses the same TLP Fmt/Type split as pcie_tlp_globals_pkg so a
    // DLL frame can carry a real TLP's type without re-deriving it -
    // in the Full Stack config this DLL VIP sits directly below the
    // TLP VIP and needs to speak the same vocabulary.
    typedef enum logic [2:0] {
        TLP_FMT_MEM_READ  = 3'b000,
        TLP_FMT_MEM_WRITE = 3'b001,
        TLP_FMT_IO_READ   = 3'b010,
        TLP_FMT_IO_WRITE  = 3'b011,
        TLP_FMT_CFG_READ  = 3'b100,
        TLP_FMT_CFG_WRITE = 3'b101,
        TLP_FMT_MSG       = 3'b110,
        TLP_FMT_MSG_DATA  = 3'b111
    } tlp_fmt_e;

    typedef enum logic [5:0] {
        TLP_TYPE_MEM_RD   = 6'b000000,
        TLP_TYPE_MEM_WR   = 6'b000001,
        TLP_TYPE_IO_RD    = 6'b000010,
        TLP_TYPE_IO_WR    = 6'b000011,
        TLP_TYPE_CFG_RD   = 6'b000100,
        TLP_TYPE_CFG_WR   = 6'b000101,
        TLP_TYPE_MSG      = 6'b001000,
        TLP_TYPE_MSG_DATA = 6'b001001,
        TLP_TYPE_CMPL     = 6'b001010
    } tlp_type_e;

    // DLLP kind - covers both data frames and the link-management
    // ACK/NAK DLLPs, since "DLLP generation and decoding" per spec
    // includes both, not just framed data.
    typedef enum logic [1:0] {
        DLLP_DATA,
        DLLP_ACK,
        DLLP_NAK
    } dllp_kind_e;

    parameter int DLL_SEQ_WIDTH   = 12;   // spec width for the sequence number
    parameter int DLL_MAX_PAYLOAD = 256;
    parameter int DLL_REPLAY_TIMEOUT_CYCLES = 100;

    // One DLL frame: a TLP wrapped with the sequence number and LCRC
    // the Data Link Layer adds on transmit and checks on receive.
    typedef struct {
        logic [DLL_SEQ_WIDTH-1:0] seq;
        logic [31:0]              lcrc;
        tlp_fmt_e                 fmt;
        tlp_type_e                typ;
        logic [31:0]              address;
        logic [9:0]               length;
        logic [31:0]              tag;
        logic [1023:0]            payload;
        int                       payload_size;
        int                       transaction_id;
        time                      timestamp;
    } dll_frame_t;

    // Posted vs Non-Posted - same rule as the TLP layer, duplicated
    // here (rather than importing pcie_tlp_globals_pkg) so this VIP
    // has no compile-time dependency on the TLP VIP's package, only
    // on the wire-level frame shape it carries.
    function automatic bit is_posted(tlp_fmt_e fmt);
        case (fmt)
            TLP_FMT_MEM_WRITE, TLP_FMT_MSG, TLP_FMT_MSG_DATA: return 1'b1;
            default: return 1'b0;
        endcase
    endfunction

    // Illustrative XOR/fold digest - NOT the real 32-bit CRC
    // polynomial from the spec. Covers the sequence number, which
    // end-to-end ECRC (a TLP-layer concept, not modeled in this DLL
    // VIP) never sees - that's what makes LCRC a distinct, per-hop check.
    function automatic logic [31:0] compute_lcrc(
        logic [DLL_SEQ_WIDTH-1:0] seq, tlp_type_e typ, logic [31:0] addr,
        logic [31:0] tag, logic [31:0] wdata
    );
        return ({20'h0, seq} ^ {26'h0, typ} ^ addr ^ tag ^ wdata ^ 32'hA5A5_A5A5);
    endfunction

endpackage

`endif
