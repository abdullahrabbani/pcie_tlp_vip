// EP DLL Agent BFM
`ifndef PCIE_DLL_EP_AGENT_BFM_SVH
`define PCIE_DLL_EP_AGENT_BFM_SVH

import uvm_pkg::*;
`include "uvm_macros.svh"
import pcie_dll_globals_pkg::*;

module pcie_dll_ep_agent_bfm #(parameter int EP_ID = 0)(
    pcie_dll_if intf
);

    pcie_dll_ep_driver_bfm ep_drv_bfm (
        .clk(intf.clk), .rst_n(intf.rst_n),
        .valid(intf.valid), .ready(intf.ready),
        .seq(intf.seq), .lcrc(intf.lcrc), .fmt(intf.fmt), .typ(intf.typ),
        .address(intf.address), .length(intf.length), .tag(intf.tag), .wdata(intf.wdata),
        .ack_valid(intf.ack_valid), .ack_ok(intf.ack_ok),
        .cpl_valid(intf.cpl_valid), .cpl_ready(intf.cpl_ready),
        .cpl_seq(intf.cpl_seq), .cpl_lcrc(intf.cpl_lcrc), .cpl_typ(intf.cpl_typ),
        .cpl_tag(intf.cpl_tag), .cpl_data(intf.cpl_data),
        .cpl_ack_valid(intf.cpl_ack_valid), .cpl_ack_ok(intf.cpl_ack_ok),
        .link_up(intf.link_up)
    );

    pcie_dll_ep_monitor_bfm ep_mon_bfm (
        .clk(intf.clk), .rst_n(intf.rst_n),
        .valid(intf.valid), .ready(intf.ready),
        .seq(intf.seq), .lcrc(intf.lcrc), .fmt(intf.fmt), .typ(intf.typ),
        .address(intf.address), .length(intf.length), .tag(intf.tag), .wdata(intf.wdata),
        .ack_valid(intf.ack_valid), .ack_ok(intf.ack_ok)
    );

    initial begin
        uvm_config_db#(virtual pcie_dll_ep_driver_bfm)::set(null, "*", "pcie_dll_ep_driver_bfm", ep_drv_bfm);
        uvm_config_db#(virtual pcie_dll_ep_monitor_bfm)::set(null, "*", "pcie_dll_ep_monitor_bfm", ep_mon_bfm);
        `uvm_info("PCIE_DLL_EP_AGENT_BFM", $sformatf("EP DLL Agent BFM instantiated with ID %0d", EP_ID), UVM_LOW)
    end

endmodule : pcie_dll_ep_agent_bfm

`endif
