// EP DLL Driver BFM
`ifndef PCIE_DLL_EP_DRIVER_BFM_SVH
`define PCIE_DLL_EP_DRIVER_BFM_SVH

import pcie_dll_globals_pkg::*;
import uvm_pkg::*;
`include "uvm_macros.svh"

interface pcie_dll_ep_driver_bfm (
    input  logic clk,
    input  logic rst_n,
    input  logic valid,
    output logic ready,
    input  logic [DLL_SEQ_WIDTH-1:0] seq,
    input  logic [31:0]              lcrc,
    input  tlp_fmt_e                 fmt,
    input  tlp_type_e                typ,
    input  logic [31:0]              address,
    input  logic [9:0]               length,
    input  logic [31:0]              tag,
    input  logic [31:0]              wdata,
    output logic                     ack_valid,
    output logic                     ack_ok,
    // Completion path: EP is the transmitter here.
    output logic                     cpl_valid,
    input  logic                     cpl_ready,
    output logic [DLL_SEQ_WIDTH-1:0] cpl_seq,
    output logic [31:0]              cpl_lcrc,
    output tlp_type_e                cpl_typ,
    output logic [31:0]              cpl_tag,
    output logic [31:0]              cpl_data,
    input  logic                     cpl_ack_valid,
    input  logic                     cpl_ack_ok,
    input  logic                     link_up
);

    string name = "PCIE_DLL_EP_DRIVER_BFM";
    int unsigned inject_corrupt = 0;  // test hook: force next N frames to fail LCRC
    logic [DLL_SEQ_WIDTH-1:0] cpl_seq_ctr = '0;

    initial `uvm_info(name, $sformatf("%s instantiated", name), UVM_LOW)

    clocking drv_cb @(posedge clk);
        default input #1step output #1step;
        output ready, ack_valid, ack_ok;
        input  valid, seq, lcrc, fmt, typ, address, length, tag, wdata;
        output cpl_valid, cpl_seq, cpl_lcrc, cpl_typ, cpl_tag, cpl_data;
        input  cpl_ready, cpl_ack_valid, cpl_ack_ok;
        input  link_up;
    endclocking

    task wait_for_reset();
        @(negedge rst_n);
        default_values();
        @(posedge rst_n);
        `uvm_info(name, "Reset deactivated", UVM_HIGH)
    endtask

    task default_values();
        drv_cb.ready     <= 1'b1;
        drv_cb.ack_valid <= 1'b0;
        drv_cb.cpl_valid <= 1'b0;
    endtask

    // Receives one frame, checks LCRC, drives ACK/NAK back on the
    // following cycle. Gated by link_up.
    task automatic receive_frame(output dll_frame_t frame, output bit good);
        drv_cb.ready <= 1'b1;
        do begin
            @(drv_cb);
        end while (!(drv_cb.valid && drv_cb.ready && drv_cb.link_up));

        frame.seq     = drv_cb.seq;
        frame.lcrc     = drv_cb.lcrc;
        frame.fmt       = drv_cb.fmt;
        frame.typ         = drv_cb.typ;
        frame.address       = drv_cb.address;
        frame.length          = drv_cb.length;
        frame.tag               = drv_cb.tag;
        frame.payload              = {992'h0, drv_cb.wdata};
        frame.payload_size            = 4;
        frame.timestamp                 = $time;

        good = (compute_lcrc(frame.seq, frame.typ, frame.address, frame.tag, drv_cb.wdata) == frame.lcrc)
               && (inject_corrupt == 0);
        if (!good && inject_corrupt > 0) inject_corrupt--;

        @(drv_cb);
        drv_cb.ack_valid <= 1'b1;
        drv_cb.ack_ok    <= good;
        `uvm_info(name, $sformatf("Frame seq=%0d %s LCRC check -> %s",
                   frame.seq, frame.typ.name(), good ? "ACK" : "NAK"), UVM_HIGH)
        @(drv_cb);
        drv_cb.ack_valid <= 1'b0;
    endtask

    // Sends one completion, waits for ACK/NAK, replays on NAK. Mirrors
    // pcie_dll_rc_driver_bfm.send_frame exactly, direction reversed -
    // EP is now the transmitter, RC the receiver.
    task automatic send_completion(
        input tlp_type_e typ_i, input logic [31:0] tag_i, input logic [31:0] data_i,
        output bit acked
    );
        automatic logic [31:0] lcrc_val;
        automatic int waited;
        acked = 0;

        do begin
            @(drv_cb);
        end while (!drv_cb.link_up);

        forever begin
            lcrc_val = compute_lcrc(cpl_seq_ctr, typ_i, 32'h0, tag_i, data_i);
            @(drv_cb);
            drv_cb.cpl_valid <= 1'b1;
            drv_cb.cpl_seq   <= cpl_seq_ctr;
            drv_cb.cpl_lcrc  <= lcrc_val;
            drv_cb.cpl_typ   <= typ_i;
            drv_cb.cpl_tag   <= tag_i;
            drv_cb.cpl_data  <= data_i;

            do begin
                @(drv_cb);
            end while (!(drv_cb.cpl_valid && drv_cb.cpl_ready));

            waited = 0;
            forever begin
                @(drv_cb);
                waited++;
                if (drv_cb.cpl_ack_valid) begin
                    if (drv_cb.cpl_ack_ok) begin
                        cpl_seq_ctr <= cpl_seq_ctr + 1'b1;
                        drv_cb.cpl_valid <= 1'b0;
                        acked = 1;
                        `uvm_info(name, $sformatf("Completion seq=%0d ACK'd", cpl_seq_ctr), UVM_HIGH)
                        return;
                    end else begin
                        `uvm_warning(name, $sformatf("Completion seq=%0d NAK'd - replaying", cpl_seq_ctr))
                        break;
                    end
                end else if (waited > DLL_REPLAY_TIMEOUT_CYCLES) begin
                    `uvm_error(name, $sformatf(
                        "Replay timeout: no ACK/NAK for completion seq=%0d after %0d cycles", cpl_seq_ctr, waited))
                    drv_cb.cpl_valid <= 1'b0;
                    acked = 0;
                    return;
                end
            end
        end
    endtask

endinterface : pcie_dll_ep_driver_bfm

`endif
