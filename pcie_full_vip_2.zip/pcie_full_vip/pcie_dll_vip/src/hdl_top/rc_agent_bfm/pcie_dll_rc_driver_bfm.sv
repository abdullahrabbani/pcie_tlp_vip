// RC DLL Driver BFM
`ifndef PCIE_DLL_RC_DRIVER_BFM_SVH
`define PCIE_DLL_RC_DRIVER_BFM_SVH

import pcie_dll_globals_pkg::*;
import uvm_pkg::*;
`include "uvm_macros.svh"

interface pcie_dll_rc_driver_bfm (
    input  logic clk,
    input  logic rst_n,
    output logic valid,
    input  logic ready,
    output logic [DLL_SEQ_WIDTH-1:0] seq,
    output logic [31:0]              lcrc,
    output tlp_fmt_e                 fmt,
    output tlp_type_e                typ,
    output logic [31:0]              address,
    output logic [9:0]               length,
    output logic [31:0]              tag,
    output logic [31:0]              wdata,
    input  logic                     ack_valid,
    input  logic                     ack_ok,
    // Completion path: RC is the receiver here (completions originate
    // at the EP), so RC drives cpl_ready/cpl_ack_* and reads the rest.
    input  logic                     cpl_valid,
    output logic                     cpl_ready,
    input  logic [DLL_SEQ_WIDTH-1:0] cpl_seq,
    input  logic [31:0]              cpl_lcrc,
    input  tlp_type_e                cpl_typ,
    input  logic [31:0]              cpl_tag,
    input  logic [31:0]              cpl_data,
    output logic                     cpl_ack_valid,
    output logic                     cpl_ack_ok,
    input  logic                     link_up
);

    string name = "PCIE_DLL_RC_DRIVER_BFM";
    logic [DLL_SEQ_WIDTH-1:0] seq_ctr = '0;
    int unsigned inject_corrupt = 0;  // test hook: force next N completions to fail LCRC

    initial `uvm_info(name, $sformatf("%s instantiated", name), UVM_LOW)

    clocking drv_cb @(posedge clk);
        default input #1step output #1step;
        output valid, seq, lcrc, fmt, typ, address, length, tag, wdata;
        input  ready, ack_valid, ack_ok;
        input  cpl_valid, cpl_seq, cpl_lcrc, cpl_typ, cpl_tag, cpl_data;
        output cpl_ready, cpl_ack_valid, cpl_ack_ok;
        input  link_up;
    endclocking

    task wait_for_reset();
        @(negedge rst_n);
        default_values();
        @(posedge rst_n);
        `uvm_info(name, "Reset deactivated", UVM_HIGH)
    endtask

    task default_values();
        drv_cb.valid         <= 1'b0;
        drv_cb.cpl_ready      <= 1'b1;
        drv_cb.cpl_ack_valid   <= 1'b0;
    endtask

    // Sends one frame, waits for ACK/NAK, replays on NAK, times out if
    // neither arrives within DLL_REPLAY_TIMEOUT_CYCLES. Gated by
    // link_up: won't even present the frame until the PHY layer below
    // reports the link trained - real hardware can't transmit at all
    // before that, so this isn't optional behavior to skip.
    task automatic send_frame(
        input tlp_fmt_e fmt_i, input tlp_type_e typ_i, input logic [31:0] addr_i,
        input logic [9:0] len_i, input logic [31:0] tag_i, input logic [31:0] wdata_i,
        output bit acked
    );
        automatic logic [31:0] lcrc_val;
        automatic int waited;
        acked = 0;

        do begin
            @(drv_cb);
        end while (!drv_cb.link_up);

        forever begin
            lcrc_val = compute_lcrc(seq_ctr, typ_i, addr_i, tag_i, wdata_i);
            @(drv_cb);
            drv_cb.valid   <= 1'b1;
            drv_cb.seq     <= seq_ctr;
            drv_cb.lcrc    <= lcrc_val;
            drv_cb.fmt     <= fmt_i;
            drv_cb.typ     <= typ_i;
            drv_cb.address <= addr_i;
            drv_cb.length  <= len_i;
            drv_cb.tag     <= tag_i;
            drv_cb.wdata   <= wdata_i;

            do begin
                @(drv_cb);
            end while (!(drv_cb.valid && drv_cb.ready));

            waited = 0;
            forever begin
                @(drv_cb);
                waited++;
                if (drv_cb.ack_valid) begin
                    if (drv_cb.ack_ok) begin
                        seq_ctr <= seq_ctr + 1'b1;
                        drv_cb.valid <= 1'b0;
                        acked = 1;
                        `uvm_info(name, $sformatf("Frame seq=%0d ACK'd", seq_ctr), UVM_HIGH)
                        return;
                    end else begin
                        `uvm_warning(name, $sformatf("Frame seq=%0d NAK'd - replaying", seq_ctr))
                        break;  // re-present the same frame, outer forever loop
                    end
                end else if (waited > DLL_REPLAY_TIMEOUT_CYCLES) begin
                    `uvm_error(name, $sformatf(
                        "Replay timeout: no ACK/NAK for seq=%0d after %0d cycles", seq_ctr, waited))
                    drv_cb.valid <= 1'b0;
                    acked = 0;
                    return;
                end
            end
        end
    endtask

    // Receives one completion frame from the EP, checks LCRC,
    // ACK/NAKs it back. Mirrors pcie_dll_ep_driver_bfm.receive_frame
    // exactly, direction reversed - RC is now the receiver.
    task automatic receive_completion(output tlp_type_e typ_o, output logic [31:0] tag_o,
                                       output logic [31:0] data_o, output bit good);
        automatic logic [31:0] expected;
        drv_cb.cpl_ready <= 1'b1;
        do begin
            @(drv_cb);
        end while (!(drv_cb.cpl_valid && drv_cb.cpl_ready && drv_cb.link_up));

        typ_o  = drv_cb.cpl_typ;
        tag_o  = drv_cb.cpl_tag;
        data_o = drv_cb.cpl_data;

        expected = compute_lcrc(drv_cb.cpl_seq, drv_cb.cpl_typ, 32'h0, drv_cb.cpl_tag, drv_cb.cpl_data);
        good = (expected == drv_cb.cpl_lcrc) && (inject_corrupt == 0);
        if (!good && inject_corrupt > 0) inject_corrupt--;

        @(drv_cb);
        drv_cb.cpl_ack_valid <= 1'b1;
        drv_cb.cpl_ack_ok    <= good;
        `uvm_info(name, $sformatf("Completion seq=%0d tag=%0d LCRC check -> %s",
                   drv_cb.cpl_seq, tag_o, good ? "ACK" : "NAK"), UVM_HIGH)
        @(drv_cb);
        drv_cb.cpl_ack_valid <= 1'b0;
    endtask

endinterface : pcie_dll_rc_driver_bfm

`endif
