// RC DLL Monitor BFM
`ifndef PCIE_DLL_RC_MONITOR_BFM_SVH
`define PCIE_DLL_RC_MONITOR_BFM_SVH

import pcie_dll_globals_pkg::*;
import uvm_pkg::*;
`include "uvm_macros.svh"

interface pcie_dll_rc_monitor_bfm (
    input logic clk,
    input logic rst_n,
    input logic valid,
    input logic ready,
    input logic [DLL_SEQ_WIDTH-1:0] seq,
    input logic [31:0]              lcrc,
    input tlp_fmt_e                 fmt,
    input tlp_type_e                typ,
    input logic [31:0]              address,
    input logic [9:0]               length,
    input logic [31:0]              tag,
    input logic [31:0]              wdata,
    input logic                     ack_valid,
    input logic                     ack_ok
);

    string name = "PCIE_DLL_RC_MONITOR_BFM";
    initial `uvm_info(name, $sformatf("%s instantiated", name), UVM_LOW)

    clocking mon_cb @(posedge clk);
        default input #1step output #1step;
        input valid, ready, seq, lcrc, fmt, typ, address, length, tag, wdata, ack_valid, ack_ok;
    endclocking

    // Never drives ready/valid - a monitor observes only. Blocks
    // until the NEXT frame is accepted (valid && ready) and returns
    // its fields, one call per frame.
    task automatic sample_frame(output dll_frame_t frame);
        do begin
            @(mon_cb);
        end while (!(mon_cb.valid && mon_cb.ready));
        frame.seq         = mon_cb.seq;
        frame.lcrc         = mon_cb.lcrc;
        frame.fmt           = mon_cb.fmt;
        frame.typ             = mon_cb.typ;
        frame.address           = mon_cb.address;
        frame.length              = mon_cb.length;
        frame.tag                  = mon_cb.tag;
        frame.payload                = {992'h0, mon_cb.wdata};
        frame.payload_size            = 4;
        frame.timestamp                 = $time;
        `uvm_info(name, $sformatf("Sampled frame seq=%0d %s", frame.seq, frame.typ.name()), UVM_HIGH)
    endtask

    task automatic sample_ack(output bit ok, output logic [DLL_SEQ_WIDTH-1:0] acked_seq);
        do begin
            @(mon_cb);
        end while (!mon_cb.ack_valid);
        ok        = mon_cb.ack_ok;
        acked_seq = mon_cb.seq;
    endtask

endinterface : pcie_dll_rc_monitor_bfm

`endif
