// Config 7: DUT Integration - representative variant
//     RC TLP VIP (active) <-------> EP DUT stub (plain SV, no UVM)
//
// Same mechanism as pcie_full_stack config7 in the earlier hand-rolled
// suite: one variant built thoroughly rather than all 6 spec
// permutations, since every variant is UVM_PASSIVE + a stub at a
// different boundary. The difference here is real: this skeleton's
// pcie_tlp_if is a multi-beat burst-framed bus (tx_data/tx_valid/
// tx_sop/tx_eop, 2 header beats + N payload words), not the simple
// single-cycle parallel interface from the earlier suite - so this
// DUT stub has to actually frame/deframe that protocol correctly,
// mirroring the exact logic pcie_tlp_ep_driver_bfm uses.
`ifndef PCIE_FULL_STACK_CONFIG7_PKG_SVH
`define PCIE_FULL_STACK_CONFIG7_PKG_SVH

package pcie_full_stack_config7_pkg;
    `include "uvm_macros.svh"
    import uvm_pkg::*;
    import pcie_tlp_globals_pkg::*;
    import pcie_tlp_rc_pkg::*;
    import pcie_tlp_rc_seq_pkg::*;

    class pcie_full_stack_config7_env extends uvm_env;
        `uvm_component_utils(pcie_full_stack_config7_env)
        pcie_tlp_rc_agent rc_agent;

        function new(string name, uvm_component parent); super.new(name, parent); endfunction

        function void build_phase(uvm_phase phase);
            pcie_tlp_rc_agent_config cfg;
            super.build_phase(phase);
            cfg = pcie_tlp_rc_agent_config::type_id::create("cfg");
            cfg.is_active = UVM_ACTIVE;
            uvm_config_db#(pcie_tlp_rc_agent_config)::set(this, "rc_agent", "cfg", cfg);
            rc_agent = pcie_tlp_rc_agent::type_id::create("rc_agent", this);
        endfunction
    endclass

    class pcie_full_stack_config7_test extends uvm_test;
        `uvm_component_utils(pcie_full_stack_config7_test)
        pcie_full_stack_config7_env env;

        function new(string name = "pcie_full_stack_config7_test", uvm_component parent = null);
            super.new(name, parent);
        endfunction

        function void build_phase(uvm_phase phase);
            super.build_phase(phase);
            env = pcie_full_stack_config7_env::type_id::create("env", this);
        endfunction

        task run_phase(uvm_phase phase);
            pcie_tlp_rc_base_seq seq = pcie_tlp_rc_base_seq::type_id::create("seq");
            phase.raise_objection(this);
            seq.num_read_transactions   = 3;
            seq.num_write_transactions  = 3;
            seq.num_config_transactions = 0;
            seq.num_io_transactions     = 0;
            seq.start(env.rc_agent.read_sequencer);
            #2000;
            phase.drop_objection(this);
        endtask
    endclass

endpackage

`endif

//=============================================================================
// EP DUT stub - plain SV, no UVM at all. Speaks pcie_tlp_if's real
// burst protocol directly: samples a 2-beat header (dw0..dw3) plus
// however many payload beats dw0[9:0] declares, and for Mem/Cfg Read
// replies with a completion burst (2-beat header + 1 payload word),
// exactly mirroring pcie_tlp_ep_driver_bfm's framing.
//=============================================================================
module ep_dut_stub_burst (
    input  logic         clk,
    input  logic         rst_n,
    input  logic [63:0]  tx_data,     // RC's tx = this module's rx
    input  logic         tx_valid,
    output logic         tx_ready,
    input  logic         tx_sop,
    input  logic         tx_eop,
    input  logic [3:0]   tx_seq_num,
    output logic [63:0]  rx_data,     // this module's tx = RC's rx
    output logic         rx_valid,
    input  logic         rx_ready,
    output logic         rx_sop,
    output logic         rx_eop,
    output logic [3:0]   rx_seq_num
);
    import pcie_tlp_globals_pkg::*;

    logic [31:0] dw0, dw1, dw2, dw3;
    tlp_fmt_e  fmt;
    logic [3:0] seq_num;
    logic [31:0] read_data = 32'hDEAD_BEEF;

    initial begin
        tx_ready <= 1'b1;
        rx_valid <= 1'b0;
    end

    always @(posedge clk) begin
        if (!rst_n) begin
            tx_ready <= 1'b1;
            rx_valid <= 1'b0;
        end
    end

    // Request sampler
    initial begin
        forever begin
            @(posedge clk);
            if (tx_valid && tx_ready && tx_sop) begin
                dw0 = tx_data[31:0];
                dw1 = tx_data[63:32];
                @(posedge clk);
                dw2 = tx_data[31:0];
                dw3 = tx_data[63:32];
                seq_num = tx_seq_num;
                fmt = tlp_fmt_e'(dw0[30:28]);

                // Drain any payload beats (not needed for read/completion
                // logic here, but must be consumed to keep the bus framed).
                while (!tx_eop) @(posedge clk);

                if (fmt inside {TLP_FMT_MEM_READ, TLP_FMT_CFG_READ}) begin
                    send_completion_burst(seq_num);
                end
                // MEM_WRITE/CFG_WRITE: posted-vs-non-posted handling is
                // a TLP-layer concept this minimal stub doesn't model -
                // it just doesn't reply, which is at least correct for
                // the posted MEM_WRITE case exercised by the default
                // rc_base_seq traffic mix.
            end
        end
    end

    task automatic send_completion_burst(logic [3:0] seq_num_i);
        logic [31:0] cmpl_dw0;
        // Matches the real field layout used throughout this VIP:
        // dw0[30:28]=Fmt, dw0[24:19]=Type, dw0[9:0]=Length (in DW).
        cmpl_dw0        = 32'h0;
        cmpl_dw0[30:28] = 3'b000;      // Fmt shape used for completions elsewhere in this VIP
        cmpl_dw0[24:19] = 6'b001010;   // Type = TLP_TYPE_CMPL
        cmpl_dw0[9:0]   = 10'd1;       // Length = 1 DW

        @(posedge clk);
        rx_data  <= {32'h0, cmpl_dw0};
        rx_valid <= 1'b1;
        rx_sop   <= 1'b1;
        rx_eop   <= 1'b0;
        rx_seq_num <= seq_num_i;
        do @(posedge clk); while (!(rx_valid && rx_ready));

        @(posedge clk);
        rx_data  <= 64'h0;   // dw2/dw3 - not decoded by anything in this minimal stub
        rx_valid <= 1'b1;
        rx_sop   <= 1'b0;
        rx_eop   <= 1'b0;
        do @(posedge clk); while (!(rx_valid && rx_ready));

        @(posedge clk);
        rx_data  <= {32'h0, read_data};
        rx_valid <= 1'b1;
        rx_sop   <= 1'b0;
        rx_eop   <= 1'b1;
        do @(posedge clk); while (!(rx_valid && rx_ready));

        @(posedge clk);
        rx_valid <= 1'b0;
    endtask

endmodule : ep_dut_stub_burst

module pcie_full_stack_config7_top;
    import uvm_pkg::*;
    `include "uvm_macros.svh"
    import pcie_tlp_globals_pkg::*;
    import pcie_full_stack_config7_pkg::*;

    bit clk = 0;
    always #5 clk = ~clk;

    bit rst_n = 1;
    initial begin
        #10 rst_n = 0;
        repeat (2) @(posedge clk);
        rst_n = 1;
        `uvm_info("CONFIG7_TOP", "Reset deasserted", UVM_LOW)
    end

    pcie_tlp_if intf (.clk(clk), .rst_n(rst_n));
    pcie_tlp_rc_agent_bfm #(.RC_ID(0)) rc_bfm (intf);

    ep_dut_stub_burst dut (
        .clk(clk), .rst_n(rst_n),
        .tx_data(intf.tx_data), .tx_valid(intf.tx_valid), .tx_ready(intf.tx_ready),
        .tx_sop(intf.tx_sop), .tx_eop(intf.tx_eop), .tx_seq_num(intf.tx_seq_num),
        .rx_data(intf.rx_data), .rx_valid(intf.rx_valid), .rx_ready(intf.rx_ready),
        .rx_sop(intf.rx_sop), .rx_eop(intf.rx_eop), .rx_seq_num(intf.rx_seq_num)
    );

    initial begin
        run_test("pcie_full_stack_config7_test");
    end

endmodule : pcie_full_stack_config7_top
