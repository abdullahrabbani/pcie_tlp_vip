// Config 4 Top: TLP + DLL, no PHY. dll_intf.link_up is tied statically
// high since there's no PHY layer in this configuration to gate it -
// contrast with Config 6/pcie_full_stack_top.sv, where link_gate
// drives it from real LTSSM training.
module pcie_full_stack_config4_top;
    import uvm_pkg::*;
    `include "uvm_macros.svh"
    import pcie_tlp_globals_pkg::*;
    import pcie_dll_globals_pkg::*;
    import pcie_full_stack_config4_pkg::*;

    bit clk = 0;
    always #5 clk = ~clk;

    bit rst_n = 1;
    initial begin
        #10 rst_n = 0;
        repeat (2) @(posedge clk);
        rst_n = 1;
        `uvm_info("CONFIG4_TOP", "Reset deasserted", UVM_LOW)
    end

    pcie_tlp_if dummy_tlp_intf (.clk(clk), .rst_n(rst_n));
    pcie_tlp_rc_agent_bfm #(.RC_ID(0)) dummy_tlp_rc_bfm (dummy_tlp_intf);

    pcie_dll_if dll_intf (.clk(clk), .rst_n(rst_n));
    assign dll_intf.link_up = 1'b1;
    pcie_dll_rc_agent_bfm #(.RC_ID(0)) dll_rc_bfm (dll_intf);
    pcie_dll_ep_agent_bfm #(.EP_ID(0)) dll_ep_bfm (dll_intf);

    initial begin
        run_test("pcie_full_stack_config4_test");
    end

endmodule : pcie_full_stack_config4_top
