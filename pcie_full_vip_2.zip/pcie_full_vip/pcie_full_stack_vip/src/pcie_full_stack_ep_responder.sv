// Full Stack EP Responder
//
// This fixes the gap found while building the integration: the
// ported TLP skeleton's ep_driver_proxy never actually listens to the
// wire (bfm.sample_request() is only called by the passive monitor)
// - it pulls independently-randomized pcie_tlp_ep_tx items from
// ep_base_seq instead, completely disconnected from what RC actually
// sent. This responder is a genuine fix, not a workaround: it
// subscribes to REAL frames arriving via DLL's ep_driver_proxy
// (frame_ap, populated only after a frame passes LCRC and gets
// ACK'd), services them against a real memory model, and sends a
// real completion back through DLL's completion channel.
`ifndef PCIE_FULL_STACK_EP_RESPONDER_SVH
`define PCIE_FULL_STACK_EP_RESPONDER_SVH

class pcie_full_stack_ep_responder extends uvm_subscriber #(pcie_dll_rc_tx);
    `uvm_component_utils(pcie_full_stack_ep_responder)

    pcie_dll_ep_driver_proxy dll_ep_driver;   // set by env.connect_phase()
    pcie_tlp_ep_memory       memory;
    semaphore                cpl_sem;          // serializes completion sends - single completion channel

    int min_address = 32'h0000_0000;
    int max_address = 32'h0000_0FFF;
    int default_read_data = 32'hDEAD_BEEF;

    function new(string name, uvm_component parent);
        super.new(name, parent);
        cpl_sem = new(1);
    endfunction

    function void build_phase(uvm_phase phase);
        super.build_phase(phase);
        memory = pcie_tlp_ep_memory::type_id::create("memory", this);
        memory.min_address = min_address;
        memory.max_address = max_address;
        memory.default_read_data = default_read_data;
    endfunction

    // uvm_subscriber's write() must return immediately (it's a plain
    // function, no blocking allowed) - the actual servicing, which
    // needs to wait on DLL's completion handshake, runs in a
    // background process instead.
    function void write(pcie_dll_rc_tx t);
        fork
            process_frame(t);
        join_none
    endfunction

    task process_frame(pcie_dll_rc_tx t);
        logic [31:0] read_data;

        case (t.fmt)
            TLP_FMT_MEM_READ: begin
                read_data = memory.is_addr_valid(t.address) ? memory.mem_read_word(t.address) : default_read_data;
                `uvm_info(get_type_name(), $sformatf("MRd addr=0x%08x -> data=0x%08x", t.address, read_data), UVM_MEDIUM)
                send_completion_serialized(TLP_TYPE_CMPL, t.tag, read_data);
            end
            TLP_FMT_MEM_WRITE: begin
                if (memory.is_addr_valid(t.address)) memory.mem_write_word(t.address, t.wdata);
                `uvm_info(get_type_name(), $sformatf("MWr addr=0x%08x data=0x%08x (posted, no completion)", t.address, t.wdata), UVM_MEDIUM)
                // Posted - no completion. Matches the fix already made
                // to pcie_tlp_ep_driver_proxy for the standalone TLP VIP.
            end
            TLP_FMT_CFG_READ: begin
                read_data = memory.cfg_read(t.address & 32'hFF);
                send_completion_serialized(TLP_TYPE_CMPL, t.tag, read_data);
            end
            TLP_FMT_CFG_WRITE: begin
                memory.cfg_write(t.address & 32'hFF, t.wdata);
                send_completion_serialized(TLP_TYPE_CMPL, t.tag, 32'h0);
            end
            default: `uvm_warning(get_type_name(), $sformatf("Unhandled fmt %s", t.fmt.name()))
        endcase
    endtask

    task send_completion_serialized(tlp_type_e typ_i, logic [31:0] tag_i, logic [31:0] data_i);
        bit acked;
        cpl_sem.get(1);
        dll_ep_driver.send_completion(typ_i, tag_i, data_i, acked);
        cpl_sem.put(1);
        if (!acked)
            `uvm_error(get_type_name(), $sformatf("Completion for tag=%0d never got DLL ACK", tag_i))
    endtask

endclass

`endif
