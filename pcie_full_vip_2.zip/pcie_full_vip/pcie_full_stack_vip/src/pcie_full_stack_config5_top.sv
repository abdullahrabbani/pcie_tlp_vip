// Config 5 Top: DLL + PHY, no TLP. dll_intf.link_up is driven by
// link_gate from real PHY training - the mirror image of Config 4,
// which had DLL+TLP but a static link_up since it has no PHY.
module pcie_full_stack_config5_top;
    import uvm_pkg::*;
    `include "uvm_macros.svh"
    import pcie_dll_globals_pkg::*;
    import pcie_phy_globals_pkg::*;
    import pcie_full_stack_config5_pkg::*;

    bit clk = 0;
    always #5 clk = ~clk;

    bit rst_n = 1;
    initial begin
        #10 rst_n = 0;
        repeat (2) @(posedge clk);
        rst_n = 1;
        `uvm_info("CONFIG5_TOP", "Reset deasserted", UVM_LOW)
    end

    pcie_dll_if dll_intf (.clk(clk), .rst_n(rst_n));
    pcie_dll_rc_agent_bfm #(.RC_ID(0)) dll_rc_bfm (dll_intf);
    pcie_dll_ep_agent_bfm #(.EP_ID(0)) dll_ep_bfm (dll_intf);

    pcie_phy_if phy_intf (.clk(clk), .rst_n(rst_n));
    pcie_phy_rc_agent_bfm #(.RC_ID(0)) phy_rc_bfm (phy_intf);
    pcie_phy_ep_agent_bfm #(.EP_ID(0)) phy_ep_bfm (phy_intf);

    initial begin
        uvm_config_db#(virtual pcie_dll_if)::set(null, "*", "pcie_dll_if", dll_intf);
        run_test("pcie_full_stack_config5_test");
    end

endmodule : pcie_full_stack_config5_top
