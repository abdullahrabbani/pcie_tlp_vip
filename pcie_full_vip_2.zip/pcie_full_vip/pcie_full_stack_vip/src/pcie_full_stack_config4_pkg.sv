// Config 4: TLP + DLL (no PHY)
//     RC TLP -> RC DLL <-------> EP DLL -> EP TLP
`ifndef PCIE_FULL_STACK_CONFIG4_PKG_SVH
`define PCIE_FULL_STACK_CONFIG4_PKG_SVH

package pcie_full_stack_config4_pkg;
    `include "uvm_macros.svh"
    import uvm_pkg::*;
    import pcie_tlp_globals_pkg::*;
    import pcie_tlp_rc_pkg::*;
    import pcie_tlp_ep_pkg::*;
    import pcie_tlp_rc_seq_pkg::*;
    import pcie_dll_globals_pkg::*;
    import pcie_dll_rc_pkg::*;
    import pcie_dll_ep_pkg::*;
    import pcie_full_stack_pkg::*;   // reuses pcie_full_stack_rc_driver_proxy, pcie_full_stack_ep_responder

    class pcie_full_stack_config4_env extends uvm_env;
        `uvm_component_utils(pcie_full_stack_config4_env)

        pcie_tlp_rc_agent tlp_rc_agent;
        pcie_dll_rc_agent dll_rc_agent;
        pcie_dll_ep_agent dll_ep_agent;
        pcie_full_stack_ep_responder ep_responder;

        function new(string name, uvm_component parent); super.new(name, parent); endfunction

        function void build_phase(uvm_phase phase);
            pcie_tlp_rc_agent_config tlp_rc_cfg;
            pcie_dll_rc_agent_config dll_rc_cfg;
            pcie_dll_ep_agent_config dll_ep_cfg;
            super.build_phase(phase);

            set_type_override_by_type(pcie_tlp_rc_driver_proxy::get_type(),
                                        pcie_full_stack_rc_driver_proxy::get_type());

            tlp_rc_cfg = pcie_tlp_rc_agent_config::type_id::create("tlp_rc_cfg");
            tlp_rc_cfg.is_active = UVM_ACTIVE;
            uvm_config_db#(pcie_tlp_rc_agent_config)::set(this, "tlp_rc_agent", "cfg", tlp_rc_cfg);
            tlp_rc_agent = pcie_tlp_rc_agent::type_id::create("tlp_rc_agent", this);

            dll_rc_cfg = pcie_dll_rc_agent_config::type_id::create("dll_rc_cfg");
            dll_rc_cfg.is_active = UVM_ACTIVE;
            uvm_config_db#(pcie_dll_rc_agent_config)::set(this, "dll_rc_agent", "cfg", dll_rc_cfg);
            dll_rc_agent = pcie_dll_rc_agent::type_id::create("dll_rc_agent", this);

            dll_ep_cfg = pcie_dll_ep_agent_config::type_id::create("dll_ep_cfg");
            dll_ep_cfg.is_active = UVM_ACTIVE;
            uvm_config_db#(pcie_dll_ep_agent_config)::set(this, "dll_ep_agent", "cfg", dll_ep_cfg);
            dll_ep_agent = pcie_dll_ep_agent::type_id::create("dll_ep_agent", this);

            ep_responder = pcie_full_stack_ep_responder::type_id::create("ep_responder", this);
        endfunction

        function void connect_phase(uvm_phase phase);
            pcie_full_stack_rc_driver_proxy bridge_drv;
            super.connect_phase(phase);
            if (!$cast(bridge_drv, tlp_rc_agent.driver))
                `uvm_fatal(get_type_name(), "Factory override for RC driver_proxy did not take effect")
            bridge_drv.dll_driver = dll_rc_agent.driver;

            ep_responder.dll_ep_driver = dll_ep_agent.driver;
            dll_ep_agent.driver.frame_ap.connect(ep_responder.analysis_export);
        endfunction

    endclass

    class pcie_full_stack_config4_test extends uvm_test;
        `uvm_component_utils(pcie_full_stack_config4_test)
        pcie_full_stack_config4_env env;

        function new(string name = "pcie_full_stack_config4_test", uvm_component parent = null);
            super.new(name, parent);
        endfunction

        function void build_phase(uvm_phase phase);
            super.build_phase(phase);
            env = pcie_full_stack_config4_env::type_id::create("env", this);
        endfunction

        task run_phase(uvm_phase phase);
            pcie_tlp_rc_base_seq seq = pcie_tlp_rc_base_seq::type_id::create("seq");
            phase.raise_objection(this);
            seq.num_read_transactions   = 3;
            seq.num_write_transactions  = 3;
            seq.num_config_transactions = 0;
            seq.num_io_transactions     = 0;
            seq.start(env.tlp_rc_agent.read_sequencer);
            #2000;
            phase.drop_objection(this);
        endtask
    endclass

endpackage

`endif
