// Config 5: DLL + PHY (no TLP)
//     RC DLL -> RC PHY <-------> EP PHY -> EP DLL
`ifndef PCIE_FULL_STACK_CONFIG5_PKG_SVH
`define PCIE_FULL_STACK_CONFIG5_PKG_SVH

package pcie_full_stack_config5_pkg;
    `include "uvm_macros.svh"
    import uvm_pkg::*;
    import pcie_dll_globals_pkg::*;
    import pcie_dll_rc_pkg::*;
    import pcie_dll_ep_pkg::*;
    import pcie_dll_rc_seq_pkg::*;   // pcie_dll_rc_base_seq
    import pcie_phy_globals_pkg::*;
    import pcie_phy_rc_pkg::*;
    import pcie_phy_ep_pkg::*;
    import pcie_full_stack_pkg::*;   // reuses pcie_full_stack_link_gate

    class pcie_full_stack_config5_env extends uvm_env;
        `uvm_component_utils(pcie_full_stack_config5_env)

        pcie_dll_rc_agent dll_rc_agent;
        pcie_dll_ep_agent dll_ep_agent;
        pcie_phy_rc_agent phy_rc_agent;
        pcie_phy_ep_agent phy_ep_agent;
        pcie_full_stack_link_gate link_gate;

        function new(string name, uvm_component parent); super.new(name, parent); endfunction

        function void build_phase(uvm_phase phase);
            pcie_dll_rc_agent_config dll_rc_cfg;
            pcie_dll_ep_agent_config dll_ep_cfg;
            pcie_phy_rc_agent_config phy_rc_cfg;
            pcie_phy_ep_agent_config phy_ep_cfg;
            super.build_phase(phase);

            dll_rc_cfg = pcie_dll_rc_agent_config::type_id::create("dll_rc_cfg");
            dll_rc_cfg.is_active = UVM_ACTIVE;
            uvm_config_db#(pcie_dll_rc_agent_config)::set(this, "dll_rc_agent", "cfg", dll_rc_cfg);
            dll_rc_agent = pcie_dll_rc_agent::type_id::create("dll_rc_agent", this);

            dll_ep_cfg = pcie_dll_ep_agent_config::type_id::create("dll_ep_cfg");
            dll_ep_cfg.is_active = UVM_ACTIVE;
            uvm_config_db#(pcie_dll_ep_agent_config)::set(this, "dll_ep_agent", "cfg", dll_ep_cfg);
            dll_ep_agent = pcie_dll_ep_agent::type_id::create("dll_ep_agent", this);

            phy_rc_cfg = pcie_phy_rc_agent_config::type_id::create("phy_rc_cfg");
            phy_rc_cfg.is_active = UVM_ACTIVE;
            uvm_config_db#(pcie_phy_rc_agent_config)::set(this, "phy_rc_agent", "cfg", phy_rc_cfg);
            phy_rc_agent = pcie_phy_rc_agent::type_id::create("phy_rc_agent", this);

            phy_ep_cfg = pcie_phy_ep_agent_config::type_id::create("phy_ep_cfg");
            phy_ep_cfg.is_active = UVM_ACTIVE;
            uvm_config_db#(pcie_phy_ep_agent_config)::set(this, "phy_ep_agent", "cfg", phy_ep_cfg);
            phy_ep_agent = pcie_phy_ep_agent::type_id::create("phy_ep_agent", this);

            link_gate = pcie_full_stack_link_gate::type_id::create("link_gate", this);
        endfunction

        function void connect_phase(uvm_phase phase);
            super.connect_phase(phase);
            link_gate.rc_phy_driver = phy_rc_agent.driver;
            link_gate.ep_phy_driver = phy_ep_agent.driver;
        endfunction

    endclass

    class pcie_full_stack_config5_test extends uvm_test;
        `uvm_component_utils(pcie_full_stack_config5_test)
        pcie_full_stack_config5_env env;

        function new(string name = "pcie_full_stack_config5_test", uvm_component parent = null);
            super.new(name, parent);
        endfunction

        function void build_phase(uvm_phase phase);
            super.build_phase(phase);
            env = pcie_full_stack_config5_env::type_id::create("env", this);
        endfunction

        task run_phase(uvm_phase phase);
            pcie_dll_rc_base_seq seq = pcie_dll_rc_base_seq::type_id::create("seq");
            phase.raise_objection(this);
            // Real training takes ~2*PHY_POLLING/CONFIG_CYCLES before
            // link_up asserts; wait for it explicitly rather than
            // relying on send_frame's own internal link_up poll,
            // which would work either way but makes the log noisier
            // if frames are attempted before training completes.
            #500;
            seq.num_frames = 5;
            seq.start(env.dll_rc_agent.sequencer);
            #500;
            phase.drop_objection(this);
        endtask
    endclass

endpackage

`endif
