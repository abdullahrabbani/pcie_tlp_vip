// Full Stack Environment
`ifndef PCIE_FULL_STACK_ENV_SVH
`define PCIE_FULL_STACK_ENV_SVH

class pcie_full_stack_env extends uvm_env;
    `uvm_component_utils(pcie_full_stack_env)

    // TLP layer - RC side only. There is no tlp_ep_agent here: EP's
    // TLP-level behavior is provided by pcie_full_stack_ep_responder
    // instead, which reacts to REAL frames instead of pcie_tlp_ep_pkg's
    // disconnected ep_base_seq stimulus (see that file's header for why).
    pcie_tlp_rc_agent tlp_rc_agent;

    // DLL layer - both sides, now with the completion channel.
    pcie_dll_rc_agent dll_rc_agent;
    pcie_dll_ep_agent dll_ep_agent;

    // PHY layer - both sides, real LTSSM.
    pcie_phy_rc_agent phy_rc_agent;
    pcie_phy_ep_agent phy_ep_agent;

    pcie_full_stack_ep_responder ep_responder;
    pcie_full_stack_link_gate    link_gate;

    function new(string name, uvm_component parent);
        super.new(name, parent);
    endfunction

    function void build_phase(uvm_phase phase);
        pcie_tlp_rc_agent_config tlp_rc_cfg;
        pcie_dll_rc_agent_config dll_rc_cfg;
        pcie_dll_ep_agent_config dll_ep_cfg;
        pcie_phy_rc_agent_config phy_rc_cfg;
        pcie_phy_ep_agent_config phy_ep_cfg;

        super.build_phase(phase);

        // The one factory override that makes this a real integration:
        // pcie_tlp_rc_agent is completely unmodified, it just gets a
        // different driver_proxy implementation swapped in underneath it.
        set_type_override_by_type(pcie_tlp_rc_driver_proxy::get_type(),
                                    pcie_full_stack_rc_driver_proxy::get_type());

        tlp_rc_cfg = pcie_tlp_rc_agent_config::type_id::create("tlp_rc_cfg");
        tlp_rc_cfg.is_active = UVM_ACTIVE;
        uvm_config_db#(pcie_tlp_rc_agent_config)::set(this, "tlp_rc_agent", "cfg", tlp_rc_cfg);
        tlp_rc_agent = pcie_tlp_rc_agent::type_id::create("tlp_rc_agent", this);

        dll_rc_cfg = pcie_dll_rc_agent_config::type_id::create("dll_rc_cfg");
        dll_rc_cfg.is_active = UVM_ACTIVE;
        uvm_config_db#(pcie_dll_rc_agent_config)::set(this, "dll_rc_agent", "cfg", dll_rc_cfg);
        dll_rc_agent = pcie_dll_rc_agent::type_id::create("dll_rc_agent", this);

        dll_ep_cfg = pcie_dll_ep_agent_config::type_id::create("dll_ep_cfg");
        dll_ep_cfg.is_active = UVM_ACTIVE;
        uvm_config_db#(pcie_dll_ep_agent_config)::set(this, "dll_ep_agent", "cfg", dll_ep_cfg);
        dll_ep_agent = pcie_dll_ep_agent::type_id::create("dll_ep_agent", this);

        phy_rc_cfg = pcie_phy_rc_agent_config::type_id::create("phy_rc_cfg");
        phy_rc_cfg.is_active = UVM_ACTIVE;
        uvm_config_db#(pcie_phy_rc_agent_config)::set(this, "phy_rc_agent", "cfg", phy_rc_cfg);
        phy_rc_agent = pcie_phy_rc_agent::type_id::create("phy_rc_agent", this);

        phy_ep_cfg = pcie_phy_ep_agent_config::type_id::create("phy_ep_cfg");
        phy_ep_cfg.is_active = UVM_ACTIVE;
        uvm_config_db#(pcie_phy_ep_agent_config)::set(this, "phy_ep_agent", "cfg", phy_ep_cfg);
        phy_ep_agent = pcie_phy_ep_agent::type_id::create("phy_ep_agent", this);

        ep_responder = pcie_full_stack_ep_responder::type_id::create("ep_responder", this);
        link_gate    = pcie_full_stack_link_gate::type_id::create("link_gate", this);
    endfunction

    function void connect_phase(uvm_phase phase);
        pcie_full_stack_rc_driver_proxy bridge_drv;
        super.connect_phase(phase);

        if (!$cast(bridge_drv, tlp_rc_agent.driver))
            `uvm_fatal(get_type_name(), "Factory override for RC driver_proxy did not take effect")
        bridge_drv.dll_driver = dll_rc_agent.driver;

        ep_responder.dll_ep_driver = dll_ep_agent.driver;
        dll_ep_agent.driver.frame_ap.connect(ep_responder.analysis_export);

        link_gate.rc_phy_driver = phy_rc_agent.driver;
        link_gate.ep_phy_driver = phy_ep_agent.driver;
    endfunction

endclass

`endif
