// Full Stack Top
//
// A dummy pcie_tlp_if + pcie_tlp_rc_agent_bfm is instantiated purely
// to satisfy pcie_tlp_rc_monitor_proxy's config_db lookup (it's part
// of the unmodified pcie_tlp_rc_agent, which this integration
// deliberately does NOT touch - only the driver_proxy is swapped via
// factory override). Its wires never carry real traffic: all actual
// TLP data flows through pcie_dll_if instead. The monitor simply
// blocks forever waiting for tx_valid&&tx_sop, which is harmless.
module pcie_full_stack_top;
    import uvm_pkg::*;
    `include "uvm_macros.svh"
    import pcie_tlp_globals_pkg::*;
    import pcie_dll_globals_pkg::*;
    import pcie_phy_globals_pkg::*;
    import pcie_full_stack_pkg::*;

    bit clk = 0;
    always #5 clk = ~clk;

    bit rst_n = 1;
    initial begin
        #10 rst_n = 0;
        repeat (2) @(posedge clk);
        rst_n = 1;
        `uvm_info("FULL_STACK_TOP", "Reset deasserted", UVM_LOW)
    end

    // --- Dummy TLP interface: unused for real traffic, see header ---
    pcie_tlp_if dummy_tlp_intf (.clk(clk), .rst_n(rst_n));
    pcie_tlp_rc_agent_bfm #(.RC_ID(0)) dummy_tlp_rc_bfm (dummy_tlp_intf);

    // --- Real DLL interface: carries all actual TLP traffic ---
    pcie_dll_if dll_intf (.clk(clk), .rst_n(rst_n));
    pcie_dll_rc_agent_bfm #(.RC_ID(0)) dll_rc_bfm (dll_intf);
    pcie_dll_ep_agent_bfm #(.EP_ID(0)) dll_ep_bfm (dll_intf);

    // --- Real PHY interface: real LTSSM training ---
    pcie_phy_if phy_intf (.clk(clk), .rst_n(rst_n));
    pcie_phy_rc_agent_bfm #(.RC_ID(0)) phy_rc_bfm (phy_intf);
    pcie_phy_ep_agent_bfm #(.EP_ID(0)) phy_ep_bfm (phy_intf);

    initial begin
        // pcie_full_stack_link_gate needs the raw interface handle
        // (not a per-signal BFM view) since it drives link_up directly.
        uvm_config_db#(virtual pcie_dll_if)::set(null, "*", "pcie_dll_if", dll_intf);
        run_test("pcie_full_stack_base_test");
    end

    initial begin
        $dumpfile("waveform.vcd");
        $dumpvars(0, pcie_full_stack_top);
    end

endmodule : pcie_full_stack_top
