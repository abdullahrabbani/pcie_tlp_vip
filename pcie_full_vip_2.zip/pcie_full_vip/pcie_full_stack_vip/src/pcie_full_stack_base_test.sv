// Full Stack Base Test
`ifndef PCIE_FULL_STACK_BASE_TEST_SVH
`define PCIE_FULL_STACK_BASE_TEST_SVH

class pcie_full_stack_base_test extends uvm_test;
    `uvm_component_utils(pcie_full_stack_base_test)
    pcie_full_stack_env env;

    function new(string name = "pcie_full_stack_base_test", uvm_component parent = null);
        super.new(name, parent);
    endfunction

    function void build_phase(uvm_phase phase);
        super.build_phase(phase);
        env = pcie_full_stack_env::type_id::create("env", this);
    endfunction

    task run_phase(uvm_phase phase);
        pcie_tlp_rc_base_seq seq = pcie_tlp_rc_base_seq::type_id::create("seq");
        phase.raise_objection(this);

        // Give PHY time to train before issuing TLP traffic -
        // pcie_full_stack_rc_driver_proxy would otherwise just block
        // inside dll_driver.bfm.send_frame() on link_up anyway, but
        // waiting here keeps the log timeline readable.
        #500;

        seq.num_read_transactions   = 3;
        seq.num_write_transactions  = 3;
        seq.num_config_transactions = 0;
        seq.num_io_transactions     = 0;
        seq.start(env.tlp_rc_agent.read_sequencer);

        #3000;
        phase.drop_objection(this);
    endtask

endclass

`endif
