// Full Stack Package
`ifndef PCIE_FULL_STACK_PKG_SVH
`define PCIE_FULL_STACK_PKG_SVH

package pcie_full_stack_pkg;
    `include "uvm_macros.svh"
    import uvm_pkg::*;

    import pcie_tlp_globals_pkg::*;
    import pcie_tlp_rc_pkg::*;
    import pcie_tlp_ep_pkg::*;        // pcie_tlp_ep_memory, reused by the responder
    import pcie_tlp_rc_seq_pkg::*;    // pcie_tlp_rc_base_seq, used by the test

    import pcie_dll_globals_pkg::*;
    import pcie_dll_rc_pkg::*;
    import pcie_dll_ep_pkg::*;

    import pcie_phy_globals_pkg::*;
    import pcie_phy_rc_pkg::*;
    import pcie_phy_ep_pkg::*;

    `include "pcie_full_stack_rc_bridge.sv"
    `include "pcie_full_stack_ep_responder.sv"
    `include "pcie_full_stack_link_gate.sv"
    `include "pcie_full_stack_env.sv"
    `include "pcie_full_stack_base_test.sv"
endpackage

`endif
