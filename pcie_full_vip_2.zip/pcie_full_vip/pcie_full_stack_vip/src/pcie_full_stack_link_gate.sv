// Full Stack Link Gate
// Drives pcie_dll_if.link_up from both PHY driver_proxies' is_link_up() -
// the integration point every earlier layer's README pointed at but
// deferred. Needs a plain component (not a continuous assign) because
// is_link_up() is a UVM method call, not an elaboration-time signal.
`ifndef PCIE_FULL_STACK_LINK_GATE_SVH
`define PCIE_FULL_STACK_LINK_GATE_SVH

class pcie_full_stack_link_gate extends uvm_component;
    `uvm_component_utils(pcie_full_stack_link_gate)
    virtual pcie_dll_if dll_vif;
    pcie_phy_rc_driver_proxy rc_phy_driver;   // set by env.connect_phase()
    pcie_phy_ep_driver_proxy ep_phy_driver;

    function new(string name, uvm_component parent);
        super.new(name, parent);
    endfunction

    function void build_phase(uvm_phase phase);
        super.build_phase(phase);
        if (!uvm_config_db#(virtual pcie_dll_if)::get(this, "", "pcie_dll_if", dll_vif))
            `uvm_fatal(get_type_name(), "Failed to get pcie_dll_if handle")
    endfunction

    task run_phase(uvm_phase phase);
        dll_vif.link_up <= 1'b0;
        forever begin
            @(posedge dll_vif.clk);
            dll_vif.link_up <= (rc_phy_driver.is_link_up() && ep_phy_driver.is_link_up());
        end
    endtask

endclass

`endif
