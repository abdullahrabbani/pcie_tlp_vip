// Full Stack RC Bridge
// Routes pcie_tlp_rc_driver_proxy's traffic through the DLL layer
// (pcie_dll_rc_driver_proxy) instead of driving pcie_tlp_vip's own
// raw AXI-stream-style wires directly. Implemented as a subclass with
// build_phase/run_phase overridden, installed via a factory type
// override in pcie_full_stack_env - pcie_tlp_rc_agent itself is
// completely unmodified.
`ifndef PCIE_FULL_STACK_RC_BRIDGE_SVH
`define PCIE_FULL_STACK_RC_BRIDGE_SVH

class pcie_full_stack_rc_driver_proxy extends pcie_tlp_rc_driver_proxy;
    `uvm_component_utils(pcie_full_stack_rc_driver_proxy)

    // Set directly by pcie_full_stack_env.connect_phase() - not via
    // config_db, since it's a plain object handle assignment between
    // two already-built components in the same environment.
    pcie_dll_rc_driver_proxy dll_driver;

    function new(string name = "pcie_full_stack_rc_driver_proxy", uvm_component parent = null);
        super.new(name, parent);
    endfunction

    // Deliberately does NOT call super.build_phase() - the TLP-native
    // pcie_tlp_rc_driver_bfm is never used in integrated mode, so
    // there's no need to fetch it (and no hdl_top wiring provides one
    // in the Full Stack top anyway).
    function void build_phase(uvm_phase phase);
    endfunction

    task run_phase(uvm_phase phase);
        pcie_tlp_rc_tx req, rsp;
        bit acked, good;
        tlp_type_e cpl_typ;
        logic [31:0] cpl_tag, cpl_data;

        forever begin
            seq_item_port.get_next_item(req);
            `uvm_info(get_type_name(), $sformatf(
                "Routing TLP ID %0d (%s %s addr=0x%08x) down through DLL",
                req.transaction_id, req.fmt.name(), req.typ.name(), req.address), UVM_MEDIUM)

            dll_driver.bfm.send_frame(req.fmt, req.typ, req.address, req.length,
                                        req.tag, req.payload[31:0], acked);

            rsp = pcie_tlp_rc_tx::type_id::create("rsp");
            rsp.set_id_info(req);
            rsp.set_transaction_id(req.transaction_id);

            if (!acked) begin
                `uvm_error(get_type_name(), $sformatf(
                    "TLP ID %0d never got DLL-level ACK (replay timeout) - no completion possible",
                    req.transaction_id))
            end else if (is_posted(req.fmt)) begin
                `uvm_info(get_type_name(), $sformatf(
                    "Posted %s TLP ID %0d retired after DLL ACK (no completion expected)",
                    req.fmt.name(), req.transaction_id), UVM_MEDIUM)
            end else begin
                // Non-posted: wait for the real completion to travel
                // back up through DLL from the EP's TLP layer.
                dll_driver.receive_completion(cpl_typ, cpl_tag, cpl_data, good);
                if (!good)
                    `uvm_error(get_type_name(), $sformatf(
                        "Completion for TLP ID %0d failed LCRC check", req.transaction_id))
                rsp.tlp.payload      = {992'h0, cpl_data};
                rsp.tlp.payload_size = 4;
                `uvm_info(get_type_name(), $sformatf(
                    "Completion received for TLP ID %0d: data=0x%08x", req.transaction_id, cpl_data), UVM_MEDIUM)
            end

            seq_item_port.item_done(rsp);
        end
    endtask

endclass

`endif
