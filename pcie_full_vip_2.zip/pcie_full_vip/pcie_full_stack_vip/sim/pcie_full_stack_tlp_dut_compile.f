// ============================================================================
// PCIe Full Stack Integration - Compile File
// Pulls together pcie_tlp_vip, pcie_dll_vip, and pcie_phy_vip
// (siblings under the same parent directory) plus this project's own
// integration package.
// ============================================================================

-sv

// ---- Include Directories ----

// TLP VIP
+incdir+../../pcie_tlp_vip/src/globals/
+incdir+../../pcie_tlp_vip/src/hdl_top/pcie_tlp_interface/
+incdir+../../pcie_tlp_vip/src/hdl_top/rc_agent_bfm/
+incdir+../../pcie_tlp_vip/src/hdl_top/ep_agent_bfm/
+incdir+../../pcie_tlp_vip/src/hvl_top/rc/
+incdir+../../pcie_tlp_vip/src/hvl_top/ep/
+incdir+../../pcie_tlp_vip/src/hvl_top/test/sequences/rc_sequences/

// DLL VIP
+incdir+../../pcie_dll_vip/src/globals/
+incdir+../../pcie_dll_vip/src/hdl_top/pcie_dll_interface/
+incdir+../../pcie_dll_vip/src/hdl_top/rc_agent_bfm/
+incdir+../../pcie_dll_vip/src/hdl_top/ep_agent_bfm/
+incdir+../../pcie_dll_vip/src/hvl_top/rc/
+incdir+../../pcie_dll_vip/src/hvl_top/ep/

// PHY VIP
+incdir+../../pcie_phy_vip/src/globals/
+incdir+../../pcie_phy_vip/src/hdl_top/pcie_phy_interface/
+incdir+../../pcie_phy_vip/src/hdl_top/rc_agent_bfm/
+incdir+../../pcie_phy_vip/src/hdl_top/ep_agent_bfm/
+incdir+../../pcie_phy_vip/src/hvl_top/rc/
+incdir+../../pcie_phy_vip/src/hvl_top/ep/

// This project
+incdir+../src/

// ---- Global Packages ----
../../pcie_tlp_vip/src/globals/pcie_tlp_globals_pkg.sv
../../pcie_dll_vip/src/globals/pcie_dll_globals_pkg.sv
../../pcie_phy_vip/src/globals/pcie_phy_globals_pkg.sv

// ---- TLP VIP packages ----
../../pcie_tlp_vip/src/hvl_top/rc/pcie_tlp_rc_pkg.sv
../../pcie_tlp_vip/src/hvl_top/ep/pcie_tlp_ep_pkg.sv
../../pcie_tlp_vip/src/hvl_top/test/sequences/rc_sequences/pcie_tlp_rc_seq_pkg.sv

// ---- DLL VIP packages ----
../../pcie_dll_vip/src/hvl_top/rc/pcie_dll_rc_pkg.sv
../../pcie_dll_vip/src/hvl_top/ep/pcie_dll_ep_pkg.sv

// ---- PHY VIP packages ----
../../pcie_phy_vip/src/hvl_top/rc/pcie_phy_rc_pkg.sv
../../pcie_phy_vip/src/hvl_top/ep/pcie_phy_ep_pkg.sv

// ---- Integration package ----
../src/pcie_full_stack_pkg.sv

// ---- Interfaces ----
../../pcie_tlp_vip/src/hdl_top/pcie_tlp_interface/pcie_tlp_if.sv
../../pcie_dll_vip/src/hdl_top/pcie_dll_interface/pcie_dll_if.sv
../../pcie_phy_vip/src/hdl_top/pcie_phy_interface/pcie_phy_if.sv

// ---- TLP RC Agent BFM (only the RC side is used, as a dummy - see pcie_full_stack_top.sv) ----
../../pcie_tlp_vip/src/hdl_top/rc_agent_bfm/pcie_tlp_rc_agent_bfm.sv
../../pcie_tlp_vip/src/hdl_top/rc_agent_bfm/pcie_tlp_rc_driver_bfm.sv
../../pcie_tlp_vip/src/hdl_top/rc_agent_bfm/pcie_tlp_rc_monitor_bfm.sv

// ---- DLL Agent BFMs ----
../../pcie_dll_vip/src/hdl_top/rc_agent_bfm/pcie_dll_rc_agent_bfm.sv
../../pcie_dll_vip/src/hdl_top/rc_agent_bfm/pcie_dll_rc_driver_bfm.sv
../../pcie_dll_vip/src/hdl_top/rc_agent_bfm/pcie_dll_rc_monitor_bfm.sv
../../pcie_dll_vip/src/hdl_top/ep_agent_bfm/pcie_dll_ep_agent_bfm.sv
../../pcie_dll_vip/src/hdl_top/ep_agent_bfm/pcie_dll_ep_driver_bfm.sv
../../pcie_dll_vip/src/hdl_top/ep_agent_bfm/pcie_dll_ep_monitor_bfm.sv

// ---- PHY Agent BFMs ----
../../pcie_phy_vip/src/hdl_top/rc_agent_bfm/pcie_phy_rc_agent_bfm.sv
../../pcie_phy_vip/src/hdl_top/rc_agent_bfm/pcie_phy_rc_driver_bfm.sv
../../pcie_phy_vip/src/hdl_top/rc_agent_bfm/pcie_phy_rc_monitor_bfm.sv
../../pcie_phy_vip/src/hdl_top/ep_agent_bfm/pcie_phy_ep_agent_bfm.sv
../../pcie_phy_vip/src/hdl_top/ep_agent_bfm/pcie_phy_ep_driver_bfm.sv
../../pcie_phy_vip/src/hdl_top/ep_agent_bfm/pcie_phy_ep_monitor_bfm.sv

// ---- Top-Level Module ----

// ---- Config 7-specific package + top ----
../src/pcie_full_stack_config7_top.sv
