// ============================================================================
// PCIe PHY VIP - Compile File
// ============================================================================

-sv

// Include Directories
+incdir+../src/globals/
+incdir+../src/hdl_top/pcie_phy_interface/
+incdir+../src/hdl_top/rc_agent_bfm/
+incdir+../src/hdl_top/ep_agent_bfm/
+incdir+../src/hvl_top/rc/
+incdir+../src/hvl_top/ep/
+incdir+../src/hvl_top/env/
+incdir+../src/hvl_top/test/

// Global Package
../src/globals/pcie_phy_globals_pkg.sv

// HVL Packages
../src/hvl_top/rc/pcie_phy_rc_pkg.sv
../src/hvl_top/ep/pcie_phy_ep_pkg.sv
../src/hvl_top/env/pcie_phy_env_pkg.sv

// Tests
../src/hvl_top/test/pcie_phy_test_pkg.sv

// Interface
../src/hdl_top/pcie_phy_interface/pcie_phy_if.sv

// RC Agent BFMs (HDL)
../src/hdl_top/rc_agent_bfm/pcie_phy_rc_agent_bfm.sv
../src/hdl_top/rc_agent_bfm/pcie_phy_rc_driver_bfm.sv
../src/hdl_top/rc_agent_bfm/pcie_phy_rc_monitor_bfm.sv

// EP Agent BFMs (HDL)
../src/hdl_top/ep_agent_bfm/pcie_phy_ep_agent_bfm.sv
../src/hdl_top/ep_agent_bfm/pcie_phy_ep_driver_bfm.sv
../src/hdl_top/ep_agent_bfm/pcie_phy_ep_monitor_bfm.sv

// Top-Level Modules
../src/hdl_top/pcie_phy_hdl_top.sv
../src/hvl_top/pcie_phy_hvl_top.sv
