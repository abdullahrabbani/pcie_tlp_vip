# pcie_phy_vip

Physical Layer VIP, built in the same hdl_top/hvl_top + BFM-interface
architecture, with a real LTSSM training state machine (not a static
link-up bit).

## What's real here

- **Actual training progression**: `LTSSM_DETECT` → `LTSSM_POLLING`
  (TS1 exchange) → `LTSSM_CONFIGURATION` (TS2 exchange, negotiates
  width/speed) → `LTSSM_L0` (link up), driven by `run_ltssm()` in both
  the RC and EP driver BFMs.
- **Real negotiation, not just agreement by construction**: the base
  test deliberately mismatches advertised parameters (RC: x8/Gen5, EP:
  x4/Gen3) and checks that both sides converge on the narrower/slower
  common configuration (x4/Gen3).
- **A scoreboard that actually checks something**: `pcie_phy_scoreboard`
  verifies every observed ordered-set transition is legal (TS1 can
  repeat or advance to TS2; TS2 can only repeat; nothing skips a
  phase) - independent of the driver's own internal state variable.

## Design choice: one training algorithm, not two

Real PCIe link training is **symmetric** between link partners - there
is no RC-specific vs EP-specific algorithm. `pcie_phy_rc_driver_bfm`
and `pcie_phy_ep_driver_bfm` run identical logic; they're duplicated
(not shared via one module instantiated twice) only to match this
skeleton's per-side-folder convention. If you're extending this VIP,
that duplication is the thing to collapse first if it starts drifting.

## A specific timing fix worth knowing about

The BFM's `run_ltssm()` is **not** auto-started from the agent BFM's
`initial` block. If it were, it would race against `build_phase`
(which sets `advertised_width`/`advertised_gen` from the agent config)
with no guaranteed ordering at time 0 - a classic plain-SV-vs-UVM-phase
race. Instead, `pcie_phy_rc_driver_proxy`/`pcie_phy_ep_driver_proxy`
call `bfm.run_ltssm()` from their own `run_phase`, which UVM guarantees
runs after `build_phase` has completed.

## What's honestly NOT modeled

- Real electrical/bit-level detail - `rx_detect`, ordered sets, and
  lane lock are abstracted booleans/enums, not receiver-detect
  circuits or actual 8b/10b/128b/130b/PAM4 symbol streams.
- Sub-states within Polling/Configuration that exist specifically to
  negotiate the electrical detail this model doesn't simulate.
- `RECOVERY`, power states (`L0S`/`L1`/`L2`), `LOOPBACK`, `HOT_RESET` -
  defined in the enum for completeness, no transition logic drives
  them; the BFM only ever moves forward through the training path and
  holds at L0.
- Per-lane negotiation - width negotiation here is a single scalar
  `min()` of two advertised widths.
