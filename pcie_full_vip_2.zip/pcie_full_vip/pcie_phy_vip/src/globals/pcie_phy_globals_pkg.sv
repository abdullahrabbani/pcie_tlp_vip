// PCIe PHY VIP - Global Package
`ifndef PCIE_PHY_GLOBALS_PKG_SVH
`define PCIE_PHY_GLOBALS_PKG_SVH

package pcie_phy_globals_pkg;

    // Core LTSSM states. Real PCIe has sub-states within Polling/
    // Configuration that exist to negotiate electrical/bit-level
    // detail this model doesn't simulate - collapsed to one state per
    // major training phase.
    typedef enum logic [3:0] {
        LTSSM_DETECT,
        LTSSM_POLLING,
        LTSSM_CONFIGURATION,
        LTSSM_L0,
        LTSSM_RECOVERY,
        LTSSM_DISABLED,
        LTSSM_LOOPBACK,
        LTSSM_HOT_RESET,
        LTSSM_L0S,
        LTSSM_L1,
        LTSSM_L2
    } ltssm_state_e;

    // Ordered sets exchanged during training - modeled abstractly as
    // "an ordered set of this kind is present this cycle", not as
    // real 8b/10b or 128b/130b symbol sequences.
    typedef enum logic [2:0] {
        OS_TS1,
        OS_TS2,
        OS_FTS,
        OS_SKP,
        OS_EIOS,
        OS_EIEOS
    } ordered_set_e;

    typedef enum logic [4:0] {
        LANE_X1  = 5'd1,
        LANE_X2  = 5'd2,
        LANE_X4  = 5'd4,
        LANE_X8  = 5'd8,
        LANE_X16 = 5'd16
    } lane_width_e;

    typedef enum logic [2:0] {
        GEN1, GEN2, GEN3, GEN4, GEN5, GEN6, GEN7
    } pcie_gen_e;

    parameter int PHY_POLLING_CYCLES = 20;
    parameter int PHY_CONFIG_CYCLES  = 20;

endpackage

`endif
