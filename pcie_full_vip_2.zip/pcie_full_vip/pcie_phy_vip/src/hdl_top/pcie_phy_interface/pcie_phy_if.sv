// PCIe PHY Interface
`ifndef PCIE_PHY_IF_SVH
`define PCIE_PHY_IF_SVH

import pcie_phy_globals_pkg::*;

interface pcie_phy_if (
    input logic clk,
    input logic rst_n
);

    // RC's outgoing ordered sets, as observed by EP
    logic         rc_os_valid;
    ordered_set_e rc_os_kind;
    lane_width_e  rc_os_lane_width;
    pcie_gen_e    rc_os_gen;
    logic         rc_rx_detect;
    logic         rc_trained;

    // EP's outgoing ordered sets, as observed by RC
    logic         ep_os_valid;
    ordered_set_e ep_os_kind;
    lane_width_e  ep_os_lane_width;
    pcie_gen_e    ep_os_gen;
    logic         ep_rx_detect;
    logic         ep_trained;

    // link_up: true once BOTH sides have independently trained to L0
    logic link_up;
    assign link_up = rc_trained && ep_trained;

endinterface : pcie_phy_if

`endif
