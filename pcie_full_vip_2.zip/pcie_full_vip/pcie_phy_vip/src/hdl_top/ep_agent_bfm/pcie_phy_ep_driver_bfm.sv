// EP PHY Driver BFM
`ifndef PCIE_PHY_EP_DRIVER_BFM_SVH
`define PCIE_PHY_EP_DRIVER_BFM_SVH

import pcie_phy_globals_pkg::*;
import uvm_pkg::*;
`include "uvm_macros.svh"

// Identical LTSSM logic to pcie_phy_rc_driver_bfm - real PCIe link
// training is symmetric between link partners, there is no
// RC-specific vs EP-specific training algorithm. Duplicated here
// (rather than shared) to match this skeleton's per-side-BFM folder
// convention; see pcie_phy_vip/README.md for the design note.
interface pcie_phy_ep_driver_bfm (
    input  logic clk,
    input  logic rst_n,
    output logic         os_valid,
    output ordered_set_e os_kind,
    output lane_width_e  os_lane_width,
    output pcie_gen_e    os_gen,
    output logic         rx_detect,
    output logic         trained,
    input  logic         peer_os_valid,
    input  ordered_set_e peer_os_kind,
    input  lane_width_e  peer_os_lane_width,
    input  pcie_gen_e    peer_os_gen
);

    string name = "PCIE_PHY_EP_DRIVER_BFM";
    ltssm_state_e state = LTSSM_DETECT;
    lane_width_e  negotiated_width;
    pcie_gen_e    negotiated_gen;

    initial `uvm_info(name, $sformatf("%s instantiated", name), UVM_LOW)

    function bit is_link_up(); return (state == LTSSM_L0); endfunction
    function lane_width_e get_negotiated_width(); return negotiated_width; endfunction
    function pcie_gen_e   get_negotiated_gen();    return negotiated_gen;   endfunction

    lane_width_e advertised_width = LANE_X4;
    pcie_gen_e   advertised_gen   = GEN5;

    task run_ltssm();
        int unsigned cycle_in_state = 0;
        os_valid  <= 1'b0;
        rx_detect <= 1'b1;
        trained   <= 1'b0;

        forever begin
            @(posedge clk);
            trained <= (state == LTSSM_L0);
            case (state)
                LTSSM_DETECT: begin
                    if (peer_os_valid || 1'b1) begin
                        change_state(LTSSM_POLLING);
                        cycle_in_state = 0;
                    end
                end

                LTSSM_POLLING: begin
                    os_valid      <= 1'b1;
                    os_kind        <= OS_TS1;
                    os_lane_width   <= advertised_width;
                    os_gen           <= advertised_gen;
                    cycle_in_state++;
                    if (cycle_in_state >= PHY_POLLING_CYCLES &&
                        peer_os_valid && peer_os_kind inside {OS_TS1, OS_TS2}) begin
                        change_state(LTSSM_CONFIGURATION);
                        cycle_in_state = 0;
                    end
                end

                LTSSM_CONFIGURATION: begin
                    negotiated_width = (advertised_width < peer_os_lane_width) ? advertised_width : peer_os_lane_width;
                    negotiated_gen   = (advertised_gen < peer_os_gen)          ? advertised_gen    : peer_os_gen;
                    os_valid      <= 1'b1;
                    os_kind        <= OS_TS2;
                    os_lane_width   <= negotiated_width;
                    os_gen           <= negotiated_gen;
                    cycle_in_state++;
                    if (cycle_in_state >= PHY_CONFIG_CYCLES &&
                        peer_os_valid && peer_os_kind == OS_TS2) begin
                        change_state(LTSSM_L0);
                        cycle_in_state = 0;
                    end
                end

                LTSSM_L0: begin
                    os_valid <= 1'b0;
                end

                default: change_state(LTSSM_DETECT);
            endcase
        end
    endtask

    function void change_state(ltssm_state_e new_state);
        `uvm_info(name, $sformatf("LTSSM: %s -> %s", state.name(), new_state.name()), UVM_LOW)
        state = new_state;
    endfunction

endinterface : pcie_phy_ep_driver_bfm

`endif
