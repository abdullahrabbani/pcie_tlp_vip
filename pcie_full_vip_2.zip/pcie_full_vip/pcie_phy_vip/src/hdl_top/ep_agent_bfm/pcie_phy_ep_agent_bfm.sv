// EP PHY Agent BFM
`ifndef PCIE_PHY_EP_AGENT_BFM_SVH
`define PCIE_PHY_EP_AGENT_BFM_SVH

import uvm_pkg::*;
`include "uvm_macros.svh"
import pcie_phy_globals_pkg::*;

module pcie_phy_ep_agent_bfm #(parameter int EP_ID = 0)(
    pcie_phy_if intf
);

    pcie_phy_ep_driver_bfm ep_drv_bfm (
        .clk(intf.clk), .rst_n(intf.rst_n),
        .os_valid(intf.ep_os_valid), .os_kind(intf.ep_os_kind),
        .os_lane_width(intf.ep_os_lane_width), .os_gen(intf.ep_os_gen),
        .rx_detect(intf.ep_rx_detect), .trained(intf.ep_trained),
        .peer_os_valid(intf.rc_os_valid), .peer_os_kind(intf.rc_os_kind),
        .peer_os_lane_width(intf.rc_os_lane_width), .peer_os_gen(intf.rc_os_gen)
    );

    pcie_phy_ep_monitor_bfm ep_mon_bfm (
        .clk(intf.clk), .rst_n(intf.rst_n),
        .os_valid(intf.ep_os_valid), .os_kind(intf.ep_os_kind),
        .os_lane_width(intf.ep_os_lane_width), .os_gen(intf.ep_os_gen),
        .trained(intf.ep_trained)
    );

    initial begin
        uvm_config_db#(virtual pcie_phy_ep_driver_bfm)::set(null, "*", "pcie_phy_ep_driver_bfm", ep_drv_bfm);
        uvm_config_db#(virtual pcie_phy_ep_monitor_bfm)::set(null, "*", "pcie_phy_ep_monitor_bfm", ep_mon_bfm);
        `uvm_info("PCIE_PHY_EP_AGENT_BFM", $sformatf("EP PHY Agent BFM instantiated with ID %0d", EP_ID), UVM_LOW)
        // run_ltssm() started by pcie_phy_ep_driver_proxy in run_phase - see rc_agent_bfm's note.
    end

endmodule : pcie_phy_ep_agent_bfm

`endif
