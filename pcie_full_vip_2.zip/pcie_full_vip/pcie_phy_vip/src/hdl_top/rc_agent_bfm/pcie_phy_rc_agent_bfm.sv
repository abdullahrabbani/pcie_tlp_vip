// RC PHY Agent BFM
`ifndef PCIE_PHY_RC_AGENT_BFM_SVH
`define PCIE_PHY_RC_AGENT_BFM_SVH

import uvm_pkg::*;
`include "uvm_macros.svh"
import pcie_phy_globals_pkg::*;

module pcie_phy_rc_agent_bfm #(parameter int RC_ID = 0)(
    pcie_phy_if intf
);

    pcie_phy_rc_driver_bfm rc_drv_bfm (
        .clk(intf.clk), .rst_n(intf.rst_n),
        .os_valid(intf.rc_os_valid), .os_kind(intf.rc_os_kind),
        .os_lane_width(intf.rc_os_lane_width), .os_gen(intf.rc_os_gen),
        .rx_detect(intf.rc_rx_detect), .trained(intf.rc_trained),
        .peer_os_valid(intf.ep_os_valid), .peer_os_kind(intf.ep_os_kind),
        .peer_os_lane_width(intf.ep_os_lane_width), .peer_os_gen(intf.ep_os_gen)
    );

    pcie_phy_rc_monitor_bfm rc_mon_bfm (
        .clk(intf.clk), .rst_n(intf.rst_n),
        .os_valid(intf.rc_os_valid), .os_kind(intf.rc_os_kind),
        .os_lane_width(intf.rc_os_lane_width), .os_gen(intf.rc_os_gen),
        .trained(intf.rc_trained)
    );

    initial begin
        uvm_config_db#(virtual pcie_phy_rc_driver_bfm)::set(null, "*", "pcie_phy_rc_driver_bfm", rc_drv_bfm);
        uvm_config_db#(virtual pcie_phy_rc_monitor_bfm)::set(null, "*", "pcie_phy_rc_monitor_bfm", rc_mon_bfm);
        `uvm_info("PCIE_PHY_RC_AGENT_BFM", $sformatf("RC PHY Agent BFM instantiated with ID %0d", RC_ID), UVM_LOW)
        // run_ltssm() is deliberately NOT started here: it's kicked
        // off by pcie_phy_rc_driver_proxy in its run_phase, AFTER
        // build_phase has set bfm.advertised_width/advertised_gen
        // from the agent config. Starting it here in a plain initial
        // block would race against UVM's config_db-driven setup with
        // no guaranteed ordering at time 0.
    end

endmodule : pcie_phy_rc_agent_bfm

`endif
