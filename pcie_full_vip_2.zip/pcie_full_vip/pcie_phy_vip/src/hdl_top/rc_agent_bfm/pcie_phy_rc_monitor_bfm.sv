// RC PHY Monitor BFM
`ifndef PCIE_PHY_RC_MONITOR_BFM_SVH
`define PCIE_PHY_RC_MONITOR_BFM_SVH

import pcie_phy_globals_pkg::*;
import uvm_pkg::*;
`include "uvm_macros.svh"

interface pcie_phy_rc_monitor_bfm (
    input logic clk,
    input logic rst_n,
    input logic         os_valid,
    input ordered_set_e os_kind,
    input lane_width_e  os_lane_width,
    input pcie_gen_e    os_gen,
    input logic         trained
);

    string name = "PCIE_PHY_RC_MONITOR_BFM";
    initial `uvm_info(name, $sformatf("%s instantiated", name), UVM_LOW)

    // Blocks until os_kind CHANGES (or first observation), returning
    // the new kind + negotiated width/gen at that moment - one call
    // per distinct training phase transition, not one per clock.
    task automatic sample_transition(output ordered_set_e kind, output lane_width_e width, output pcie_gen_e gen);
        ordered_set_e last_kind;
        bit seen_any = 1'b0;
        forever begin
            @(posedge clk);
            if (os_valid && (!seen_any || os_kind != last_kind)) begin
                kind = os_kind; width = os_lane_width; gen = os_gen;
                last_kind = os_kind; seen_any = 1'b1;
                return;
            end
        end
    endtask

endinterface : pcie_phy_rc_monitor_bfm

`endif
