// PHY HVL Top module
`ifndef PCIE_PHY_HVL_TOP_SVH
`define PCIE_PHY_HVL_TOP_SVH

module pcie_phy_hvl_top;

    import uvm_pkg::*;
    `include "uvm_macros.svh"
    import pcie_phy_globals_pkg::*;
    import pcie_phy_test_pkg::*;

    logic clk;
    logic rst_n;
    pcie_phy_if if0 (.clk(clk), .rst_n(rst_n));

    initial begin
        clk = 1'b0;
        forever #5 clk = ~clk;
    end

    initial begin
        rst_n = 1'b0;
        #20;
        rst_n = 1'b1;
        `uvm_info("HVL_TOP", "Reset deasserted", UVM_LOW)
    end

    initial begin
        uvm_config_db#(virtual pcie_phy_if)::set(null, "*", "pcie_phy_if", if0);
    end

    initial begin : START_TEST
        run_test("pcie_phy_base_test");
    end

endmodule : pcie_phy_hvl_top

`endif
