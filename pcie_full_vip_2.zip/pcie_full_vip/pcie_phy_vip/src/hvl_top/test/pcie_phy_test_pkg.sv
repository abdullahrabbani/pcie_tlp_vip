// PHY Test Package
`ifndef PCIE_PHY_TEST_PKG_SVH
`define PCIE_PHY_TEST_PKG_SVH

package pcie_phy_test_pkg;
    `include "uvm_macros.svh"
    import uvm_pkg::*;
    import pcie_phy_globals_pkg::*;
    import pcie_phy_rc_pkg::*;
    import pcie_phy_ep_pkg::*;
    import pcie_phy_env_pkg::*;

    `include "pcie_phy_base_test.sv"
endpackage

`endif
