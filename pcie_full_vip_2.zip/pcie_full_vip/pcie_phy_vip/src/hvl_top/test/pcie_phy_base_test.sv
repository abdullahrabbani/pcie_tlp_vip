// PHY Base Test
`ifndef PCIE_PHY_BASE_TEST_SVH
`define PCIE_PHY_BASE_TEST_SVH

class pcie_phy_base_test extends uvm_test;
    `uvm_component_utils(pcie_phy_base_test)
    pcie_phy_env        env;
    pcie_phy_env_config  env_cfg;

    function new(string name = "pcie_phy_base_test", uvm_component parent = null);
        super.new(name, parent);
    endfunction

    function void build_phase(uvm_phase phase);
        super.build_phase(phase);
        env_cfg = pcie_phy_env_config::type_id::create("env_cfg");
        env_cfg.rc_cfg = pcie_phy_rc_agent_config::type_id::create("rc_cfg");
        env_cfg.ep_cfg = pcie_phy_ep_agent_config::type_id::create("ep_cfg");
        env_cfg.rc_cfg.is_active = UVM_ACTIVE;
        env_cfg.ep_cfg.is_active = UVM_ACTIVE;
        // Deliberately mismatched: RC advertises x8/Gen5, EP advertises
        // x4/Gen3 - proves negotiation converges on the narrower/slower
        // common configuration rather than just reflecting one side.
        env_cfg.rc_cfg.advertised_width = LANE_X8;
        env_cfg.rc_cfg.advertised_gen   = GEN5;
        env_cfg.ep_cfg.advertised_width = LANE_X4;
        env_cfg.ep_cfg.advertised_gen   = GEN3;
        uvm_config_db#(pcie_phy_env_config)::set(this, "env", "cfg", env_cfg);
        env = pcie_phy_env::type_id::create("env", this);
    endfunction

    task run_phase(uvm_phase phase);
        phase.raise_objection(this);
        #2000;  // long enough for Detect -> Polling -> Configuration -> L0 on both sides
        if (env.rc_agent.driver.is_link_up() && env.ep_agent.driver.is_link_up()) begin
            `uvm_info(get_type_name(), $sformatf(
                "Link UP: negotiated width=%0d gen=%s",
                env.rc_agent.driver.get_negotiated_width(),
                env.rc_agent.driver.get_negotiated_gen().name()), UVM_NONE)
        end else begin
            `uvm_error(get_type_name(), $sformatf("Link FAILED to train: rc=%0b ep=%0b",
                        env.rc_agent.driver.is_link_up(), env.ep_agent.driver.is_link_up()))
        end
        phase.drop_objection(this);
    endtask

endclass

`endif
