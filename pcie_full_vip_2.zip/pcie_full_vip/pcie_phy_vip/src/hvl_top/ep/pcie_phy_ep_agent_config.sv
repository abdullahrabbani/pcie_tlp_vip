// EP PHY Agent Configuration
`ifndef PCIE_PHY_EP_AGENT_CONFIG_SVH
`define PCIE_PHY_EP_AGENT_CONFIG_SVH

import uvm_pkg::*; `include "uvm_macros.svh"

class pcie_phy_ep_agent_config extends uvm_object;
    `uvm_object_utils(pcie_phy_ep_agent_config)
    uvm_active_passive_enum is_active = UVM_ACTIVE;
    bit has_coverage = 1'b0;
    lane_width_e advertised_width = LANE_X4;
    pcie_gen_e   advertised_gen   = GEN5;

    function new(string name = "pcie_phy_ep_agent_config");
        super.new(name);
    endfunction
endclass

`endif
