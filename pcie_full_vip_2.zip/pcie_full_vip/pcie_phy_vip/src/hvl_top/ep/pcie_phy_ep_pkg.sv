// EP PHY Agent Package
`ifndef PCIE_PHY_EP_PKG_SVH
`define PCIE_PHY_EP_PKG_SVH

package pcie_phy_ep_pkg;
    `include "uvm_macros.svh"
    import uvm_pkg::*;
    import pcie_phy_globals_pkg::*;
    import pcie_phy_rc_pkg::*;   // reuses pcie_phy_transition as the common event shape

    `include "pcie_phy_ep_agent_config.sv"
    `include "pcie_phy_ep_driver_proxy.sv"
    `include "pcie_phy_ep_monitor_proxy.sv"
    `include "pcie_phy_ep_agent.sv"
endpackage

`endif
