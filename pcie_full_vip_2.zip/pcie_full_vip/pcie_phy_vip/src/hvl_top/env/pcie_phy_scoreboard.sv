// PHY Scoreboard
`ifndef PCIE_PHY_SCOREBOARD_SVH
`define PCIE_PHY_SCOREBOARD_SVH

`uvm_analysis_imp_decl(_rc)
`uvm_analysis_imp_decl(_ep)

class pcie_phy_scoreboard extends uvm_scoreboard;
    `uvm_component_utils(pcie_phy_scoreboard)

    uvm_analysis_imp_rc #(pcie_phy_transition, pcie_phy_scoreboard) rc_imp;
    uvm_analysis_imp_ep #(pcie_phy_transition, pcie_phy_scoreboard) ep_imp;

    bit           rc_have_last, ep_have_last;
    ordered_set_e rc_last_kind, ep_last_kind;
    int unsigned  rc_violations, ep_violations;
    int unsigned  transitions_seen;

    function new(string name = "pcie_phy_scoreboard", uvm_component parent = null);
        super.new(name, parent);
        rc_imp = new("rc_imp", this);
        ep_imp = new("ep_imp", this);
    endfunction

    // The only forward-legal moves this VIP's BFM actually produces:
    // TS1 (Polling) -> TS1 or TS2 (Configuration) -> TS2 or nothing
    // further (L0, where os_valid drops and no more ordered sets are
    // observed at all).
    function bit legal(ordered_set_e from_k, ordered_set_e to_k);
        case (from_k)
            OS_TS1: return to_k inside {OS_TS1, OS_TS2};
            OS_TS2: return to_k == OS_TS2;
            default: return 1'b1;
        endcase
    endfunction

    function void write_rc(pcie_phy_transition tr);
        transitions_seen++;
        if (rc_have_last && !legal(rc_last_kind, tr.kind)) begin
            rc_violations++;
            `uvm_error(get_type_name(), $sformatf("RC illegal ordered-set transition: %s -> %s", rc_last_kind.name(), tr.kind.name()))
        end
        rc_last_kind = tr.kind; rc_have_last = 1'b1;
    endfunction

    function void write_ep(pcie_phy_transition tr);
        transitions_seen++;
        if (ep_have_last && !legal(ep_last_kind, tr.kind)) begin
            ep_violations++;
            `uvm_error(get_type_name(), $sformatf("EP illegal ordered-set transition: %s -> %s", ep_last_kind.name(), tr.kind.name()))
        end
        ep_last_kind = tr.kind; ep_have_last = 1'b1;
    endfunction

    function void report_phase(uvm_phase phase);
        `uvm_info(get_type_name(), $sformatf(
            "Summary: transitions_seen=%0d rc_violations=%0d ep_violations=%0d",
            transitions_seen, rc_violations, ep_violations), UVM_NONE)
    endfunction

endclass

`endif
