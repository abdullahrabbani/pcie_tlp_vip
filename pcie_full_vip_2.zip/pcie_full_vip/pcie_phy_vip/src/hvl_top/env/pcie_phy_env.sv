// PHY Environment
`ifndef PCIE_PHY_ENV_SVH
`define PCIE_PHY_ENV_SVH

class pcie_phy_env extends uvm_env;
    `uvm_component_utils(pcie_phy_env)
    pcie_phy_env_config cfg;
    pcie_phy_rc_agent   rc_agent;
    pcie_phy_ep_agent   ep_agent;
    pcie_phy_scoreboard sb;

    function new(string name = "pcie_phy_env", uvm_component parent = null);
        super.new(name, parent);
    endfunction

    function void build_phase(uvm_phase phase);
        super.build_phase(phase);
        if (!uvm_config_db#(pcie_phy_env_config)::get(this, "", "cfg", cfg))
            `uvm_fatal(get_type_name(), "No env config found")
        uvm_config_db#(pcie_phy_rc_agent_config)::set(this, "rc_agent", "cfg", cfg.rc_cfg);
        uvm_config_db#(pcie_phy_ep_agent_config)::set(this, "ep_agent", "cfg", cfg.ep_cfg);
        rc_agent = pcie_phy_rc_agent::type_id::create("rc_agent", this);
        ep_agent = pcie_phy_ep_agent::type_id::create("ep_agent", this);
        if (cfg.has_scoreboard)
            sb = pcie_phy_scoreboard::type_id::create("sb", this);
    endfunction

    function void connect_phase(uvm_phase phase);
        super.connect_phase(phase);
        if (cfg.has_scoreboard) begin
            rc_agent.monitor.ap.connect(sb.rc_imp);
            ep_agent.monitor.ap.connect(sb.ep_imp);
        end
    endfunction

endclass

`endif
