// RC PHY Driver Proxy
`ifndef PCIE_PHY_RC_DRIVER_PROXY_SVH
`define PCIE_PHY_RC_DRIVER_PROXY_SVH

// No sequencer, no sequence item - real link training is autonomous,
// not sequence-item-driven the way TLP stimulus is. This proxy exists
// only to bridge UVM configuration (agent_config) into the BFM before
// kicking off run_ltssm(), and to expose is_link_up()/negotiated
// width/gen to the rest of the UVM world.
class pcie_phy_rc_driver_proxy extends uvm_component;
    `uvm_component_utils(pcie_phy_rc_driver_proxy)
    virtual pcie_phy_rc_driver_bfm bfm;
    pcie_phy_rc_agent_config cfg;

    function new(string name = "pcie_phy_rc_driver_proxy", uvm_component parent = null);
        super.new(name, parent);
    endfunction

    function void build_phase(uvm_phase phase);
        super.build_phase(phase);
        if (!uvm_config_db#(virtual pcie_phy_rc_driver_bfm)::get(this, "", "pcie_phy_rc_driver_bfm", bfm))
            `uvm_fatal(get_type_name(), "Failed to get BFM handle")
    endfunction

    function bit is_link_up();
        return bfm.is_link_up();
    endfunction

    function lane_width_e get_negotiated_width();
        return bfm.get_negotiated_width();
    endfunction

    function pcie_gen_e get_negotiated_gen();
        return bfm.get_negotiated_gen();
    endfunction

    task run_phase(uvm_phase phase);
        super.run_phase(phase);
        bfm.advertised_width = cfg.advertised_width;
        bfm.advertised_gen   = cfg.advertised_gen;
        `uvm_info(get_type_name(), $sformatf(
            "Starting LTSSM training: advertised x%0d/%s", cfg.advertised_width, cfg.advertised_gen.name()), UVM_LOW)
        bfm.run_ltssm();
    endtask

endclass

`endif
