// RC PHY Agent Package
`ifndef PCIE_PHY_RC_PKG_SVH
`define PCIE_PHY_RC_PKG_SVH

package pcie_phy_rc_pkg;
    `include "uvm_macros.svh"
    import uvm_pkg::*;
    import pcie_phy_globals_pkg::*;

    `include "pcie_phy_rc_agent_config.sv"
    `include "pcie_phy_rc_driver_proxy.sv"
    `include "pcie_phy_rc_monitor_proxy.sv"
    `include "pcie_phy_rc_agent.sv"
endpackage

`endif
