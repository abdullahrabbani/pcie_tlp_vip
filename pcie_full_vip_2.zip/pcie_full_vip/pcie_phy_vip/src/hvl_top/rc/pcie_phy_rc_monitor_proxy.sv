// RC PHY Monitor Proxy
`ifndef PCIE_PHY_RC_MONITOR_PROXY_SVH
`define PCIE_PHY_RC_MONITOR_PROXY_SVH

class pcie_phy_transition extends uvm_object;
    `uvm_object_utils(pcie_phy_transition)
    ordered_set_e kind;
    lane_width_e  width;
    pcie_gen_e    gen;

    function new(string name = "pcie_phy_transition");
        super.new(name);
    endfunction
endclass

class pcie_phy_rc_monitor_proxy extends uvm_monitor;
    `uvm_component_utils(pcie_phy_rc_monitor_proxy)
    virtual pcie_phy_rc_monitor_bfm bfm;
    pcie_phy_rc_agent_config cfg;
    uvm_analysis_port #(pcie_phy_transition) ap;

    function new(string name = "pcie_phy_rc_monitor_proxy", uvm_component parent = null);
        super.new(name, parent);
        ap = new("ap", this);
    endfunction

    function void build_phase(uvm_phase phase);
        super.build_phase(phase);
        if (!uvm_config_db#(virtual pcie_phy_rc_monitor_bfm)::get(this, "", "pcie_phy_rc_monitor_bfm", bfm))
            `uvm_fatal(get_type_name(), "Failed to get BFM handle")
    endfunction

    task run_phase(uvm_phase phase);
        ordered_set_e kind; lane_width_e width; pcie_gen_e gen;
        forever begin
            bfm.sample_transition(kind, width, gen);
            begin
                pcie_phy_transition tr = pcie_phy_transition::type_id::create("tr");
                tr.kind = kind; tr.width = width; tr.gen = gen;
                ap.write(tr);
            end
        end
    endtask

endclass

`endif
