// RC PHY Agent
`ifndef PCIE_PHY_RC_AGENT_SVH
`define PCIE_PHY_RC_AGENT_SVH

class pcie_phy_rc_agent extends uvm_agent;
    `uvm_component_utils(pcie_phy_rc_agent)

    pcie_phy_rc_agent_config cfg;
    pcie_phy_rc_driver_proxy  driver;
    pcie_phy_rc_monitor_proxy monitor;

    function new(string name = "pcie_phy_rc_agent", uvm_component parent = null);
        super.new(name, parent);
    endfunction

    function void build_phase(uvm_phase phase);
        super.build_phase(phase);
        if (!uvm_config_db#(pcie_phy_rc_agent_config)::get(this, "", "cfg", cfg))
            `uvm_fatal(get_type_name(), "No configuration object found")
        monitor = pcie_phy_rc_monitor_proxy::type_id::create("monitor", this);
        if (cfg.is_active == UVM_ACTIVE)
            driver = pcie_phy_rc_driver_proxy::type_id::create("driver", this);
    endfunction

    function void connect_phase(uvm_phase phase);
        super.connect_phase(phase);
        monitor.cfg = cfg;
        if (cfg.is_active == UVM_ACTIVE) driver.cfg = cfg;
    endfunction

endclass

`endif
