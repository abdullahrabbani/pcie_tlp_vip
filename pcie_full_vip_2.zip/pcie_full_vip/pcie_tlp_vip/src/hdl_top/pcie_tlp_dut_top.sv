// pcie_tlp_vip: DUT Integration Top (RC VIP <-> EP DUT)
//
// Native to pcie_tlp_vip - doesn't require pcie_full_stack_vip.
// RC side is the normal active VIP. EP side has NO driver at all: the
// DUT drives those wires directly. pcie_tlp_ep_agent still builds its
// monitor unconditionally (confirmed in pcie_tlp_ep_agent.sv - monitor
// creation isn't gated by is_active), so it keeps observing real DUT
// traffic for coverage/scoreboarding even in passive mode - that's
// the whole reason Active/Passive was built the way it was.
`ifndef PCIE_TLP_DUT_TOP_SVH
`define PCIE_TLP_DUT_TOP_SVH

//=============================================================================
// EP DUT stub - plain SV, no UVM. Speaks pcie_tlp_if's real burst
// protocol: samples a 2-beat header plus however many payload beats
// dw0[9:0] declares, replies to Mem/Cfg Read with a completion burst.
// (Same design as pcie_full_stack_vip's ep_dut_stub_burst, made
// native here so this VIP doesn't need that project as a dependency.)
//=============================================================================
module pcie_tlp_ep_dut_stub (
    input  logic         clk,
    input  logic         rst_n,
    input  logic [63:0]  tx_data,
    input  logic         tx_valid,
    output logic         tx_ready,
    input  logic         tx_sop,
    input  logic         tx_eop,
    input  logic [3:0]   tx_seq_num,
    output logic [63:0]  rx_data,
    output logic         rx_valid,
    input  logic         rx_ready,
    output logic         rx_sop,
    output logic         rx_eop,
    output logic [3:0]   rx_seq_num
);
    import pcie_tlp_globals_pkg::*;

    logic [31:0] dw0, dw1, dw2, dw3;
    tlp_fmt_e    fmt;
    logic [3:0]  seq_num;
    logic [31:0] read_data = 32'hDEAD_BEEF;

    initial begin
        tx_ready <= 1'b1;
        rx_valid <= 1'b0;
    end

    always @(posedge clk) begin
        if (!rst_n) begin
            tx_ready <= 1'b1;
            rx_valid <= 1'b0;
        end
    end

    initial begin
        forever begin
            @(posedge clk);
            if (tx_valid && tx_ready && tx_sop) begin
                dw0 = tx_data[31:0];
                dw1 = tx_data[63:32];
                @(posedge clk);
                dw2 = tx_data[31:0];
                dw3 = tx_data[63:32];
                seq_num = tx_seq_num;
                fmt = tlp_fmt_e'(dw0[30:28]);

                while (!tx_eop) @(posedge clk);

                if (fmt inside {TLP_FMT_MEM_READ, TLP_FMT_CFG_READ}) begin
                    send_completion_burst(seq_num);
                end
                // MEM_WRITE/CFG_WRITE: posted vs. non-posted is a
                // TLP-layer distinction this minimal stub doesn't
                // model - it just doesn't reply, correct for the
                // posted MEM_WRITE case in the default traffic mix.
            end
        end
    end

    task automatic send_completion_burst(logic [3:0] seq_num_i);
        logic [31:0] cmpl_dw0;
        cmpl_dw0        = 32'h0;
        cmpl_dw0[30:28] = 3'b000;
        cmpl_dw0[24:19] = 6'b001010;   // Type = TLP_TYPE_CMPL
        cmpl_dw0[9:0]   = 10'd1;       // Length = 1 DW

        @(posedge clk);
        rx_data    <= {32'h0, cmpl_dw0};
        rx_valid   <= 1'b1;
        rx_sop     <= 1'b1;
        rx_eop     <= 1'b0;
        rx_seq_num <= seq_num_i;
        do @(posedge clk); while (!(rx_valid && rx_ready));

        @(posedge clk);
        rx_data  <= 64'h0;
        rx_valid <= 1'b1;
        rx_sop   <= 1'b0;
        rx_eop   <= 1'b0;
        do @(posedge clk); while (!(rx_valid && rx_ready));

        @(posedge clk);
        rx_data  <= {32'h0, read_data};
        rx_valid <= 1'b1;
        rx_sop   <= 1'b0;
        rx_eop   <= 1'b1;
        do @(posedge clk); while (!(rx_valid && rx_ready));

        @(posedge clk);
        rx_valid <= 1'b0;
    endtask

endmodule : pcie_tlp_ep_dut_stub

module pcie_tlp_dut_top;
    import uvm_pkg::*;
    `include "uvm_macros.svh"
    import pcie_tlp_globals_pkg::*;
    import pcie_tlp_test_pkg::*;

    bit clk = 0;
    always #5 clk = ~clk;

    bit rst_n = 1;
    initial begin
        #10 rst_n = 0;
        repeat (2) @(posedge clk);
        rst_n = 1;
        `uvm_info("DUT_TOP", "Reset deasserted", UVM_LOW)
    end

    pcie_tlp_if intf (.clk(clk), .rst_n(rst_n));

    // RC side: the real, active VIP driver+monitor.
    pcie_tlp_rc_agent_bfm #(.RC_ID(0)) rc_bfm (intf);

    // EP side: only the monitor BFM - no driver_bfm, since the DUT
    // drives those wires directly. Instantiated standalone (bypassing
    // pcie_tlp_ep_agent_bfm, which would also pull in an unused
    // driver_bfm) so there's exactly one thing driving each signal.
    pcie_tlp_ep_monitor_bfm ep_mon_bfm (
        .clk(intf.clk), .rst_n(intf.rst_n),
        .tx_data(intf.tx_data), .tx_keep(intf.tx_keep), .tx_valid(intf.tx_valid), .tx_ready(intf.tx_ready),
        .tx_sop(intf.tx_sop), .tx_eop(intf.tx_eop), .tx_empty(intf.tx_empty),
        .tx_seq_num(intf.tx_seq_num), .tx_vc_id(intf.tx_vc_id), .tx_tc(intf.tx_tc),
        .rx_data(intf.rx_data), .rx_keep(intf.rx_keep), .rx_valid(intf.rx_valid), .rx_ready(intf.rx_ready),
        .rx_sop(intf.rx_sop), .rx_eop(intf.rx_eop), .rx_empty(intf.rx_empty),
        .rx_seq_num(intf.rx_seq_num), .rx_vc_id(intf.rx_vc_id), .rx_tc(intf.rx_tc)
    );

    pcie_tlp_ep_dut_stub dut (
        .clk(clk), .rst_n(rst_n),
        .tx_data(intf.tx_data), .tx_valid(intf.tx_valid), .tx_ready(intf.tx_ready),
        .tx_sop(intf.tx_sop), .tx_eop(intf.tx_eop), .tx_seq_num(intf.tx_seq_num),
        .rx_data(intf.rx_data), .rx_valid(intf.rx_valid), .rx_ready(intf.rx_ready),
        .rx_sop(intf.rx_sop), .rx_eop(intf.rx_eop), .rx_seq_num(intf.rx_seq_num)
    );

    initial begin
        // rc_bfm already publishes its own driver/monitor BFM handles
        // via config_db internally (see pcie_tlp_rc_agent_bfm.sv) -
        // only the EP monitor needs an explicit set here, since we
        // bypassed the combined ep_agent_bfm wrapper that would
        // otherwise have done it (and also pulled in an unused
        // driver_bfm we deliberately don't want).
        uvm_config_db#(virtual pcie_tlp_ep_monitor_bfm)::set(null, "*", "pcie_tlp_ep_monitor_bfm", ep_mon_bfm);
        run_test("pcie_tlp_dut_ep_test");
    end

endmodule : pcie_tlp_dut_top

`endif
