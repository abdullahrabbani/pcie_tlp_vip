// pcie_tlp_vip: DUT Integration env/test (RC VIP <-> EP DUT)
`ifndef PCIE_TLP_DUT_EP_TEST_SVH
`define PCIE_TLP_DUT_EP_TEST_SVH

class pcie_tlp_dut_ep_env extends uvm_env;
    `uvm_component_utils(pcie_tlp_dut_ep_env)
    pcie_tlp_rc_agent rc_agent;
    pcie_tlp_ep_agent ep_agent;   // is_active=PASSIVE - monitor only, DUT drives the wires

    function new(string name = "pcie_tlp_dut_ep_env", uvm_component parent = null);
        super.new(name, parent);
    endfunction

    function void build_phase(uvm_phase phase);
        pcie_tlp_rc_agent_config rc_cfg;
        pcie_tlp_ep_agent_config ep_cfg;
        super.build_phase(phase);

        rc_cfg = pcie_tlp_rc_agent_config::type_id::create("rc_cfg");
        rc_cfg.is_active = UVM_ACTIVE;
        uvm_config_db#(pcie_tlp_rc_agent_config)::set(this, "rc_agent", "cfg", rc_cfg);
        rc_agent = pcie_tlp_rc_agent::type_id::create("rc_agent", this);

        ep_cfg = pcie_tlp_ep_agent_config::type_id::create("ep_cfg");
        ep_cfg.is_active = UVM_PASSIVE;   // <-- the entire DUT-substitution switch
        uvm_config_db#(pcie_tlp_ep_agent_config)::set(this, "ep_agent", "cfg", ep_cfg);
        ep_agent = pcie_tlp_ep_agent::type_id::create("ep_agent", this);
    endfunction

endclass

class pcie_tlp_dut_ep_test extends uvm_test;
    `uvm_component_utils(pcie_tlp_dut_ep_test)
    pcie_tlp_dut_ep_env env;

    function new(string name = "pcie_tlp_dut_ep_test", uvm_component parent = null);
        super.new(name, parent);
    endfunction

    function void build_phase(uvm_phase phase);
        super.build_phase(phase);
        env = pcie_tlp_dut_ep_env::type_id::create("env", this);
    endfunction

    task run_phase(uvm_phase phase);
        pcie_tlp_rc_base_seq seq = pcie_tlp_rc_base_seq::type_id::create("seq");
        phase.raise_objection(this);
        seq.num_read_transactions   = 3;
        seq.num_write_transactions  = 3;
        seq.num_config_transactions = 0;
        seq.num_io_transactions     = 0;
        seq.start(env.rc_agent.read_sequencer);
        #2000;
        phase.drop_objection(this);
    endtask

endclass

`endif
