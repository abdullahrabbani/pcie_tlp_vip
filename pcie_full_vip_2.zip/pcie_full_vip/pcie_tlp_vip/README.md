# PCIe TLP VIP

Complete UVM-based verification IP for PCIe TLP.

## UVM Phases Implemented

All components implement the full UVM phase flow:

- **build_phase**: Component creation and configuration
- **connect_phase**: TLM connections between components
- **end_of_elaboration_phase**: Post-construction checks
- **start_of_simulation_phase**: Pre-simulation initialization
- **run_phase**: Main simulation task
- **extract_phase**: Data extraction from components
- **check_phase**: Assertion checking
- **report_phase**: Final report generation
- **final_phase**: Cleanup

## Directory Structure

- `src/` - Source files
  - `globals/` - Global package
  - `hdl_top/` - HDL top and BFMs
  - `hvl_top/` - HVL environment
    - `rc/` - Root Complex agent
    - `ep/` - Endpoint agent
    - `env/` - Environment and virtual sequencer
    - `test/` - Test classes
    - `test/sequences/` - Sequence classes
- `sim/` - Simulation scripts and makefiles

## Usage

```bash
cd sim
make compile
make sim TEST=pcie_tlp_base_test
```

## Changelog: fixes applied on top of the original upload

### Protocol-fidelity fixes (posted/non-posted semantics)
- **RC driver never waited for real completions.** `rc_driver_bfm` had
  no receive capability at all - `rc_driver_proxy` fired `send_tlp()`
  and immediately fabricated a fake response. Added
  `wait_for_completion()` to the BFM; the proxy now genuinely blocks
  on it for non-posted requests.
- **`MWr` incorrectly waited for/generated a completion.** Removed -
  Memory Write is posted per spec.
- **`IOWr` never got a completion at all.** Added one - IO Write is
  non-posted, unlike `MWr` (a common spec gotcha).
- **Msg/MsgData TLPs had no handler**, would hit `default: uvm_error`.
  Added a proper posted, no-completion handler.

### Build-system fix
- **Every compile.f in this track had a wrong path depth**
  (`../../src/...` when `sim/` and `src/` are direct siblings, needing
  only `../src/...`). Inherited from the original upload's own
  `pcie_tlp_compile.f` and copied uncritically into every other
  compile.f written for this whole project family. Fixed in all four
  affected files; every build target re-validated by fully resolving
  `` `include `` directives and confirming every referenced file
  actually exists on disk, not just checking text balance.

### DUT integration (new)
- `pcie_tlp_dut_top.sv` / `pcie_tlp_dut_ep_test.sv` / `pcie_tlp_dut_compile.f`
  - RC stays a normal active VIP; EP is replaced by
    `pcie_tlp_ep_dut_stub`, a plain-SV module (no UVM) that correctly
    frames/deframes the real multi-beat burst protocol.
  - `pcie_tlp_ep_agent`'s monitor is confirmed to build unconditionally
    regardless of `is_active` (verified by reading the actual
    `build_phase`, not assumed) - so it keeps observing real DUT
    traffic even with the driver removed.

### Scoreboard fix (the important one)
`pcie_tlp_scoreboard.compare_tlp()` does bit-exact comparison between
what RC sent and what EP's `ep_base_seq` independently randomizes.
Since those two sequences ran with **no causal relationship** beyond
matching *counts* and *address range*, the comparison failed on
almost every transaction, every run - not a rare corner case, the
default behavior of `pcie_tlp_base_test`.

Fixed with a shared `mailbox #(pcie_tlp_rc_tx)`, created by
`pcie_tlp_virtual_base_seq` and handed to both `rc_seq` and `ep_seq`:
- `rc_base_seq` pushes a clone of every issued request into the
  mailbox after `finish_item()`.
- `ep_base_seq` (when the mailbox is set) pulls from it and
  constructs its completion by mirroring **every field the
  scoreboard's `compare_tlp()` actually checks** - not just
  address/type, but `tc`/`vc_id`/`seq_num`/`tag`/`payload`/
  `payload_size`/`transaction_id`, since RC and EP build their packed
  `tlp_t` headers with identical bit-slicing logic and every one of
  those fields feeds into it.
- When no mailbox is set (standalone EP-only testing), `ep_base_seq`
  falls back to its original independent-randomization behavior
  unchanged - this is additive, not a breaking change.

Also fixed while in there: `pcie_tlp_rc_base_seq` and
`pcie_tlp_ep_base_seq` both declared their transaction counters
(`trans_count`, `total_count`, and RC's `inflight_base`/
`inflight_span`/`committed_base`) as `static` - class-level state
shared across every instance, not per-object. Harmless for a single
test run, but would corrupt state across any re-instantiation (e.g. a
regression running multiple tests in one compile). Now instance-level.
