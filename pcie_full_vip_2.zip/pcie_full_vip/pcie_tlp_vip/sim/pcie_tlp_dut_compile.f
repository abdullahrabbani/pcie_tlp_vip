// ============================================================================
// PCIe TLP VIP - DUT Integration (RC VIP <-> EP DUT) Compile File
// ============================================================================

-sv

+incdir+../src/globals/
+incdir+../src/hdl_top/pcie_tlp_interface/
+incdir+../src/hdl_top/rc_agent_bfm/
+incdir+../src/hdl_top/ep_agent_bfm/
+incdir+../src/hvl_top/rc/
+incdir+../src/hvl_top/ep/
+incdir+../src/hvl_top/env/
+incdir+../src/hvl_top/env/virtual_sequencer/
+incdir+../src/hvl_top/test/
+incdir+../src/hvl_top/test/sequences/rc_sequences/
+incdir+../src/hvl_top/test/sequences/ep_sequences/
+incdir+../src/hvl_top/test/virtual_sequences/

// Global Package
../src/globals/pcie_tlp_globals_pkg.sv

// HVL Packages
../src/hvl_top/rc/pcie_tlp_rc_pkg.sv
../src/hvl_top/ep/pcie_tlp_ep_pkg.sv
../src/hvl_top/env/pcie_tlp_env_pkg.sv

// Sequence Packages
../src/hvl_top/test/sequences/rc_sequences/pcie_tlp_rc_seq_pkg.sv
../src/hvl_top/test/sequences/ep_sequences/pcie_tlp_ep_seq_pkg.sv
../src/hvl_top/test/virtual_sequences/pcie_tlp_vseq_base_pkg.sv

// Tests (includes pcie_tlp_dut_ep_test.sv)
../src/hvl_top/test/pcie_tlp_test_pkg.sv

// Interface
../src/hdl_top/pcie_tlp_interface/pcie_tlp_if.sv

// RC Agent BFM (full - active side)
../src/hdl_top/rc_agent_bfm/pcie_tlp_rc_agent_bfm.sv
../src/hdl_top/rc_agent_bfm/pcie_tlp_rc_driver_bfm.sv
../src/hdl_top/rc_agent_bfm/pcie_tlp_rc_monitor_bfm.sv

// EP side: ONLY the monitor BFM - no driver_bfm, the DUT stub drives
// those wires directly instead (defined inside pcie_tlp_dut_top.sv).
../src/hdl_top/ep_agent_bfm/pcie_tlp_ep_monitor_bfm.sv

// Top-Level Module (includes the EP DUT stub + wiring)
../src/hdl_top/pcie_tlp_dut_top.sv
